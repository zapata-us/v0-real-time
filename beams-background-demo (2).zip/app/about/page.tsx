"use client"

import { useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Clock, Award, Users } from "lucide-react"
import { motion } from "framer-motion"
import { SiteLayout } from "@/components/site-layout"

export default function AboutPage() {
  const historyRef = useRef<HTMLDivElement>(null)
  const valuesRef = useRef<HTMLDivElement>(null)
  const teamRef = useRef<HTMLDivElement>(null)

  const sectionVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeOut",
      },
    },
  }

  return (
    <SiteLayout>
      <div className="px-4 sm:px-6 py-4 sm:py-6">
        <div className="mb-8 mt-[13%] backdrop-blur-sm bg-black/10 rounded-2xl p-3 inline-flex items-center text-sm text-white/80 hover:text-white transition-colors duration-200 shadow-sm">
          <Link href="/" className="inline-flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </div>

        <div className="mb-12 backdrop-blur-md bg-black/10 p-6 rounded-2xl border border-white/5 shadow-xl">
          <h1 className="text-3xl font-bold text-white mb-4 tracking-tight">About Real Time</h1>
          <p className="text-white/70 max-w-3xl mb-6">
            Discover our story, our passion for luxury timepieces, and the team behind Miami's premier watch
            destination.
          </p>

          <div className="border-t border-white/10 pt-6 mt-2">
            <div className="flex flex-wrap gap-4">
              <div className="text-sm text-white/80">Quick Navigation:</div>
              <div className="flex flex-wrap gap-2">
                <a
                  href="#our-history"
                  className="px-4 py-1.5 text-sm rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors duration-200 backdrop-blur-sm"
                >
                  Our History
                </a>
                <a
                  href="#our-values"
                  className="px-4 py-1.5 text-sm rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors duration-200 backdrop-blur-sm"
                >
                  Our Values
                </a>
                <a
                  href="#our-team"
                  className="px-4 py-1.5 text-sm rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors duration-200 backdrop-blur-sm"
                >
                  Our Team
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Our History Section */}
          <motion.section
            id="our-history"
            ref={historyRef}
            className="mb-8 scroll-mt-24 backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden p-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={sectionVariants}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-[#c0c0c0]/20 rounded-full">
                <Clock className="h-6 w-6 text-[#c0c0c0]" />
              </div>
              <div>
                <h2 className="text-white text-xl sm:text-2xl font-bold">Our History</h2>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-white/80">
                Founded in 2010, Real Time began as a small boutique in Miami's jewelry district with a simple mission:
                to provide watch enthusiasts with authentic luxury timepieces and exceptional service.
              </p>

              <p className="text-white/80">
                What started as a passion project by our founder, a third-generation watchmaker, quickly grew into one
                of Miami's most trusted destinations for luxury watches. Our reputation for authenticity, fair pricing,
                and unparalleled expertise has allowed us to build lasting relationships with collectors and enthusiasts
                alike.
              </p>

              <p className="text-white/80">
                Today, Real Time stands as a beacon in the luxury watch market, offering a curated selection of the
                world's finest timepieces while maintaining the personalized service that has been our hallmark since
                day one.
              </p>

              <div className="relative h-60 w-full overflow-hidden rounded-lg mt-6">
                <Image
                  src="/placeholder.svg?height=240&width=500&text=Our+Boutique"
                  alt="Real Time Boutique"
                  fill
                  className="object-cover"
                />
              </div>
            </div>
          </motion.section>

          {/* Our Values Section */}
          <motion.section
            id="our-values"
            ref={valuesRef}
            className="mb-8 scroll-mt-24 backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden p-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={sectionVariants}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-[#c0c0c0]/20 rounded-full">
                <Award className="h-6 w-6 text-[#c0c0c0]" />
              </div>
              <div>
                <h2 className="text-white text-xl sm:text-2xl font-bold">Our Values</h2>
              </div>
            </div>

            <div className="space-y-6">
              <div className="space-y-2">
                <h3 className="text-lg font-medium text-white">Authenticity</h3>
                <p className="text-white/80">
                  Every timepiece we sell undergoes rigorous authentication by our certified experts. We stand behind
                  the authenticity of our products with a lifetime guarantee.
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium text-white">Expertise</h3>
                <p className="text-white/80">
                  Our team consists of passionate watch enthusiasts and certified watchmakers with decades of combined
                  experience in the luxury watch industry.
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium text-white">Transparency</h3>
                <p className="text-white/80">
                  We believe in complete transparency in all our dealings. From pricing to the condition of our watches,
                  we provide honest and detailed information.
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-medium text-white">Service</h3>
                <p className="text-white/80">
                  Customer satisfaction is our priority. We offer personalized service tailored to each client's needs,
                  whether you're a first-time buyer or a seasoned collector.
                </p>
              </div>
            </div>
          </motion.section>

          {/* Our Team Section */}
          <motion.section
            id="our-team"
            ref={teamRef}
            className="mb-8 scroll-mt-24 backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden p-6 md:col-span-2"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={sectionVariants}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-[#c0c0c0]/20 rounded-full">
                <Users className="h-6 w-6 text-[#c0c0c0]" />
              </div>
              <div>
                <h2 className="text-white text-xl sm:text-2xl font-bold">Our Team</h2>
              </div>
            </div>

            <p className="text-white/80 mb-6">
              Meet the passionate experts behind Real Time. Our team combines decades of experience in horology with a
              genuine love for luxury timepieces.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {/* Team Member 1 - Founder */}
              <div className="backdrop-blur-sm bg-black/10 border border-white/10 rounded-lg overflow-hidden">
                <div className="relative h-64 w-full">
                  <Image
                    src="/placeholder.svg?height=256&width=256&text=Dani+Zapata"
                    alt="Dani Zapata"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-medium text-white">Dani Zapata</h3>
                  <p className="text-white/60 text-sm">Founder</p>
                  <p className="text-white/80 mt-2 text-sm">
                    As the founder of Real Time, Dani's vision and expertise in luxury timepieces have established our
                    reputation for excellence in the watch industry.
                  </p>
                </div>
              </div>

              {/* Team Member 2 - Co-founder */}
              <div className="backdrop-blur-sm bg-black/10 border border-white/10 rounded-lg overflow-hidden">
                <div className="relative h-64 w-full">
                  <Image
                    src="/placeholder.svg?height=256&width=256&text=Bryan+Zapata"
                    alt="Bryan Zapata"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="text-lg font-medium text-white">Bryan Zapata</h3>
                  <p className="text-white/60 text-sm">Co-founder</p>
                  <p className="text-white/80 mt-2 text-sm">
                    Bryan's passion for horology and business acumen have been instrumental in growing Real Time into
                    Miami's premier destination for luxury watches.
                  </p>
                </div>
              </div>
            </div>
          </motion.section>

          {/* Certifications Section */}
          <motion.section
            className="mb-8 scroll-mt-24 backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden p-6 md:col-span-2"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={sectionVariants}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-[#c0c0c0]/20 rounded-full">
                <Award className="h-6 w-6 text-[#c0c0c0]" />
              </div>
              <div>
                <h2 className="text-white text-xl sm:text-2xl font-bold">Industry Recognition</h2>
              </div>
            </div>

            <p className="text-white/80 mb-6">
              Real Time is proud to be members of the most prestigious watch shows and exhibitions nationwide. Our
              presence at these exclusive events allows us to bring the finest timepieces to our discerning clientele.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 justify-between">
              {["IWJG", "Las Vegas", "Miami", "New York", "JCK"].map((city, i) => (
                <div
                  key={i}
                  className={`flex items-center justify-start ${i === 1 ? "sm:col-end-4 md:col-end-7" : ""}`}
                >
                  <div
                    className={`relative h-20 w-full flex flex-col ${city === "JCK" ? "items-center" : "items-start"} justify-center`}
                  >
                    {city === "Miami" ? (
                      <Image
                        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ORIGINALVINTAGE-REAL-TIME-prccZZu80FQWbL1EO40d2TG76VgPBK.png"
                        alt="ORIGINAL VINTAGE REAL TIME"
                        width={204}
                        height={109}
                        className="object-contain"
                      />
                    ) : city === "New York" ? (
                      <Image
                        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/nycjaws-logo-white-JOiIlGoqBdjjABplDMcuVlhgnOgdRE.svg"
                        alt="New York City Jewelry & Watch Show"
                        width={180}
                        height={96}
                        className="object-contain"
                      />
                    ) : city === "Las Vegas" ? (
                      <Image
                        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/JIS-01-NqJNsDLaPcZcHLZFfZ0hfMg6Mx4Rao.png"
                        alt="JIS Show"
                        width={154}
                        height={106}
                        className="object-contain brightness-0 invert"
                      />
                    ) : city === "IWJG" ? (
                      <Image
                        src="/images/IWJG-REAL-TIME.png"
                        alt="IWJG REAL TIME"
                        width={180}
                        height={96}
                        className="object-contain"
                      />
                    ) : city === "JCK" ? (
                      <Image
                        src="/images/jck-logo-white.png"
                        alt="JCK Show"
                        width={180}
                        height={96}
                        className="object-contain"
                      />
                    ) : (
                      <Image
                        src={`/placeholder.svg?height=96&width=96&text=${city}+Show`}
                        alt={`${city} Watch Show`}
                        width={96}
                        height={96}
                        className="object-contain"
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </motion.section>
        </div>
      </div>
    </SiteLayout>
  )
}
