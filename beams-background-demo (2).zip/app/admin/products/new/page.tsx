"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { SiteLayout } from "@/components/site-layout"
import { ProductForm } from "@/components/product-form"
import { useAuth } from "@/lib/auth-context"

export default function NewProductPage() {
  const router = useRouter()
  const { user, isAdmin } = useAuth()

  useEffect(() => {
    // Redirect if not authenticated or not admin
    if (!isAdmin) {
      router.push("/login?redirect=/admin/products/new")
    }
  }, [isAdmin, router])

  if (!isAdmin) {
    return null // Don't render anything while redirecting
  }

  return (
    <SiteLayout isAdmin={true}>
      <div className="container mx-auto px-4 py-8">
        <ProductForm />
      </div>
    </SiteLayout>
  )
}
