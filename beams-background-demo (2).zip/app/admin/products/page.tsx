"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Plus, Search, Filter, ArrowUpDown, MoreHorizontal, Pencil, Trash2, Eye, AlertCircle } from "lucide-react"
import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"
import type { ProductType } from "@/types/product"
import { fetchProducts, deleteProduct } from "@/lib/product-service"
import { useAuth } from "@/lib/auth-context"

export default function ProductsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { user, isAdmin } = useAuth()
  const [products, setProducts] = useState<ProductType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [productToDelete, setProductToDelete] = useState<string | null>(null)

  useEffect(() => {
    // Only redirect if we've finished loading and the user is not an admin
    if (!isLoading && !isAdmin) {
      router.push("/login?redirect=/admin/products")
      return
    }

    // Only load products if we're authenticated as admin
    if (!isLoading && isAdmin) {
      loadProducts()
    }
  }, [isLoading, isAdmin, router])

  const loadProducts = async () => {
    setIsLoading(true)
    try {
      const data = await fetchProducts()
      setProducts(data)
    } catch (error) {
      toast({
        title: "Error loading products",
        description: "There was a problem loading the product list. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteClick = (productId: string) => {
    setProductToDelete(productId)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = async () => {
    if (!productToDelete) return

    try {
      await deleteProduct(productToDelete)
      setProducts(products.filter((product) => product.id !== productToDelete))
      toast({
        title: "Product deleted",
        description: "The product has been successfully deleted.",
      })
    } catch (error) {
      toast({
        title: "Error deleting product",
        description: "There was a problem deleting the product. Please try again.",
        variant: "destructive",
      })
    } finally {
      setDeleteDialogOpen(false)
      setProductToDelete(null)
    }
  }

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.id.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Add this near the top of the component, before the return statement
  if (isLoading) {
    return (
      <SiteLayout isAdmin={true}>
        <div className="container mx-auto px-4 py-8 mt-[40%]">
          <div className="text-center py-8">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
            <p className="mt-4 text-white/70">Loading authentication...</p>
          </div>
        </div>
      </SiteLayout>
    )
  }

  return (
    <SiteLayout isAdmin={true}>
      <div className="container mx-auto px-4 py-8 mt-[40%]">
        <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-4 mb-6">
          <h3 className="text-white font-medium mb-1">Real-Time Updates Enabled</h3>
          <p className="text-white/80 text-sm">
            All changes made in the admin panel are automatically reflected in the frontend. Products marked as "manual"
            will be immediately visible to users after publishing.
          </p>
        </div>

        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-white">Product Management</h1>
          <Button onClick={() => router.push("/admin/products/new")} className="bg-white text-black hover:bg-white/90">
            <Plus className="mr-2 h-4 w-4" />
            Add New Product
          </Button>
        </div>

        <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/50" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-black/20 border-white/20 text-white placeholder:text-white/50"
              />
            </div>
            <Button variant="outline" className="border-white/20 text-white">
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </div>

          {isLoading ? (
            <div className="text-center py-8">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
              <p className="mt-4 text-white/70">Loading products...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-white/20 rounded-lg">
              <AlertCircle className="mx-auto h-12 w-12 text-white/50" />
              <h3 className="mt-4 text-lg font-medium text-white">No products found</h3>
              <p className="mt-2 text-white/70">
                {searchQuery ? "Try adjusting your search query" : "Start by adding a new product"}
              </p>
              {!searchQuery && (
                <Button
                  onClick={() => router.push("/admin/products/new")}
                  className="mt-4 bg-white text-black hover:bg-white/90"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add New Product
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-white/5">
                    <TableHead className="text-white/70">Image</TableHead>
                    <TableHead className="text-white/70">
                      <div className="flex items-center">
                        Name
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                      </div>
                    </TableHead>
                    <TableHead className="text-white/70">Brand</TableHead>
                    <TableHead className="text-white/70 text-right">Price</TableHead>
                    <TableHead className="text-white/70 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => (
                    <TableRow key={product.id} className="border-white/10 hover:bg-white/5">
                      <TableCell className="font-medium">
                        <div className="h-12 w-12 rounded bg-white/10 overflow-hidden">
                          {product.image && (
                            <img
                              src={product.image || "/placeholder.svg"}
                              alt={product.name}
                              className="h-full w-full object-cover"
                            />
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium text-white">{product.name}</TableCell>
                      <TableCell className="text-white/70">{product.brand}</TableCell>
                      <TableCell className="text-right text-white">${product.price.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0 text-white">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-black/90 border-white/20">
                            <DropdownMenuLabel className="text-white/70">Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator className="bg-white/10" />
                            <DropdownMenuItem
                              className="text-white cursor-pointer hover:bg-white/10"
                              onClick={() => router.push(`/product/${product.id}`)}
                            >
                              <Eye className="mr-2 h-4 w-4" />
                              View
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-white cursor-pointer hover:bg-white/10"
                              onClick={() => router.push(`/admin/products/edit/${product.id}`)}
                            >
                              <Pencil className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-red-500 cursor-pointer hover:bg-white/10"
                              onClick={() => handleDeleteClick(product.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="bg-black/90 border-white/20 text-white">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription className="text-white/70">
              Are you sure you want to delete this product? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="border-white/20 text-white hover:bg-white/10"
            >
              Cancel
            </Button>
            <Button onClick={confirmDelete} className="bg-red-600 hover:bg-red-700 text-white">
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SiteLayout>
  )
}
