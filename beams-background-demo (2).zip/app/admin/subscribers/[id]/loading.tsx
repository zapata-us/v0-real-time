import { SiteLayout } from "@/components/site-layout"

export default function Loading() {
  return (
    <SiteLayout isAdmin={true}>
      <div className="container mx-auto px-4 py-8 mt-[40%]">
        <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-6">
          <div className="text-center py-8">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
            <p className="mt-4 text-white/70">Loading subscriber details...</p>
          </div>
        </div>
      </div>
    </SiteLayout>
  )
}
