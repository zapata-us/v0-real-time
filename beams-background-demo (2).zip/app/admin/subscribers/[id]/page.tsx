"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, User, Calendar, Clock, CreditCard, MapPin, Phone, Mail, Building, AtSign } from "lucide-react"
import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import type { SubscriberType } from "@/types/subscriber"
import { fetchSubscriberById, updateSubscriptionStatus } from "@/lib/subscriber-service"
import { useAuth } from "@/lib/auth-context"

export default function SubscriberDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const { isAdmin } = useAuth()
  const [subscriber, setSubscriber] = useState<SubscriberType | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const { id } = params

  useEffect(() => {
    // Redirect if not authenticated or not admin
    if (!isLoading && !isAdmin) {
      router.push(`/login?redirect=/admin/subscribers/${id}`)
      return
    }

    // Load subscriber data if we're authenticated as admin
    if (!isLoading && isAdmin) {
      loadSubscriber()
    }
  }, [isLoading, isAdmin, router, id])

  const loadSubscriber = async () => {
    setIsLoading(true)
    try {
      const data = await fetchSubscriberById(id)
      setSubscriber(data)
    } catch (error) {
      toast({
        title: "Error loading subscriber",
        description: "There was a problem loading the subscriber details. Please try again.",
        variant: "destructive",
      })
      router.push("/admin/subscribers")
    } finally {
      setIsLoading(false)
    }
  }

  const handleStatusUpdate = async (status: "active" | "cancelled" | "expired" | "pending") => {
    if (!subscriber) return

    try {
      const updatedSubscriber = await updateSubscriptionStatus(subscriber.id, status)
      setSubscriber(updatedSubscriber)
      toast({
        title: "Status updated",
        description: `Subscription status has been updated to ${status}.`,
      })
    } catch (error) {
      toast({
        title: "Error updating status",
        description: "There was a problem updating the subscription status. Please try again.",
        variant: "destructive",
      })
    }
  }

  // Helper function to format dates
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  // Helper function for status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/20 text-green-500 border-green-500/30"
      case "cancelled":
        return "bg-orange-500/20 text-orange-500 border-orange-500/30"
      case "expired":
        return "bg-red-500/20 text-red-500 border-red-500/30"
      case "pending":
        return "bg-blue-500/20 text-blue-500 border-blue-500/30"
      default:
        return "bg-gray-500/20 text-gray-500 border-gray-500/30"
    }
  }

  // Add this near the top of the component, before the return statement
  if (isLoading) {
    return (
      <SiteLayout isAdmin={true}>
        <div className="container mx-auto px-4 py-8 mt-[40%]">
          <div className="text-center py-8">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
            <p className="mt-4 text-white/70">Loading subscriber details...</p>
          </div>
        </div>
      </SiteLayout>
    )
  }

  if (!subscriber) {
    return (
      <SiteLayout isAdmin={true}>
        <div className="container mx-auto px-4 py-8 mt-[40%]">
          <div className="text-center py-8">
            <div className="text-red-500 text-6xl mb-4">404</div>
            <h2 className="text-xl font-medium text-white mb-2">Subscriber Not Found</h2>
            <p className="text-white/70 mb-6">The subscriber you're looking for doesn't exist or has been removed.</p>
            <Button onClick={() => router.push("/admin/subscribers")} className="bg-white text-black hover:bg-white/90">
              Return to Subscribers
            </Button>
          </div>
        </div>
      </SiteLayout>
    )
  }

  return (
    <SiteLayout isAdmin={true}>
      <div className="container mx-auto px-4 py-8 mt-[40%]">
        {/* Back button */}
        <div className="mb-6">
          <button
            onClick={() => router.push("/admin/subscribers")}
            className="group inline-flex items-center text-white/70 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2 group-hover:-translate-x-1 transition-transform" />
            <span>Back to subscribers</span>
          </button>
        </div>

        {/* Subscriber Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div className="flex items-center">
            <div className="h-12 w-12 rounded-full bg-white/10 text-white flex items-center justify-center mr-4">
              <User className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">
                {subscriber.firstName} {subscriber.lastName}
              </h1>
              <div className="flex items-center space-x-3 mt-1">
                <Badge className={`${getStatusColor(subscriber.subscriptionStatus)} border`}>
                  {subscriber.subscriptionStatus.charAt(0).toUpperCase() + subscriber.subscriptionStatus.slice(1)}
                </Badge>
                <span className="text-white/70">
                  {subscriber.subscriptionType === "monthly" ? "Monthly" : "Annual"} Plan
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {subscriber.subscriptionStatus !== "active" && (
              <Button
                onClick={() => handleStatusUpdate("active")}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                Activate Subscription
              </Button>
            )}

            {subscriber.subscriptionStatus !== "cancelled" && (
              <Button
                onClick={() => handleStatusUpdate("cancelled")}
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                Cancel Subscription
              </Button>
            )}

            <Button
              onClick={() => router.push(`/admin/subscribers/edit/${subscriber.id}`)}
              className="bg-white text-black hover:bg-white/90"
            >
              Edit Subscriber
            </Button>
          </div>
        </div>

        {/* Main content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left column - Subscriber Info */}
          <div className="md:col-span-2 space-y-6">
            <Card className="bg-black/30 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Subscriber Information</CardTitle>
                <CardDescription className="text-white/70">Personal and contact details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <p className="text-white/50 text-sm">Full Name</p>
                    <p className="text-white font-medium">
                      {subscriber.firstName} {subscriber.lastName}
                    </p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-white/50 text-sm flex items-center">
                      <Mail className="h-3 w-3 mr-2" /> Email Address
                    </p>
                    <p className="text-white font-medium">{subscriber.email}</p>
                  </div>
                </div>

                <Separator className="bg-white/10" />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-1">
                    <p className="text-white/50 text-sm flex items-center">
                      <AtSign className="h-3 w-3 mr-2" /> Username
                    </p>
                    <p className="text-white font-medium">@{subscriber.username}</p>
                  </div>

                  <div className="space-y-1">
                    <p className="text-white/50 text-sm flex items-center">
                      <Phone className="h-3 w-3 mr-2" /> Phone Number
                    </p>
                    <p className="text-white font-medium">{subscriber.phone}</p>
                  </div>
                </div>

                <Separator className="bg-white/10" />

                <div className="space-y-1">
                  <p className="text-white/50 text-sm flex items-center">
                    <Building className="h-3 w-3 mr-2" /> Company
                  </p>
                  <p className="text-white font-medium">{subscriber.companyName}</p>
                </div>

                <Separator className="bg-white/10" />

                <div className="space-y-1">
                  <p className="text-white/50 text-sm flex items-center">
                    <MapPin className="h-3 w-3 mr-2" /> Address
                  </p>
                  <div className="text-white">
                    <p>{subscriber.address.street}</p>
                    {subscriber.address.street2 && <p>{subscriber.address.street2}</p>}
                    <p>
                      {subscriber.address.city}, {subscriber.address.state} {subscriber.address.zip}
                    </p>
                    <p>{subscriber.address.country}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right column - Subscription Details */}
          <div className="space-y-6">
            <Card className="bg-black/30 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Subscription Details</CardTitle>
                <CardDescription className="text-white/70">Plan information and dates</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1">
                  <p className="text-white/50 text-sm flex items-center">
                    <CreditCard className="h-3 w-3 mr-2" /> Plan Type
                  </p>
                  <p className="text-white font-medium">
                    {subscriber.subscriptionType === "monthly" ? "Monthly" : "Annual"} Plan
                    {subscriber.subscriptionType === "monthly" ? " ($12.49/month)" : " ($99.99/year)"}
                  </p>
                </div>

                <div className="space-y-1">
                  <p className="text-white/50 text-sm flex items-center">
                    <Calendar className="h-3 w-3 mr-2" /> Start Date
                  </p>
                  <p className="text-white font-medium">{formatDate(subscriber.startDate)}</p>
                </div>

                <div className="space-y-1">
                  <p className="text-white/50 text-sm flex items-center">
                    <Calendar className="h-3 w-3 mr-2" /> Next Billing Date
                  </p>
                  <p className="text-white font-medium">{formatDate(subscriber.nextBillingDate)}</p>
                </div>

                <Separator className="bg-white/10" />

                <div className="space-y-1">
                  <p className="text-white/50 text-sm flex items-center">
                    <Clock className="h-3 w-3 mr-2" /> Member Since
                  </p>
                  <p className="text-white font-medium">{formatDate(subscriber.createdAt)}</p>
                </div>

                {subscriber.lastLoginAt && (
                  <div className="space-y-1">
                    <p className="text-white/50 text-sm flex items-center">
                      <Clock className="h-3 w-3 mr-2" /> Last Login
                    </p>
                    <p className="text-white font-medium">{formatDate(subscriber.lastLoginAt)}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-black/30 border-white/10">
              <CardHeader>
                <CardTitle className="text-white">Payment History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-6">
                  <p className="text-white/70">Payment history is available in the billing system</p>
                  <Button className="mt-4 bg-white/10 text-white hover:bg-white/20">View Billing System</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </SiteLayout>
  )
}
