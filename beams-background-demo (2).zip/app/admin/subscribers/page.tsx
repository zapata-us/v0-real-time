"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Search,
  Filter,
  ArrowUpDown,
  MoreHorizontal,
  Pencil,
  Trash2,
  Eye,
  AlertCircle,
  User,
  UserPlus,
  Calendar,
  DollarSign,
  Users,
} from "lucide-react"
import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

import type { SubscriberType } from "@/types/subscriber"
import { fetchSubscribers, deleteSubscriber, updateSubscriptionStatus } from "@/lib/subscriber-service"
import { useAuth } from "@/lib/auth-context"

export default function SubscribersPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { user, isAdmin } = useAuth()
  const [subscribers, setSubscribers] = useState<SubscriberType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [subscriberToDelete, setSubscriberToDelete] = useState<string | null>(null)
  const [statusDialogOpen, setStatusDialogOpen] = useState(false)
  const [subscriberToUpdate, setSubscriberToUpdate] = useState<{
    id: string
    status: "active" | "cancelled" | "expired" | "pending"
  } | null>(null)
  const [activeFilter, setActiveFilter] = useState("all")

  useEffect(() => {
    // Only redirect if we've finished loading and the user is not an admin
    if (!isLoading && !isAdmin) {
      router.push("/login?redirect=/admin/subscribers")
      return
    }

    // Only load subscribers if we're authenticated as admin
    if (!isLoading && isAdmin) {
      loadSubscribers()
    }
  }, [isLoading, isAdmin, router])

  const loadSubscribers = async (filterStatus?: string) => {
    setIsLoading(true)
    try {
      const filters: { status?: string[] } = {}

      if (filterStatus && filterStatus !== "all") {
        filters.status = [filterStatus]
      }

      const data = await fetchSubscribers({
        filters,
      })
      setSubscribers(data)
    } catch (error) {
      toast({
        title: "Error loading subscribers",
        description: "There was a problem loading the subscriber list. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteClick = (subscriberId: string) => {
    setSubscriberToDelete(subscriberId)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = async () => {
    if (!subscriberToDelete) return

    try {
      await deleteSubscriber(subscriberToDelete)
      setSubscribers(subscribers.filter((subscriber) => subscriber.id !== subscriberToDelete))
      toast({
        title: "Subscriber deleted",
        description: "The subscriber has been successfully deleted.",
      })
    } catch (error) {
      toast({
        title: "Error deleting subscriber",
        description: "There was a problem deleting the subscriber. Please try again.",
        variant: "destructive",
      })
    } finally {
      setDeleteDialogOpen(false)
      setSubscriberToDelete(null)
    }
  }

  const handleStatusClick = (subscriberId: string, status: "active" | "cancelled" | "expired" | "pending") => {
    setSubscriberToUpdate({ id: subscriberId, status })
    setStatusDialogOpen(true)
  }

  const confirmStatusUpdate = async () => {
    if (!subscriberToUpdate) return

    try {
      const updatedSubscriber = await updateSubscriptionStatus(subscriberToUpdate.id, subscriberToUpdate.status)
      setSubscribers(subscribers.map((sub) => (sub.id === updatedSubscriber.id ? updatedSubscriber : sub)))
      toast({
        title: "Status updated",
        description: `Subscription status has been updated to ${subscriberToUpdate.status}.`,
      })
    } catch (error) {
      toast({
        title: "Error updating status",
        description: "There was a problem updating the subscription status. Please try again.",
        variant: "destructive",
      })
    } finally {
      setStatusDialogOpen(false)
      setSubscriberToUpdate(null)
    }
  }

  const filteredSubscribers = subscribers.filter(
    (subscriber) =>
      subscriber.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subscriber.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subscriber.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subscriber.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      subscriber.companyName.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Helper function to format dates
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  // Helper function for status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/20 text-green-500 border-green-500/30"
      case "cancelled":
        return "bg-orange-500/20 text-orange-500 border-orange-500/30"
      case "expired":
        return "bg-red-500/20 text-red-500 border-red-500/30"
      case "pending":
        return "bg-blue-500/20 text-blue-500 border-blue-500/30"
      default:
        return "bg-gray-500/20 text-gray-500 border-gray-500/30"
    }
  }

  // Add this near the top of the component, before the return statement
  if (isLoading) {
    return (
      <SiteLayout isAdmin={true}>
        <div className="container mx-auto px-4 py-8 mt-[40%]">
          <div className="text-center py-8">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
            <p className="mt-4 text-white/70">Loading authentication...</p>
          </div>
        </div>
      </SiteLayout>
    )
  }

  return (
    <SiteLayout isAdmin={true}>
      <div className="container mx-auto px-4 py-8 mt-[40%]">
        <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-4 mb-6">
          <h3 className="text-white font-medium mb-1">Subscriber Management</h3>
          <p className="text-white/80 text-sm">
            View and manage subscribers to Real Time. Track subscription statuses, update information, and manage user accounts.
          </p>
        </div>

        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-white">Subscribers</h1>
            <div className="ml-4 bg-black/30 rounded-full px-3 py-1">
              <span className="text-white/70 text-sm">{subscribers.length} total</span>
            </div>
          </div>
          <Button onClick={() => router.push("/subscription")} className="bg-white text-black hover:bg-white/90">
            <UserPlus className="mr-2 h-4 w-4" />
            New Subscription
          </Button>
        </div>

        <Tabs defaultValue="all" className="mb-6" onValueChange={(value) => {
          setActiveFilter(value)
          loadSubscribers(value === "all" ? undefined : value)
        }}>
          <TabsList className="bg-black/20 border border-white/10">
            <TabsTrigger value="all" className="data-[state=active]:bg-white/10">
              All
            </TabsTrigger>
            <TabsTrigger value="active" className="data-[state=active]:bg-white/10">
              Active
            </TabsTrigger>
            <TabsTrigger value="cancelled" className="data-[state=active]:bg-white/10">
              Cancelled
            </TabsTrigger>
            <TabsTrigger value="expired" className="data-[state=active]:bg-white/10">
              Expired
            </TabsTrigger>
            <TabsTrigger value="pending" className="data-[state=active]:bg-white/10">
              Pending
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/50" />
              <Input
                placeholder="Search subscribers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-black/20 border-white/20 text-white placeholder:text-white/50"
              />
            </div>
            <Button variant="outline" className="border-white/20 text-white">
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </div>

          {isLoading ? (
            <div className="text-center py-8">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
              <p className="mt-4 text-white/70">Loading subscribers...</p>
            </div>
          ) : filteredSubscribers.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-white/20 rounded-lg">
              <AlertCircle className="mx-auto h-12 w-12 text-white/50" />
              <h3 className="mt-4 text-lg font-medium text-white">No subscribers found</h3>
              <p className="mt-2 text-white/70">
                {searchQuery ? "Try adjusting your search query" : "No subscribers match the current filters"}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-white/5">
                    <TableHead className="text-white/70">Name</TableHead>
                    <TableHead className="text-white/70">
                      <div className="flex items-center">
                        Email/Username
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                      </div>
                    </TableHead>
                    <TableHead className="text-white/70">Status</TableHead>
                    <TableHead className="text-white/70">Plan</TableHead>
                    <TableHead className="text-white/70 text-right">Next Billing</TableHead>
                    <TableHead className="text-white/70 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSubscribers.map((subscriber) => (
                    <TableRow key={subscriber.id} className="border-white/10 hover:bg-white/5">
                      <TableCell className="font-medium text-white">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-white/10 text-white flex items-center justify-center mr-3">
                            <User className="h-4 w-4" />
                          </div>
                          <div>
                            <div>{subscriber.firstName} {subscriber.lastName}</div>
                            <div className="text-white/50 text-xs">{subscriber.companyName}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-white">
                        <div>{subscriber.email}</div>
                        <div className="text-white/50 text-xs">@{subscriber.username}</div>
                      </TableCell>
                      <TableCell>
                        <Badge className={`${getStatusColor(subscriber.subscriptionStatus)} border`}>
                          {subscriber.subscriptionStatus.charAt(0).toUpperCase() + subscriber.subscriptionStatus.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-white">
                        {subscriber.subscriptionType === "monthly" ? "Monthly" : "Annual"}
                      </TableCell>
                      <TableCell className="text-right text-white/70">
                        {formatDate(subscriber.nextBillingDate)}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0 text-white">
                              <span className="sr-only">Open menu</span>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-black/90 border-white/20">
                            <DropdownMenuLabel className="text-white/70">Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator className="bg-white/10" />
                            <DropdownMenuItem
                              className="text-white cursor-pointer hover:bg-white/10"
                              onClick={() => router.push(`/admin/subscribers/${subscriber.id}`)}
                            >
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-white cursor-pointer hover:bg-white/10"
                              onClick={() => router.push(`/admin/subscribers/edit/${subscriber.id}`)}
                            >
                              <Pencil className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            
                            {/* Status Update Options */}
                            <DropdownMenuSeparator className="bg-white/10" />
                            <DropdownMenuLabel className="text-white/70">Status</DropdownMenuLabel>
                            
                            {subscriber.subscriptionStatus !== "active" && (
                              <DropdownMenuItem
                                className="text-green-500 cursor-pointer hover:bg-white/10"
                                onClick={() => handleStatusClick(subscriber.id, "active")}
                              >
                                <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
                                Activate
                              </DropdownMenuItem>
                            )}
                            
                            {subscriber.subscriptionStatus !== "cancelled" && (
                              <DropdownMenuItem
                                className="text-orange-500 cursor-pointer hover:bg-white/10"
                                onClick={() => handleStatusClick(subscriber.id, "cancelled")}
                              >
                                <div className="h-2 w-2 rounded-full bg-orange-500 mr-2"></div>
                                Cancel
                              </DropdownMenuItem>
                            )}
                            
                            {subscriber.subscriptionStatus !== "expired" && (
                              <DropdownMenuItem
                                className="text-red-500 cursor-pointer hover:bg-white/10"
                                onClick={() => handleStatusClick(subscriber.id, "expired")}
                              >
                                <div className="h-2 w-2 rounded-full bg-red-500 mr-2"></div>
                                Mark Expired
                              </DropdownMenuItem>
                            )}
                            
                            <DropdownMenuSeparator className="bg-white/10" />
                            <DropdownMenuItem
                              className="text-red-500 cursor-pointer hover:bg-white/10"
                              onClick={() => handleDeleteClick(subscriber.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
        
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="bg-black/30 border border-white/10 rounded-lg p-6 backdrop-blur-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-white">Active Subscribers</h3>
              <Users className="h-5 w-5 text-green-400" />
            </div>
            <p className="text-3xl font-bold text-white">
              {subscribers.filter(s => s.subscriptionStatus === "active").length}
            </p>
            <p className="text-white/60 text-sm mt-2">
              Current active subscriptions
            </p>
          </div>
          
          <div className="bg-black/30 border border-white/10 rounded-lg p-6 backdrop-blur-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-white">Renewals Soon</h3>
              <Calendar className="h-5 w-5 text-blue-400" />
            </div>
            <p className="text-3xl font-bold text-white">
              {subscribers.filter(s => 
                s.subscriptionStatus === "active" && 
                s.nextBillingDate < Date.now() + (30 * 24 * 60 * 60 * 1000)
              ).length}
            </p>
            <p className="text-white/60 text-sm mt-2">
              Renewals in the next 30 days
            </p>
          </div>
          
          <div className="bg-black/30 border border-white/10 rounded-lg p-6 backdrop-blur-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-white">Monthly Revenue</h3>
              <DollarSign className="h-5 w-5 text-amber-400" />
            </div>
            <p className="text-3xl font-bold text-white">
              ${(
                (subscribers.filter(s => s.subscriptionStatus === "active" && s.subscriptionType === "monthly").length * 12.49) +\
                (subscribers.filter(s => s.subscriptionStatus === "active\" && s.subscriptionType === \"annual\").length * (99.99 / 12)).toFixed(2)}
            </p>
            <p className="text-white/60 text-sm mt-2">
              Estimated monthly subscription revenue
            </p>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="bg-black/90 border-white/20 text-white">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription className="text-white/70">
              Are you sure you want to delete this subscriber? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDeleteDialogOpen(false)}
              className="border-white/20 text-white hover:bg-white/10"
            >
              Cancel
            </Button>
            <Button onClick={confirmDelete} className="bg-red-600 hover:bg-red-700 text-white">
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Status Update Dialog */}
      <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
        <DialogContent className="bg-black/90 border-white/20 text-white">
          <DialogHeader>
            <DialogTitle>Update Subscription Status</DialogTitle>
            <DialogDescription className="text-white/70">
              Are you sure you want to change the subscription status to{" "}
              <span className="font-medium text-white">
                {subscriberToUpdate?.status}
              </span>
              ?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setStatusDialogOpen(false)}
              className="border-white/20 text-white hover:bg-white/10"
            >
              Cancel
            </Button>
            <Button onClick={confirmStatusUpdate} className="bg-amber-500 hover:bg-amber-600 text-black">
              Update Status
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </SiteLayout>
  )
}
