import { NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.SOME_CRITICAL_VAR || "", {
  apiVersion: "2023-10-16",
})

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { customerId, paymentMethodId } = body

    if (!customerId || !paymentMethodId) {
      return NextResponse.json({ error: "Customer ID and payment method ID are required" }, { status: 400 })
    }

    // Attach the payment method to the customer
    await stripe.paymentMethods.attach(paymentMethodId, {
      customer: customerId,
    })

    // Set as default payment method
    await stripe.customers.update(customerId, {
      invoice_settings: {
        default_payment_method: paymentMethodId,
      },
    })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Stripe API error:", error)
    return NextResponse.json(
      { error: { message: error.message || "Failed to update payment method." } },
      { status: 400 },
    )
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const paymentMethodId = searchParams.get("paymentMethodId")

    if (!paymentMethodId) {
      return NextResponse.json({ error: "Payment method ID is required" }, { status: 400 })
    }

    // Detach the payment method
    await stripe.paymentMethods.detach(paymentMethodId)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error("Stripe API error:", error)
    return NextResponse.json(
      { error: { message: error.message || "Failed to delete payment method." } },
      { status: 400 },
    )
  }
}
