import { NextResponse } from "next/server"
import Stripe from "stripe"

// Initialize Stripe with the secret key
const stripe = new Stripe(process.env.SOME_CRITICAL_VAR || "", {
  apiVersion: "2023-10-16",
})

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { priceId, customerId, paymentMethodId, subscriptionType, billingCycle } = body

    // Create or retrieve a customer
    let customer
    if (customerId) {
      customer = await stripe.customers.retrieve(customerId)
    } else {
      customer = await stripe.customers.create({
        email: body.email,
        name: body.name,
        metadata: {
          userId: body.userId,
        },
      })
    }

    // Attach payment method to customer if provided
    if (paymentMethodId) {
      await stripe.paymentMethods.attach(paymentMethodId, {
        customer: customer.id,
      })

      // Set as default payment method
      await stripe.customers.update(customer.id, {
        invoice_settings: {
          default_payment_method: paymentMethodId,
        },
      })
    }

    // Create subscription
    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [
        {
          price: priceId,
        },
      ],
      payment_behavior: "default_incomplete",
      payment_settings: {
        save_default_payment_method: "on_subscription",
      },
      expand: ["latest_invoice.payment_intent"],
    })

    return NextResponse.json({
      subscriptionId: subscription.id,
      clientSecret: (subscription.latest_invoice as any).payment_intent.client_secret,
      customerId: customer.id,
    })
  } catch (error: any) {
    console.error("Stripe API error:", error)
    return NextResponse.json(
      { error: { message: error.message || "Something went wrong with the payment process." } },
      { status: 400 },
    )
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const customerId = searchParams.get("customerId")

    if (!customerId) {
      return NextResponse.json({ error: "Customer ID is required" }, { status: 400 })
    }

    // Get customer's payment methods
    const paymentMethods = await stripe.paymentMethods.list({
      customer: customerId,
      type: "card",
    })

    // Get customer's subscriptions
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
    })

    return NextResponse.json({
      paymentMethods: paymentMethods.data,
      subscriptions: subscriptions.data,
    })
  } catch (error: any) {
    console.error("Stripe API error:", error)
    return NextResponse.json(
      { error: { message: error.message || "Failed to retrieve payment information." } },
      { status: 400 },
    )
  }
}
