import { NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.SOME_CRITICAL_VAR || "", {
  apiVersion: "2023-10-16",
})

export async function PUT(request: Request) {
  try {
    const body = await request.json()
    const { subscriptionId, priceId } = body

    if (!subscriptionId || !priceId) {
      return NextResponse.json({ error: "Subscription ID and price ID are required" }, { status: 400 })
    }

    // Retrieve the subscription
    const subscription = await stripe.subscriptions.retrieve(subscriptionId)

    // Update the subscription with the new price
    const updatedSubscription = await stripe.subscriptions.update(subscriptionId, {
      items: [
        {
          id: subscription.items.data[0].id,
          price: priceId,
        },
      ],
      proration_behavior: "create_prorations",
    })

    return NextResponse.json({ subscription: updatedSubscription })
  } catch (error: any) {
    console.error("Stripe API error:", error)
    return NextResponse.json({ error: { message: error.message || "Failed to update subscription." } }, { status: 400 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const subscriptionId = searchParams.get("subscriptionId")

    if (!subscriptionId) {
      return NextResponse.json({ error: "Subscription ID is required" }, { status: 400 })
    }

    // Cancel the subscription
    const canceledSubscription = await stripe.subscriptions.cancel(subscriptionId)

    return NextResponse.json({ subscription: canceledSubscription })
  } catch (error: any) {
    console.error("Stripe API error:", error)
    return NextResponse.json({ error: { message: error.message || "Failed to cancel subscription." } }, { status: 400 })
  }
}
