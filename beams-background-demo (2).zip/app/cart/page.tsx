"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Minus, Plus, Trash2 } from "lucide-react"
import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

// Mock cart items
const initialCartItems = [
  {
    id: "1",
    name: "GMT-Master II 'Batman'",
    brand: "Rolex",
    price: 14950,
    quantity: 1,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
  {
    id: "2",
    name: "Royal Oak Offshore",
    brand: "Audemars Piguet",
    price: 45900,
    quantity: 1,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
]

export default function CartPage() {
  const [cartItems, setCartItems] = useState(initialCartItems)

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity < 1) return
    setCartItems((items) => items.map((item) => (item.id === id ? { ...item, quantity: newQuantity } : item)))
  }

  const removeItem = (id: string) => {
    setCartItems((items) => items.filter((item) => item.id !== id))
  }

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = 50
  const tax = subtotal * 0.08
  const total = subtotal + shipping + tax

  return (
    <SiteLayout>
      <div className="container mx-auto px-4 py-8">
        <Link href="/collection" className="inline-flex items-center text-sm text-white/70 hover:text-white mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Continue Shopping
        </Link>

        <h1 className="text-3xl font-bold text-white mb-8">Shopping Bag</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {cartItems.length > 0 ? (
              <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all duration-300">
                <div className="p-6">
                  {cartItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex flex-col sm:flex-row items-start sm:items-center py-6 border-b border-white/10 last:border-0"
                    >
                      <div className="w-full sm:w-20 h-20 relative mb-4 sm:mb-0">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          fill
                          className="object-cover rounded"
                        />
                      </div>

                      <div className="flex-1 sm:ml-6">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                          <div>
                            <div className="text-sm text-white/70">{item.brand}</div>
                            <h3 className="text-lg font-medium text-white">{item.name}</h3>
                          </div>
                          <div className="text-lg font-semibold text-white mt-2 sm:mt-0">
                            ${(item.price * item.quantity).toLocaleString()}
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-4">
                          <div className="flex items-center">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8 rounded-l-md border-white/20 text-white"
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <div className="h-8 w-10 flex items-center justify-center border-y border-white/20 text-white text-sm">
                              {item.quantity}
                            </div>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8 rounded-r-md border-white/20 text-white"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>

                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-white/70 hover:text-white"
                            onClick={() => removeItem(item.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Remove
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-12 text-center">
                <h2 className="text-xl font-medium text-white mb-4">Your shopping bag is empty</h2>
                <p className="text-white/70 mb-6">Discover our collection and add some timepieces to your bag.</p>
                <Button asChild>
                  <Link href="/collection">Browse Collection</Link>
                </Button>
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-6 hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all duration-300">
              <h2 className="text-xl font-semibold text-white mb-6">Order Summary</h2>

              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-white/80">
                  <span>Subtotal</span>
                  <span>${subtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-white/80">
                  <span>Shipping</span>
                  <span>${shipping.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-white/80">
                  <span>Tax</span>
                  <span>${tax.toLocaleString()}</span>
                </div>
                <div className="border-t border-white/10 pt-4 flex justify-between text-white font-semibold">
                  <span>Total</span>
                  <span>${total.toLocaleString()}</span>
                </div>
              </div>

              <div className="mb-6">
                <label htmlFor="promo" className="block text-sm font-medium text-white mb-2">
                  Promo Code
                </label>
                <div className="flex">
                  <Input
                    id="promo"
                    placeholder="Enter code"
                    className="flex-1 bg-black/20 border border-white/20 rounded-l-md text-white placeholder:text-white/50 focus-visible:ring-white/30"
                  />
                  <Button className="rounded-l-none bg-white text-black hover:bg-white/90">Apply</Button>
                </div>
              </div>

              <Button className="w-full bg-white text-black hover:bg-white/90">Proceed to Checkout</Button>
            </div>
          </div>
        </div>
      </div>
    </SiteLayout>
  )
}
