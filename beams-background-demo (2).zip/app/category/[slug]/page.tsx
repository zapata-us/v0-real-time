import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { SiteLayout } from "@/components/site-layout"
import { ProductGrid } from "@/components/product-grid"

export default function CategoryPage({ params }: { params: { slug: string } }) {
  // Convert slug to display name (e.g., "limited-edition" -> "Limited Edition")
  const categoryName = params.slug
    .split("-")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")

  return (
    <SiteLayout>
      <div className="container mx-auto px-4 py-8">
        <Link href="/" className="inline-flex items-center text-sm text-white/70 hover:text-white mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        <div className="mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">{categoryName} Watches</h1>
          <p className="text-white/70 max-w-3xl">
            Discover our curated collection of {categoryName.toLowerCase()} timepieces, crafted with precision and
            designed for those who appreciate exceptional quality.
          </p>
        </div>

        <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-6 mb-12">
          <div className="flex flex-wrap gap-4">
            <div className="text-sm text-white/80">Filter by:</div>
            <div className="flex flex-wrap gap-2">
              <button className="px-3 py-1 text-sm rounded-full bg-white/10 text-white hover:bg-white/20">Price</button>
              <button className="px-3 py-1 text-sm rounded-full bg-white/10 text-white hover:bg-white/20">Brand</button>
              <button className="px-3 py-1 text-sm rounded-full bg-white/10 text-white hover:bg-white/20">
                Material
              </button>
              <button className="px-3 py-1 text-sm rounded-full bg-white/10 text-white hover:bg-white/20">
                Movement
              </button>
              <button className="px-3 py-1 text-sm rounded-full bg-white/10 text-white hover:bg-white/20">
                Features
              </button>
            </div>
          </div>
        </div>

        <ProductGrid />
      </div>
    </SiteLayout>
  )
}
