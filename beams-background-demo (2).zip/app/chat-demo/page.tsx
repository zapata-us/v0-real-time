"use client"

import { useState } from "react"
import WatchesChat from "@/components/watches-chat"
import { Button } from "@/components/ui/button"
import { Clock, Shield, Truck, CreditCard } from "lucide-react"

export default function ChatDemo() {
  const [showChat, setShowChat] = useState(true)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-4">Watches.io Live Chat</h1>
        <p className="text-gray-300 mb-6">
          A real-time luxury watch concierge service for high-end timepiece inquiries.
        </p>

        {!showChat && (
          <Button onClick={() => setShowChat(true)} className="bg-blue-500 hover:bg-blue-600 text-white">
            Open Live Chat
          </Button>
        )}
      </div>

      <div className="w-full max-w-4xl bg-white rounded-lg shadow-xl p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Featured Watch</h2>
        <div className="flex flex-col md:flex-row gap-6">
          <div className="w-full md:w-1/2">
            <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
              <img
                src="/placeholder.svg?height=400&width=400&text=Patek+Philippe+Aquanaut"
                alt="Patek Philippe Aquanaut 5168G-001"
                className="max-w-full max-h-full object-contain"
              />
            </div>
          </div>
          <div className="w-full md:w-1/2">
            <h3 className="text-lg font-medium">Patek Philippe Aquanaut</h3>
            <p className="text-sm text-gray-500 mb-2">Ref. 5168G-001</p>
            <div className="flex items-center mb-4">
              <p className="text-2xl font-bold">$85,500</p>
              <span className="ml-2 px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full">In Stock</span>
            </div>
            <div className="space-y-4">
              <p className="text-gray-700">
                The Patek Philippe Aquanaut 5168G-001 features a 42.2mm white gold case with a stunning blue dial and
                matching blue composite strap.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Self-winding mechanical movement</li>
                <li>• Caliber 324 S C</li>
                <li>• Date display at 3 o'clock</li>
                <li>• Water resistant to 120m</li>
                <li>• Sapphire crystal case back</li>
              </ul>

              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="flex items-center text-sm text-gray-600">
                  <Shield className="h-4 w-4 mr-2 text-blue-500" />
                  <span>Authenticity Guaranteed</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Truck className="h-4 w-4 mr-2 text-blue-500" />
                  <span>Free Insured Shipping</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Clock className="h-4 w-4 mr-2 text-blue-500" />
                  <span>2-Year Warranty</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <CreditCard className="h-4 w-4 mr-2 text-blue-500" />
                  <span>Secure Payment</span>
                </div>
              </div>

              <div className="pt-4">
                <Button onClick={() => setShowChat(true)} className="w-full bg-blue-500 hover:bg-blue-600 text-white">
                  Chat with a Specialist
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showChat && <WatchesChat />}
    </div>
  )
}
