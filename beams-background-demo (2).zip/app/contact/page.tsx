"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Mail, Phone, MapPin, Send } from "lucide-react"
import { motion } from "framer-motion"
import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function ContactPage() {
  const [formState, setFormState] = useState({
    name: "Danny Z",
    email: "",
    phone: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormState((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setSubmitSuccess(true)

      // Reset form after showing success message
      setTimeout(() => {
        setSubmitSuccess(false)
        setFormState({
          name: "",
          email: "",
          phone: "",
          subject: "",
          message: "",
        })
      }, 3000)
    }, 1500)
  }

  const sectionVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeOut",
      },
    },
  }

  return (
    <SiteLayout>
      <div className="px-4 sm:px-6 py-4 sm:py-6">
        <div className="mb-8 mt-[13%] backdrop-blur-sm bg-black/10 rounded-2xl p-3 inline-flex items-center text-sm text-white/80 hover:text-white transition-colors duration-200 shadow-sm">
          <Link href="/" className="inline-flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </div>

        <div className="mb-12 backdrop-blur-md bg-black/10 p-6 rounded-2xl border border-white/5 shadow-xl">
          <h1 className="text-3xl font-bold text-white mb-4 tracking-tight">Contact Us</h1>
          <p className="text-white/70 max-w-3xl mb-6">
            Have questions about our timepieces or services? Our team of experts is ready to assist you.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Contact Form */}
          <motion.section
            className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden p-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={sectionVariants}
          >
            <h2 className="text-xl font-bold text-white mb-6">Send Us a Message</h2>

            {submitSuccess ? (
              <div className="bg-emerald-900/30 border border-emerald-500/50 rounded-lg p-4 text-white">
                <p className="font-medium">Thank you for your message!</p>
                <p className="text-white/80 text-sm mt-1">We'll get back to you as soon as possible.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-white mb-1">
                      Your Name
                    </label>
                    <Input
                      id="name"
                      name="name"
                      onChange={handleChange}
                      required
                      className="bg-black/30 border-white/20 text-white placeholder:text-white/50"
                      placeholder="Danny Z"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-white mb-1">
                      Email Address
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formState.email}
                      onChange={handleChange}
                      required
                      className="bg-black/30 border-white/20 text-white placeholder:text-white/50"
                      placeholder="danny@example.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-white mb-1">
                      Phone Number (Optional)
                    </label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      value={formState.phone}
                      onChange={handleChange}
                      className="bg-black/30 border-white/20 text-white placeholder:text-white/50"
                      placeholder="+1 (305) 123-4567"
                    />
                  </div>
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-white mb-1">
                      Subject
                    </label>
                    <Input
                      id="subject"
                      name="subject"
                      value={formState.subject}
                      onChange={handleChange}
                      required
                      className="bg-black/30 border-white/20 text-white placeholder:text-white/50"
                      placeholder="Inquiry about Rolex watches"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-white mb-1">
                    Your Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formState.message}
                    onChange={handleChange}
                    required
                    className="min-h-[120px] bg-black/30 border-white/20 text-white placeholder:text-white/50"
                    placeholder="Please provide details about your inquiry..."
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full backdrop-blur-md bg-white text-black hover:bg-white/90"
                >
                  {isSubmitting ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-black border-t-transparent"></div>
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Send Message
                    </>
                  )}
                </Button>
              </form>
            )}
          </motion.section>

          {/* Contact Information */}
          <motion.section
            className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden p-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
            variants={sectionVariants}
          >
            <h2 className="text-xl font-bold text-white mb-6">Contact Information</h2>

            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-4">
                  <Mail className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-medium">Email</h3>
                  <a
                    href="mailto:info@realtimejewelers.com"
                    className="text-white/70 hover:text-white transition-colors"
                  >
                    info@realtimejewelers.com
                  </a>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-4">
                  <Phone className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-medium">Phone</h3>
                  <a href="tel:+13057663058" className="text-white/70 hover:text-white transition-colors block">
                    +1 (305) 766-3058
                  </a>
                  <a href="tel:+17862382082" className="text-white/70 hover:text-white transition-colors block mt-1">
                    +1 (786) 238-2082
                  </a>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-4">
                  <MapPin className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-medium">Location</h3>
                  <address className="text-white/70 not-italic">
                    36 NE 1st St
                    <br />
                    Miami, FL 33132
                    <br />
                    United States
                  </address>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="text-white font-medium mb-2">Business Hours</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-white/70">Monday - Friday</div>
                  <div className="text-white">9 AM TO 6PM</div>

                  <div className="text-white/70">Saturday</div>
                  <div className="text-white">11:00 AM - 5:00 PM</div>

                  <div className="text-white/70">Sunday</div>
                  <div className="text-white">Closed</div>
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="mt-6 border border-white/10 rounded-lg overflow-hidden h-[200px] w-full">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3592.6978371493!2d-80.19196492394726!3d25.77631770987613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88d9b69c4af9a4d1%3A0x3ea5a8cc3f8d659e!2s36%20NE%201st%20St%2C%20Miami%2C%20FL%2033132!5e0!3m2!1sen!2sus!4v1712000000000!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Real Time Jewelers Location"
                className="backdrop-blur-sm bg-black/30"
              ></iframe>
            </div>
          </motion.section>
        </div>
      </div>
    </SiteLayout>
  )
}
