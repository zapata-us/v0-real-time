"use client"

import { Switch } from "@/components/ui/switch"

import { Input } from "@/components/ui/input"

import { Label } from "@/components/ui/label"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  CreditCard,
  FileText,
  User,
  LogOut,
  Calendar,
  CheckCircle,
  AlertCircle,
  Clock,
  BarChart3,
  Search,
  Bell,
  Shield,
  Download,
} from "lucide-react"
import { format } from "date-fns"

export default function DashboardPage() {
  const router = useRouter()
  const { user, logout } = useAuth()
  const [activeTab, setActiveTab] = useState("overview")

  // Redirect if not authenticated
  if (!user) {
    router.push("/login")
    return null
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/10 text-green-500 border-green-500/20"
      case "trialing":
        return "bg-blue-500/10 text-blue-500 border-blue-500/20"
      case "past_due":
        return "bg-amber-500/10 text-amber-500 border-amber-500/20"
      case "canceled":
        return "bg-red-500/10 text-red-500 border-red-500/20"
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/20"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4" />
      case "trialing":
        return <Clock className="h-4 w-4" />
      case "past_due":
        return <AlertCircle className="h-4 w-4" />
      case "canceled":
        return <AlertCircle className="h-4 w-4" />
      default:
        return null
    }
  }

  // Mock billing history
  const billingHistory = [
    {
      id: "INV-001",
      date: "2023-05-15",
      amount: user.billingCycle === "annual" ? 499.99 : 49.99,
      status: "paid",
    },
    {
      id: "INV-002",
      date: "2023-04-15",
      amount: user.billingCycle === "annual" ? 499.99 : 49.99,
      status: "paid",
    },
    {
      id: "INV-003",
      date: "2023-03-15",
      amount: user.billingCycle === "annual" ? 499.99 : 49.99,
      status: "paid",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto p-4">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="w-full md:w-64 shrink-0">
            <Card className="bg-gray-800/50 border-gray-700 sticky top-4">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-stone-400 flex items-center justify-center text-black font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <CardTitle className="text-white">{user.name}</CardTitle>
                    <CardDescription className="text-gray-400">{user.email}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <nav className="space-y-1 px-2">
                  <Button
                    variant="ghost"
                    className={`w-full justify-start ${
                      activeTab === "overview"
                        ? "bg-gray-700/50 text-white"
                        : "text-gray-400 hover:text-white hover:bg-gray-700/30"
                    }`}
                    onClick={() => setActiveTab("overview")}
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Overview
                  </Button>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start ${
                      activeTab === "billing"
                        ? "bg-gray-700/50 text-white"
                        : "text-gray-400 hover:text-white hover:bg-gray-700/30"
                    }`}
                    onClick={() => setActiveTab("billing")}
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Billing
                  </Button>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start ${
                      activeTab === "account"
                        ? "bg-gray-700/50 text-white"
                        : "text-gray-400 hover:text-white hover:bg-gray-700/30"
                    }`}
                    onClick={() => setActiveTab("account")}
                  >
                    <User className="h-4 w-4 mr-2" />
                    Account
                  </Button>
                </nav>
              </CardContent>
              <CardFooter className="pt-4">
                <Button
                  variant="ghost"
                  className="w-full justify-start text-gray-400 hover:text-white hover:bg-gray-700/30"
                  onClick={() => logout()}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </Button>
              </CardFooter>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === "overview" && (
              <div className="space-y-6">
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Subscription Overview</CardTitle>
                    <CardDescription className="text-gray-400">
                      Your current subscription details and status
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-medium text-white">
                            {user.subscriptionTier?.charAt(0).toUpperCase() + user.subscriptionTier?.slice(1)} Plan
                          </h3>
                          <p className="text-gray-400">
                            {user.billingCycle === "annual" ? "Annual" : "Monthly"} billing
                          </p>
                        </div>
                        <Badge className={getStatusColor(user.subscriptionStatus)}>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(user.subscriptionStatus)}
                            <span>
                              {user.subscriptionStatus.charAt(0).toUpperCase() +
                                user.subscriptionStatus.slice(1).replace("_", " ")}
                            </span>
                          </div>
                        </Badge>
                      </div>

                      {user.subscriptionRenewalDate && (
                        <div className="flex items-center text-sm text-gray-400">
                          <Calendar className="h-4 w-4 mr-2 text-stone-400" />
                          Renews on {format(new Date(user.subscriptionRenewalDate), "MMMM d, yyyy")}
                        </div>
                      )}

                      <Separator className="bg-gray-700" />

                      <div className="space-y-2">
                        <h4 className="font-medium text-white">Features Included:</h4>
                        <ul className="space-y-1">
                          {user.subscriptionTier === "premium" ? (
                            <>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Unlimited Rolex Serial Number Lookup</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Real-time Market Price Data</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Advanced Authentication Guides</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Dealer Network Access</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Authentication Certificates</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Price Alerts</span>
                              </li>
                            </>
                          ) : user.subscriptionTier === "basic" ? (
                            <>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Rolex Serial Number Lookup (Limited)</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Basic Market Price Data</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Authentication Guides</span>
                              </li>
                            </>
                          ) : user.subscriptionTier === "business" ? (
                            <>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Unlimited Serial Number Lookup (All Brands)</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Real-time Market Price Data</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Advanced Authentication Guides</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Dealer Network Access</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Unlimited Authentication Certificates</span>
                              </li>
                              <li className="flex items-start text-sm">
                                <CheckCircle className="h-4 w-4 text-stone-400 mr-2 mt-0.5 shrink-0" />
                                <span className="text-gray-300">Price Alerts</span>
                              </li>
                            </>
                          ) : (
                            <li className="text-gray-400">No active subscription</li>
                          )}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className="bg-stone-400 hover:bg-stone-500 text-black"
                      onClick={() => router.push("/subscribe")}
                    >
                      {user.subscriptionTier ? "Manage Subscription" : "Subscribe Now"}
                    </Button>
                  </CardFooter>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Quick Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button
                        variant="outline"
                        className="w-full justify-start text-white border-gray-600 hover:bg-gray-700/50"
                      >
                        <Search className="h-4 w-4 mr-2 text-stone-400" />
                        Serial Number Lookup
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-white border-gray-600 hover:bg-gray-700/50"
                      >
                        <BarChart3 className="h-4 w-4 mr-2 text-stone-400" />
                        Market Price Analysis
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-white border-gray-600 hover:bg-gray-700/50"
                      >
                        <Bell className="h-4 w-4 mr-2 text-stone-400" />
                        Set Price Alert
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-white border-gray-600 hover:bg-gray-700/50"
                      >
                        <Shield className="h-4 w-4 mr-2 text-stone-400" />
                        Authentication Guide
                      </Button>
                    </CardContent>
                  </Card>

                  <Card className="bg-gray-800/50 border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-white">Recent Activity</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-full bg-stone-400/20 flex items-center justify-center shrink-0">
                            <Search className="h-4 w-4 text-stone-400" />
                          </div>
                          <div>
                            <p className="text-sm text-white">Serial Number Lookup</p>
                            <p className="text-xs text-gray-400">Rolex Submariner 116610LN</p>
                            <p className="text-xs text-gray-500">2 days ago</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-full bg-stone-400/20 flex items-center justify-center shrink-0">
                            <BarChart3 className="h-4 w-4 text-stone-400" />
                          </div>
                          <div>
                            <p className="text-sm text-white">Market Price Check</p>
                            <p className="text-xs text-gray-400">Patek Philippe Nautilus</p>
                            <p className="text-xs text-gray-500">5 days ago</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-full bg-stone-400/20 flex items-center justify-center shrink-0">
                            <Bell className="h-4 w-4 text-stone-400" />
                          </div>
                          <div>
                            <p className="text-sm text-white">Price Alert Set</p>
                            <p className="text-xs text-gray-400">Audemars Piguet Royal Oak</p>
                            <p className="text-xs text-gray-500">1 week ago</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {activeTab === "billing" && (
              <div className="space-y-6">
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Payment Method</CardTitle>
                    <CardDescription className="text-gray-400">
                      Manage your payment details and billing preferences
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-700/30 p-4 rounded-lg flex items-start gap-4">
                      <CreditCard className="h-10 w-10 text-stone-400 shrink-0" />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-white font-medium">Visa ending in 4242</p>
                            <p className="text-gray-400 text-sm">Expires 12/25</p>
                          </div>
                          <Badge className="bg-green-500/10 text-green-500 border-green-500/20">Default</Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col space-y-2 items-start">
                    <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-700/50">
                      Update Payment Method
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Billing History</CardTitle>
                    <CardDescription className="text-gray-400">View and download your past invoices</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {billingHistory.map((invoice) => (
                        <div
                          key={invoice.id}
                          className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg"
                        >
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-full bg-stone-400/20 flex items-center justify-center shrink-0">
                              <FileText className="h-4 w-4 text-stone-400" />
                            </div>
                            <div>
                              <p className="text-sm text-white">{invoice.id}</p>
                              <p className="text-xs text-gray-400">{format(new Date(invoice.date), "MMMM d, yyyy")}</p>
                              <p className="text-xs text-gray-400">${invoice.amount.toFixed(2)}</p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-stone-400 hover:text-stone-300 hover:bg-gray-700/50"
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Subscription Management</CardTitle>
                    <CardDescription className="text-gray-400">Change or cancel your subscription</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gray-700/30 p-4 rounded-lg">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="text-white font-medium">Current Plan</h3>
                        <Badge className={getStatusColor(user.subscriptionStatus)}>
                          <div className="flex items-center gap-1">
                            {getStatusIcon(user.subscriptionStatus)}
                            <span>
                              {user.subscriptionStatus.charAt(0).toUpperCase() +
                                user.subscriptionStatus.slice(1).replace("_", " ")}
                            </span>
                          </div>
                        </Badge>
                      </div>
                      <p className="text-gray-400 mb-4">
                        {user.subscriptionTier?.charAt(0).toUpperCase() + user.subscriptionTier?.slice(1)} Plan (
                        {user.billingCycle === "annual" ? "Annual" : "Monthly"})
                      </p>
                      <div className="flex gap-2">
                        <Button
                          className="bg-stone-400 hover:bg-stone-500 text-black"
                          onClick={() => router.push("/subscribe")}
                        >
                          Change Plan
                        </Button>
                        <Button variant="outline" className="text-white border-gray-600 hover:bg-gray-700/50">
                          Cancel Subscription
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === "account" && (
              <div className="space-y-6">
                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Account Information</CardTitle>
                    <CardDescription className="text-gray-400">Manage your personal details</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="text-white">
                          Full Name
                        </Label>
                        <Input
                          id="name"
                          defaultValue={user.name}
                          className="bg-gray-700/50 border-gray-600 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-white">
                          Email Address
                        </Label>
                        <Input
                          id="email"
                          defaultValue={user.email}
                          className="bg-gray-700/50 border-gray-600 text-white"
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="bg-stone-400 hover:bg-stone-500 text-black">Save Changes</Button>
                  </CardFooter>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Security</CardTitle>
                    <CardDescription className="text-gray-400">
                      Update your password and security settings
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword" className="text-white">
                        Current Password
                      </Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        className="bg-gray-700/50 border-gray-600 text-white"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="newPassword" className="text-white">
                          New Password
                        </Label>
                        <Input id="newPassword" type="password" className="bg-gray-700/50 border-gray-600 text-white" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword" className="text-white">
                          Confirm New Password
                        </Label>
                        <Input
                          id="confirmPassword"
                          type="password"
                          className="bg-gray-700/50 border-gray-600 text-white"
                        />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="bg-stone-400 hover:bg-stone-500 text-black">Update Password</Button>
                  </CardFooter>
                </Card>

                <Card className="bg-gray-800/50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-white">Preferences</CardTitle>
                    <CardDescription className="text-gray-400">
                      Manage your notification and communication preferences
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-white">Email Notifications</Label>
                        <p className="text-xs text-gray-400">
                          Receive email updates about your subscription and new features
                        </p>
                      </div>
                      <Switch className="data-[state=checked]:bg-stone-400" defaultChecked />
                    </div>
                    <Separator className="bg-gray-700" />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-white">Price Alerts</Label>
                        <p className="text-xs text-gray-400">
                          Receive notifications when watch prices change significantly
                        </p>
                      </div>
                      <Switch className="data-[state=checked]:bg-stone-400" defaultChecked />
                    </div>
                    <Separator className="bg-gray-700" />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-white">Marketing Communications</Label>
                        <p className="text-xs text-gray-400">Receive promotional offers and marketing materials</p>
                      </div>
                      <Switch className="data-[state=checked]:bg-stone-400" />
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="bg-stone-400 hover:bg-stone-500 text-black">Save Preferences</Button>
                  </CardFooter>
                </Card>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
