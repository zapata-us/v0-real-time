"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { StripeProvider } from "@/lib/stripe-context"
import { PaymentMethodsManager } from "@/components/payment-methods-manager"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function PaymentMethodsPage() {
  const router = useRouter()
  const { user } = useAuth()
  const [customerId, setCustomerId] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchCustomerId = async () => {
      try {
        // In a real app, you would fetch this from your backend
        // For this demo, we'll simulate it
        setTimeout(() => {
          setCustomerId("cus_mock123456")
          setIsLoading(false)
        }, 1000)
      } catch (error) {
        console.error("Error fetching customer ID:", error)
        setIsLoading(false)
      }
    }

    if (!user) {
      router.push("/login")
      return
    }

    fetchCustomerId()
  }, [user, router])

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black p-4">
      <div className="container mx-auto max-w-4xl py-8">
        <div className="mb-8">
          <Button
            onClick={() => router.back()}
            variant="outline"
            className="border-gray-700 text-white hover:bg-gray-800"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Payment Methods</h1>
          <p className="text-gray-400 max-w-xl mx-auto">
            Manage your payment methods and billing information securely.
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <div className="h-64 bg-gray-800/50 animate-pulse rounded-lg"></div>
          </div>
        ) : customerId ? (
          <StripeProvider>
            <PaymentMethodsManager customerId={customerId} />
          </StripeProvider>
        ) : (
          <div className="text-center py-12 bg-gray-800/50 rounded-lg border border-gray-700">
            <h2 className="text-xl font-medium text-white mb-2">No Payment Methods Found</h2>
            <p className="text-gray-400 mb-6">
              You don't have any payment methods set up yet. Add a payment method to manage your subscriptions.
            </p>
            <Button onClick={() => router.push("/subscribe")} className="bg-stone-400 hover:bg-stone-500 text-black">
              Subscribe Now
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
