import { Skeleton } from "@/components/ui/skeleton"
import { SiteLayout } from "@/components/site-layout"

export default function Loading() {
  return (
    <SiteLayout>
      <div className="container mx-auto px-4 py-8 mt-[13%]">
        {/* Back button */}
        <div className="flex items-center mb-8">
          <Skeleton className="h-6 w-24 bg-white/10" />
        </div>

        {/* Header */}
        <div className="mb-12">
          <Skeleton className="h-10 w-64 mb-4 bg-white/10" />
          <Skeleton className="h-5 w-full max-w-2xl mb-2 bg-white/10" />
          <Skeleton className="h-5 w-3/4 max-w-xl mb-6 bg-white/10" />

          {/* Search and filter bar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Skeleton className="h-12 w-full bg-white/10 rounded-full" />
            <Skeleton className="h-12 w-32 bg-white/10 rounded-md" />
          </div>
        </div>

        {/* Products grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="rounded-xl overflow-hidden bg-white/5 backdrop-blur-sm">
              <Skeleton className="aspect-square w-full bg-white/10" />
              <div className="p-4">
                <Skeleton className="h-6 w-3/4 mb-2 bg-white/10" />
                <Skeleton className="h-4 w-1/2 mb-4 bg-white/10" />
                <Skeleton className="h-5 w-1/3 bg-white/10" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </SiteLayout>
  )
}
