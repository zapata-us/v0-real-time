"use client"

import type React from "react"

import { useState, useEffect, useCallback, useMemo } from "react"
import Link from "next/link"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { useRouter } from "next/navigation"
import { ArrowLeft, Search, Filter, X, ChevronDown, ChevronUp, RefreshCw, Check, ArrowUpRight } from "lucide-react"

import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { fetchProducts } from "@/lib/product-service"
import type { ProductType } from "@/types/product"
import { getAllBrands } from "@/lib/brand-service"

// Rolex serial number database - simplified to most recent years only
const SERIAL_YEAR_DATABASE = [
  { serial_number: "Random", year: 2018 },
  { serial_number: "Random", year: 2017 },
  { serial_number: "Random", year: 2016 },
  { serial_number: "Random", year: 2015 },
  { serial_number: "G", year: 2010 },
  { serial_number: "V", year: 2009 },
  { serial_number: "M OR V", year: 2008 },
  // Add more as needed
]

export default function CollectionPage() {
  const router = useRouter()

  const [products, setProducts] = useState<ProductType[]>([])
  const [filteredProducts, setFilteredProducts] = useState<ProductType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [activeFilters, setActiveFilters] = useState<{
    brands: string[]
    materials: string[]
    colors: string[]
    priceRange: [number | null, number | null]
  }>({
    brands: [],
    materials: [],
    colors: [],
    priceRange: [null, null],
  })

  const [expandedSections, setExpandedSections] = useState({
    brands: true,
    materials: false,
    colors: false,
    price: false,
  })

  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(false)
  const ITEMS_PER_PAGE = 8

  const brands = ["Rolex", "Audemars Piguet", "Patek Philippe", "Omega", "Cartier", "Hublot", "TAG Heuer"]
  const materials = ["Stainless Steel", "Yellow Gold", "Rose Gold", "White Gold", "Titanium", "Ceramic", "Platinum"]
  const colors = ["Black", "Blue", "Green", "White", "Silver", "Gold", "Brown"]

  const [isImageLoading, setIsImageLoading] = useState<Record<string, boolean>>({})
  const [serialNumber, setSerialNumber] = useState("")
  const [searchResult, setSearchResult] = useState<{ year: number; match: string; exact: boolean } | null>(null)
  const [isSearching, setIsSearching] = useState(false)
  const [brandsData] = useState(getAllBrands())

  // Collaborator data with actual logos
  const collaborators = [
    {
      name: "IWJG",
      logo: "/images/IWJG-REAL-TIME.png",
      width: 200,
      height: 70,
    },
    {
      name: "JIS",
      logo: "/images/JIS-01.png",
      width: 120,
      height: 50,
    },
    {
      name: "Original Vintage",
      logo: "/images/ORIGINALVINTAGE-REAL-TIME.png",
      width: 200,
      height: 70,
    },
    {
      name: "JCK",
      logo: "/images/jck-logo-white.png",
      width: 150,
      height: 50,
    },
    {
      name: "NYC JAWS",
      logo: "/images/nycjaws-logo-white.svg",
      width: 180,
      height: 50,
    },
  ]

  // Load products on mount
  useEffect(() => {
    loadProducts()
  }, [])

  // Apply filters when they change
  useEffect(() => {
    applyFilters()
  }, [products, searchQuery, activeFilters])

  // Load products from API
  const loadProducts = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const data = await fetchProducts()
      setProducts(data)
    } catch (err) {
      console.error("Failed to load products:", err)
      setError("Failed to load products. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  // Apply filters to products
  const applyFilters = useCallback(() => {
    if (products.length === 0) return

    let result = [...products]

    // Apply search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (product) =>
          product.name.toLowerCase().includes(query) ||
          product.brand.toLowerCase().includes(query) ||
          (product.reference && product.reference.toLowerCase().includes(query)),
      )
    }

    // Apply brand filter
    if (activeFilters.brands.length > 0) {
      result = result.filter((product) => activeFilters.brands.includes(product.brand))
    }

    // Apply material filter
    if (activeFilters.materials.length > 0) {
      result = result.filter(
        (product) => product.caseMaterial && activeFilters.materials.includes(product.caseMaterial),
      )
    }

    // Apply color filter
    if (activeFilters.colors.length > 0) {
      result = result.filter((product) => product.dialColor && activeFilters.colors.includes(product.dialColor))
    }

    // Apply price range filter
    const [minPrice, maxPrice] = activeFilters.priceRange
    if (minPrice !== null) {
      result = result.filter((product) => product.price >= minPrice)
    }
    if (maxPrice !== null) {
      result = result.filter((product) => product.price <= maxPrice)
    }

    setFilteredProducts(result)
    setHasMore(result.length > page * ITEMS_PER_PAGE)
  }, [products, searchQuery, activeFilters, page, ITEMS_PER_PAGE])

  // Toggle filter section
  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  // Toggle filter value
  const toggleFilter = (type: "brands" | "materials" | "colors", value: string) => {
    setActiveFilters((prev) => {
      const current = [...prev[type]]
      const index = current.indexOf(value)

      if (index === -1) {
        current.push(value)
      } else {
        current.splice(index, 1)
      }

      return {
        ...prev,
        [type]: current,
      }
    })

    // Reset to first page when filter changes
    setPage(1)
  }

  // Set price range
  const setPriceRange = (min: number | null, max: number | null) => {
    setActiveFilters((prev) => ({
      ...prev,
      priceRange: [min, max],
    }))

    // Reset to first page when filter changes
    setPage(1)
  }

  // Reset all filters
  const resetFilters = () => {
    setActiveFilters({
      brands: [],
      materials: [],
      colors: [],
      priceRange: [null, null],
    })
    setSearchQuery("")
    setPage(1)
  }

  // Load more products
  const loadMore = () => {
    setPage((prev) => prev + 1)
  }

  // Get current page of products
  const currentProducts = filteredProducts.slice(0, page * ITEMS_PER_PAGE)

  // Check if any filters are active
  const hasActiveFilters =
    activeFilters.brands.length > 0 ||
    activeFilters.materials.length > 0 ||
    activeFilters.colors.length > 0 ||
    activeFilters.priceRange[0] !== null ||
    activeFilters.priceRange[1] !== null ||
    searchQuery.trim() !== ""

  // Handle image load state
  const handleImageLoad = (brandId: string) => {
    setIsImageLoading((prev) => ({
      ...prev,
      [brandId]: false,
    }))
  }

  // Handle image load error
  const handleImageError = (brandId: string) => {
    setIsImageLoading((prev) => ({
      ...prev,
      [brandId]: false,
    }))
    // Error is handled by the onError attribute on the Image component
  }

  // Function to normalize serial number for comparison
  const normalizeSerial = (serial: string): string => {
    return serial.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()
  }

  // Function to check if a serial number matches a pattern
  const matchesPattern = (input: string, pattern: string): boolean => {
    // Handle empty patterns
    if (!pattern) return false

    // Handle "Random" pattern (2011-2018)
    if (pattern.toLowerCase() === "random") {
      // Check if input is 8 digits (typical for random serials)
      return /^\d{8}$/.test(normalizeSerial(input))
    }

    // Handle patterns with "OR" (e.g., "M OR V")
    if (pattern.includes("OR")) {
      const options = pattern.split("OR").map((opt) => normalizeSerial(opt.trim()))
      const normalizedInput = normalizeSerial(input)

      // Check if input starts with any of the options
      return options.some((opt) => normalizedInput.startsWith(opt))
    }

    // Handle numeric ranges (e.g., "9,400,000")
    if (/[\d,]+/.test(pattern)) {
      const patternNum = Number.parseInt(pattern.replace(/,/g, ""))
      const inputNum = Number.parseInt(normalizeSerial(input))

      // If both can be parsed as numbers, compare them
      if (!isNaN(patternNum) && !isNaN(inputNum)) {
        return inputNum >= patternNum
      }
    }

    // Default: check if input starts with the pattern
    return normalizeSerial(input).startsWith(normalizeSerial(pattern))
  }

  // Function to find the best match for a serial number
  const findBestMatch = (input: string) => {
    const normalizedInput = normalizeSerial(input)

    // First try to find an exact match
    for (let i = 0; i < SERIAL_YEAR_DATABASE.length; i++) {
      const entry = SERIAL_YEAR_DATABASE[i]
      if (matchesPattern(normalizedInput, entry.serial_number)) {
        return {
          year: entry.year,
          match: entry.serial_number,
          exact: true,
        }
      }
    }

    // If no exact match, try to find the closest match based on first character
    if (normalizedInput.length > 0) {
      const firstChar = normalizedInput[0]

      // Check for letter matches (for modern Rolex serials)
      for (const entry of SERIAL_YEAR_DATABASE) {
        if (entry.serial_number && entry.serial_number.toUpperCase().startsWith(firstChar)) {
          return {
            year: entry.year,
            match: entry.serial_number,
            exact: false,
          }
        }
      }

      // Check for numeric ranges
      if (/^\d+$/.test(normalizedInput)) {
        const inputNum = Number.parseInt(normalizedInput)

        // Find the closest numeric range
        let closestEntry: any = null
        let smallestDiff = Number.MAX_SAFE_INTEGER

        for (const entry of SERIAL_YEAR_DATABASE) {
          if (/[\d,]+/.test(entry.serial_number)) {
            const entryNum = Number.parseInt(entry.serial_number.replace(/,/g, ""))
            if (!isNaN(entryNum)) {
              const diff = Math.abs(inputNum - entryNum)
              if (diff < smallestDiff) {
                smallestDiff = diff
                closestEntry = entry
              }
            }
          }
        }

        if (closestEntry) {
          return {
            year: closestEntry.year,
            match: closestEntry.serial_number,
            exact: false,
          }
        }
      }
    }

    // If still no match, return the most recent year for modern watches
    if (/^\d{8}$/.test(normalizedInput)) {
      return {
        year: 2018,
        match: "Random",
        exact: false,
      }
    }

    // If all else fails, return null
    return null
  }

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!serialNumber.trim()) return

    setIsSearching(true)

    // Simulate API delay
    setTimeout(() => {
      const result = findBestMatch(serialNumber)
      setSearchResult(result)
      setIsSearching(false)
    }, 300)
  }

  // Group years by decade for the reference table
  const decadeGroups = useMemo(() => {
    const groups: Record<string, typeof SERIAL_YEAR_DATABASE> = {}

    SERIAL_YEAR_DATABASE.forEach((entry) => {
      const decade = `${Math.floor(entry.year / 10) * 10}s`
      if (!groups[decade]) {
        groups[decade] = []
      }
      groups[decade].push(entry)
    })

    return Object.entries(groups).sort((a, b) => {
      // Sort decades in descending order (newest first)
      return Number.parseInt(b[0]) - Number.parseInt(a[0])
    })
  }, [])

  return (
    <SiteLayout>
      <div className="container mx-auto px-4 py-8 mt-[13%]">
        {/* Back button */}
        <Link href="/" className="inline-flex items-center text-sm text-white/70 hover:text-white mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Home
        </Link>

        {/* Header */}
            
        <div className="mb-12">
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-3xl font-bold text-white mb-4"
          >
            Luxury Timepiece Marketplace
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-white/70 mb-6 max-w-2xl"
          >
            Explore our curated selection of premium watches from the world's most prestigious manufacturers. Each
            timepiece is authenticated and certified by our expert horologists.
          </motion.p>

          {/* Search and filter bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-3"
          >
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-white/50" />
              <Input
                type="search"
                placeholder="Search by brand, model, or reference..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full h-12 pl-10 pr-4 bg-white/5 backdrop-blur-sm text-white placeholder:text-white/50 rounded-full border-none"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/50 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              )}
            </div>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="h-12 px-4 bg-white/5 backdrop-blur-sm border-none text-white hover:bg-white/10"
            >
              <Filter className="mr-2 h-5 w-5" />
              Filters
              {hasActiveFilters && (
                <span className="ml-2 bg-emerald-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {activeFilters.brands.length +
                    activeFilters.materials.length +
                    activeFilters.colors.length +
                    (activeFilters.priceRange[0] !== null ? 1 : 0) +
                    (activeFilters.priceRange[1] !== null ? 1 : 0)}
                </span>
              )}
            </Button>
          </motion.div>
          {/* Filters panel */}
          <AnimatePresence>
            {showFilters && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                transition={{ duration: 0.2 }}
                className="mt-4 mb-8 p-6 rounded-xl bg-white/5 backdrop-blur-lg border border-white/10"
              >
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-semibold text-white">Refine Your Search</h2>
                  <div className="flex gap-2">
                    {hasActiveFilters && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={resetFilters}
                        className="h-9 text-white/70 hover:text-white hover:bg-white/10"
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Reset All
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowFilters(false)}
                      className="h-9 text-white/70 hover:text-white hover:bg-white/10"
                    >
                      <X className="mr-2 h-4 w-4" />
                      Close
                    </Button>
                  </div>
                </div>

                {/* Active filters */}
                {hasActiveFilters && (
                  <div className="mb-4 pb-4 border-b border-white/10">
                    <p className="text-sm text-white/70 mb-2">Active Filters:</p>
                    <div className="flex flex-wrap gap-2">
                      {activeFilters.brands.map((brand) => (
                        <div
                          key={brand}
                          className="flex items-center bg-emerald-500/20 text-emerald-300 text-sm rounded-full px-3 py-1"
                        >
                          {brand}
                          <button
                            onClick={() => toggleFilter("brands", brand)}
                            className="ml-2 text-emerald-300/70 hover:text-emerald-300"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}

                      {activeFilters.materials.map((material) => (
                        <div
                          key={material}
                          className="flex items-center bg-emerald-500/20 text-emerald-300 text-sm rounded-full px-3 py-1"
                        >
                          {material}
                          <button
                            onClick={() => toggleFilter("materials", material)}
                            className="ml-2 text-emerald-300/70 hover:text-emerald-300"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}

                      {activeFilters.colors.map((color) => (
                        <div
                          key={color}
                          className="flex items-center bg-emerald-500/20 text-emerald-300 text-sm rounded-full px-3 py-1"
                        >
                          {color}
                          <button
                            onClick={() => toggleFilter("colors", color)}
                            className="ml-2 text-emerald-300/70 hover:text-emerald-300"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}

                      {activeFilters.priceRange[0] !== null && (
                        <div className="flex items-center bg-emerald-500/20 text-emerald-300 text-sm rounded-full px-3 py-1">
                          Min: ${activeFilters.priceRange[0].toLocaleString()}
                          <button
                            onClick={() => setPriceRange(null, activeFilters.priceRange[1])}
                            className="ml-2 text-emerald-300/70 hover:text-emerald-300"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      )}

                      {activeFilters.priceRange[1] !== null && (
                        <div className="flex items-center bg-emerald-500/20 text-emerald-300 text-sm rounded-full px-3 py-1">
                          Max: ${activeFilters.priceRange[1].toLocaleString()}
                          <button
                            onClick={() => setPriceRange(activeFilters.priceRange[0], null)}
                            className="ml-2 text-emerald-300/70 hover:text-emerald-300"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      )}

                      {searchQuery && (
                        <div className="flex items-center bg-emerald-500/20 text-emerald-300 text-sm rounded-full px-3 py-1">
                          Search: "{searchQuery}"
                          <button
                            onClick={() => setSearchQuery("")}
                            className="ml-2 text-emerald-300/70 hover:text-emerald-300"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {/* Brand filter */}
                  <div className="space-y-2">
                    <button
                      onClick={() => toggleSection("brands")}
                      className="flex justify-between items-center w-full text-left text-white font-medium"
                    >
                      Brand
                      {expandedSections.brands ? (
                        <ChevronUp className="h-4 w-4 text-white/70" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-white/70" />
                      )}
                    </button>

                    {expandedSections.brands && (
                      <div className="space-y-2 pt-2">
                        {brands.map((brand) => (
                          <div key={brand} className="flex items-center">
                            <button
                              onClick={() => toggleFilter("brands", brand)}
                              className="flex items-center w-full text-left text-white/80 hover:text-white text-sm py-1"
                            >
                              <div
                                className={`w-4 h-4 mr-2 rounded border flex items-center justify-center ${
                                  activeFilters.brands.includes(brand)
                                    ? "bg-emerald-500 border-emerald-500"
                                    : "border-white/30"
                                }`}
                              >
                                {activeFilters.brands.includes(brand) && <Check className="h-3 w-3 text-white" />}
                              </div>
                              {brand}
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Material filter */}
                  <div className="space-y-2">
                    <button
                      onClick={() => toggleSection("materials")}
                      className="flex justify-between items-center w-full text-left text-white font-medium"
                    >
                      Case Material
                      {expandedSections.materials ? (
                        <ChevronUp className="h-4 w-4 text-white/70" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-white/70" />
                      )}
                    </button>

                    {expandedSections.materials && (
                      <div className="space-y-2 pt-2">
                        {materials.map((material) => (
                          <div key={material} className="flex items-center">
                            <button
                              onClick={() => toggleFilter("materials", material)}
                              className="flex items-center w-full text-left text-white/80 hover:text-white text-sm py-1"
                            >
                              <div
                                className={`w-4 h-4 mr-2 rounded border flex items-center justify-center ${
                                  activeFilters.materials.includes(material)
                                    ? "bg-emerald-500 border-emerald-500"
                                    : "border-white/30"
                                }`}
                              >
                                {activeFilters.materials.includes(material) && <Check className="h-3 w-3 text-white" />}
                              </div>
                              {material}
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Color filter */}
                  <div className="space-y-2">
                    <button
                      onClick={() => toggleSection("colors")}
                      className="flex justify-between items-center w-full text-left text-white font-medium"
                    >
                      Dial Color
                      {expandedSections.colors ? (
                        <ChevronUp className="h-4 w-4 text-white/70" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-white/70" />
                      )}
                    </button>

                    {expandedSections.colors && (
                      <div className="space-y-2 pt-2">
                        {colors.map((color) => (
                          <div key={color} className="flex items-center">
                            <button
                              onClick={() => toggleFilter("colors", color)}
                              className="flex items-center w-full text-left text-white/80 hover:text-white text-sm py-1"
                            >
                              <div
                                className={`w-4 h-4 mr-2 rounded border flex items-center justify-center ${
                                  activeFilters.colors.includes(color)
                                    ? "bg-emerald-500 border-emerald-500"
                                    : "border-white/30"
                                }`}
                              >
                                {activeFilters.colors.includes(color) && <Check className="h-3 w-3 text-white" />}
                              </div>
                              {color}
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Price filter */}
                  <div className="space-y-2">
                    <button
                      onClick={() => toggleSection("price")}
                      className="flex justify-between items-center w-full text-left text-white font-medium"
                    >
                      Price Range
                      {expandedSections.price ? (
                        <ChevronUp className="h-4 w-4 text-white/70" />
                      ) : (
                        <ChevronDown className="h-4 w-4 text-white/70" />
                      )}
                    </button>

                    {expandedSections.price && (
                      <div className="space-y-3 pt-2">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-xs text-white/70 mb-1 block">Min Price</label>
                            <Input
                              type="number"
                              placeholder="Min"
                              value={activeFilters.priceRange[0] || ""}
                              onChange={(e) => {
                                const value = e.target.value ? Number.parseInt(e.target.value) : null
                                setPriceRange(value, activeFilters.priceRange[1])
                              }}
                              className="h-9 bg-white/5 border-white/10 text-white"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-white/70 mb-1 block">Max Price</label>
                            <Input
                              type="number"
                              placeholder="Max"
                              value={activeFilters.priceRange[1] || ""}
                              onChange={(e) => {
                                const value = e.target.value ? Number.parseInt(e.target.value) : null
                                setPriceRange(activeFilters.priceRange[0], value)
                              }}
                              className="h-9 bg-white/5 border-white/10 text-white"
                            />
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setPriceRange(0, 10000)}
                            className="h-7 text-xs bg-white/5 border-white/10 text-white hover:bg-white/10"
                          >
                            Under $10k
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setPriceRange(10000, 25000)}
                            className="h-7 text-xs bg-white/5 border-white/10 text-white hover:bg-white/10"
                          >
                            $10k - $25k
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setPriceRange(25000, 50000)}
                            className="h-7 text-xs bg-white/5 border-white/10 text-white hover:bg-white/10"
                          >
                            $25k - $50k
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setPriceRange(50000, null)}
                            className="h-7 text-xs bg-white/5 border-white/10 text-white hover:bg-white/10"
                          >
                            $50k+
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Brand Showcase Section */}
          <div className="container mx-auto px-2 mb-8 mt-8">

            {/* Brand Section Title */}
            <div className="mb-4 text-center max-w-2xl mx-auto">
              <h3 className="text-white text-2xl font-medium mb-1">Luxury Watch Brands</h3>
              <p className="text-white/70 text-sm md:text-base">
                Explore our curated collection of prestigious timepieces from the world&apos;s most renowned watchmakers,
                each representing a unique heritage of craftsmanship and innovation.
              </p>
            </div>

            {/* Brand Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-6 gap-2 md:gap-3">
              {brandsData.map((brand, index) => (
                <Link
                  key={brand.id}
                  href={`/brands/${brand.id}`}
                  className="block group focus:outline-none focus:ring-2 focus:ring-white/50 focus:rounded-xl"
                  onClick={() => {
                    // Pre-loading state for seamless transitions
                    setIsImageLoading((prev) => ({
                      ...prev,
                      [brand.id]: true,
                    }))
                  }}
                >
                  <div
                    className="h-44 md:h-72 backdrop-blur-md bg-white/5 p-3 md:p-6 flex flex-col items-center justify-between 
          transition-all duration-300 hover:translate-y-[-4px] rounded-xl border border-transparent 
          hover:border-white/10 hover:bg-white/10"
                  >
                    {/* Brand Image Container */}
                    <div className="flex-1 flex items-center justify-center mb-2 md:mb-4 min-h-[100px] md:min-h-[180px] relative w-full">
                      {/* Loading Skeleton */}
                      <div
                        className={`absolute inset-0 flex items-center justify-center ${isImageLoading[brand.id] ? "opacity-100" : "opacity-0"} transition-opacity duration-300`}
                      >
                        <div className="w-16 h-16 md:w-24 md:h-24 rounded-full bg-white/10 animate-pulse"></div>
                      </div>

                      {/* Actual Image */}
                      <Image
                        src={brand.imagePath || "/placeholder.svg"}
                        alt={`${brand.name} luxury watch`}
                        width={168}
                        height={168}
                        className={`max-h-[98px] md:max-h-[196px] w-auto object-contain 
                transition-all duration-300 group-hover:scale-110 
                ${isImageLoading[brand.id] ? "opacity-0" : "opacity-100"}`}
                        priority={index < 3}
                        sizes="(max-width: 640px) 40vw, (max-width: 768px) 25vw, (max-width: 1024px) 16vw, 168px"
                        loading={index < 3 ? "eager" : "lazy"}
                        onLoad={() => handleImageLoad(brand.id)}
                        onError={() => handleImageError(brand.id)}
                      />
                    </div>

                    {/* Brand Info */}
                    <div className="text-center">
                      <h3
                        className="text-xs md:text-base font-medium text-white mb-0 md:whitespace-nowrap md:overflow-hidden md:text-ellipsis md:max-w-full"
                        title={brand.name}
                      >
                        {brand.name}
                      </h3>
                      <div className="flex items-center justify-center mt-1 text-white/70 text-[10px] md:text-xs">
                        <span>View all models</span>
                        <ArrowUpRight className="w-2 h-2 md:w-3 md:h-3 ml-1" />
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Latest Arrivals Section */}
          <div className="container mx-auto px-2 mb-8 mt-12">
            {/* Latest Arrivals Section Title */}
            <div className="mb-4 text-center max-w-2xl mx-auto">
              <h3 className="text-white text-2xl font-medium mb-1">Latest Arrivals</h3>
              <p className="text-white/70 text-sm md:text-base">
                Discover our newest additions to the collection, featuring the most sought-after timepieces 
                that have just arrived in our inventory.
              </p>
            </div>
            
            {/* Latest Arrivals Content */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-8 text-center">
              <p className="text-white/70 mb-2">No new arrivals are currently available.</p>
              <p className="text-white/50 text-sm">Check back soon for the latest luxury timepieces.</p>
            </div>
          </div>

        {/* Results count */}

        {/* Products grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="rounded-xl overflow-hidden bg-white/5 backdrop-blur-sm">
                <Skeleton className="aspect-square w-full bg-white/10" />
                <div className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2 bg-white/10" />
                  <Skeleton className="h-4 w-1/2 mb-4 bg-white/10" />
                  <Skeleton className="h-5 w-1/3 bg-white/10" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-400 mb-4">{error}</p>
            <Button onClick={loadProducts}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Try Again
            </Button>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-12 bg-white/5 backdrop-blur-sm rounded-xl">
            <p className="text-white/70 mb-4">No watches found matching your criteria</p>
            <Button onClick={resetFilters}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Reset Filters
            </Button>
          </div>
        ) : (
          <>
            
            <div className="mt-16 mb-8">
              <h3 className="text-white text-2xl font-medium mb-4 text-center">Marketplace Collection</h3>
              <div className="text-center py-12 bg-white/5 backdrop-blur-sm rounded-xl">
                <p className="text-white/70 mb-4">No products are currently available in the marketplace collection.</p>
                <p className="text-white/50 text-sm">Our team is curating the next selection of premium timepieces.</p>
              </div>
              <div className="clear-both"></div>
            </div>
            <div className="clear-both"></div>

            {/* Load more button */}
            {hasMore && (
              <div className="flex justify-center mt-10">
                <Button onClick={loadMore} className="bg-white/10 hover:bg-white/20 text-white border-none">
                  Load More Watches
                </Button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Add animation keyframes */}
      <style jsx global>{`
        
        
        @keyframes marquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
      `}</style>
    </SiteLayout>
  );
}
