import Link from "next/link"
import { Button } from "@/components/ui/button"
import BeamsBackground from "@/components/beams-background"
import { Home, Search } from "lucide-react"

export default function NotFound() {
  return (
    <BeamsBackground>
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-black/40 backdrop-blur-xl p-8 rounded-xl text-center">
          <h1 className="text-6xl font-bold text-white mb-2">404</h1>
          <h2 className="text-2xl font-semibold text-white mb-4">Page Not Found</h2>
          <p className="text-white/70 mb-8">The page you are looking for doesn't exist or has been moved.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild className="bg-white/20 hover:bg-white/30 text-white">
              <Link href="/">
                <Home className="h-4 w-4 mr-2" />
                Return Home
              </Link>
            </Button>
            <Button asChild className="bg-white/10 hover:bg-white/20 text-white">
              <Link href="/collection">
                <Search className="h-4 w-4 mr-2" />
                Browse Collection
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </BeamsBackground>
  )
}
