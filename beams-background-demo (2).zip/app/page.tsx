"use client"

import { useRef, useEffect } from "react"
import { motion, useInView, useAnimation } from "framer-motion"
import { SiteLayout } from "@/components/site-layout"
import { GlassHero } from "@/components/glass-hero"
import { FeaturedProducts } from "@/components/featured-products"
import { BrandShowcase } from "@/components/brand-showcase"
import { PromotionalBanner } from "@/components/promotional-banner"
import { NewsletterSignup } from "@/components/newsletter-signup"
import { SectionLayout } from "@/components/section-layout"

export default function Home() {
  // Simple device detection
  const isMobileDevice = typeof window !== "undefined" && window.innerWidth < 768

  const heroRef = useRef(null)
  const brandsRef = useRef(null)
  const promotionalRef = useRef(null)

  const isHeroInView = useInView(heroRef, { once: true, amount: 0.2 })
  const isBrandsInView = useInView(brandsRef, { once: true, amount: 0.2 })
  const isPromotionalInView = useInView(promotionalRef, { once: true, amount: 0.2 })

  const heroControls = useAnimation()
  const brandsControls = useAnimation()
  const promotionalControls = useAnimation()

  useEffect(() => {
    if (isHeroInView) heroControls.start({ opacity: 1, y: 0 })
    if (isBrandsInView) brandsControls.start({ opacity: 1, y: 0 })
    if (isPromotionalInView) promotionalControls.start({ opacity: 1, y: 0 })
  }, [isHeroInView, isBrandsInView, isPromotionalInView, heroControls, brandsControls, promotionalControls])

  return (
    <SiteLayout>
      {/* Hero Section */}
      <motion.div ref={heroRef} initial={{ opacity: 0, y: 20 }} animate={heroControls} transition={{ duration: 0.8 }}>
        <GlassHero />
      </motion.div>

      {/* Featured Products */}
      <section className="w-full px-3 sm:px-4 pt-4 pb-8 sm:pt-8 sm:pb-8 mt-2 sm:mt-4 overflow-hidden">
        <div className="max-w-[100vw] mx-auto">
          <SectionLayout
            title="Featured Timepieces"
            description="Discover our curated selection of exceptional luxury watches"
          >
            <div className="sm:container -mx-2 sm:mx-auto">
              <FeaturedProducts
                disableAutoScroll={true}
                desktopItemCount={6}
                key={`featured-products-${isMobileDevice ? "mobile" : "desktop"}`}
              />
            </div>
          </SectionLayout>
        </div>
      </section>

      {/* Brand Showcase */}
      <motion.section
        ref={brandsRef}
        initial={{ opacity: 0, y: 20 }}
        animate={brandsControls}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="container mx-auto px-2 py-2 min-w-full sm:min-w-0"
      >
        <SectionLayout
          title="Prestigious Brands"
          description="Explore our collection of the world's most renowned watchmakers"
        >
          <BrandShowcase />
        </SectionLayout>
      </motion.section>

      {/* Newsletter Signup */}
      <NewsletterSignup />

      {/* Promotional Banner */}
      <motion.section
        ref={promotionalRef}
        initial={{ opacity: 0, y: 20 }}
        animate={promotionalControls}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="container mx-auto px-2 py-8 min-w-full sm:min-w-0 bg-gradient-to-b from-black/0 to-black/30 backdrop-blur-sm rounded-lg mt-8"
      >
        <PromotionalBanner />
      </motion.section>
    </SiteLayout>
  )
}
