"use client"

import { useState, useEffect, Suspense, lazy } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, ShoppingBag } from "lucide-react"
import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import dynamic from "next/dynamic"
import { useInView } from "react-intersection-observer"
import { fetchProductById } from "@/lib/product-service"
import { useRouter } from "next/navigation"
import { useIOSDetection } from "@/lib/use-ios-detection"
import { ProductComments } from "@/components/product-comments"

// Lazy load components that aren't needed for initial render
const ProductGrid = dynamic(() => import("@/components/product-grid").then((mod) => ({ default: mod.ProductGrid })), {
  loading: () => <ProductGridSkeleton />,
  ssr: false,
})

// Chat component lazy loaded
const ProductChat = lazy(() => import("@/components/product-chat"))

// Skeleton loaders
function ProductGridSkeleton() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
      {[...Array(6)].map((_, i) => (
        <div key={i} className="aspect-square bg-black/20 rounded-lg animate-pulse" />
      ))}
    </div>
  )
}

function ProductDetailSkeleton() {
  return (
    <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden">
      <div className="grid grid-cols-3 md:grid-cols-5 gap-2 md:gap-8">
        <div className="col-span-1 p-3 md:p-4 flex items-center justify-center">
          <div className="aspect-square relative rounded-lg w-full bg-black/30 animate-pulse" />
        </div>
        <div className="col-span-2 md:col-span-4 p-3 md:p-8 flex flex-col">
          <div className="h-4 w-20 bg-black/30 animate-pulse mb-2" />
          <div className="h-6 w-48 bg-black/30 animate-pulse mb-4" />
          <div className="h-5 w-24 bg-black/30 animate-pulse mb-6" />
          <div className="grid grid-cols-2 gap-4 mb-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-12 bg-black/30 animate-pulse rounded" />
            ))}
          </div>
          <div className="flex gap-2 md:gap-4 mt-auto">
            <div className="flex-1 h-10 bg-black/30 animate-pulse rounded-full" />
            <div className="flex-1 h-10 bg-black/30 animate-pulse rounded-full" />
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ProductPage({ params }: { params: { id: string } }) {
  // State for product data with loading state
  const [product, setProduct] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [loadedProductSets, setLoadedProductSets] = useState(1)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const isIOS = useIOSDetection()

  // Intersection observer for lazy loading additional products
  const { ref: loadMoreRef, inView } = useInView({
    threshold: 0.1,
    triggerOnce: false,
  })

  const router = useRouter()

  // Add a new state for tracking product not found errors
  const [productNotFound, setProductNotFound] = useState(false)

  // Modify the useEffect for fetching product data
  useEffect(() => {
    const getProduct = async () => {
      try {
        setIsLoading(true)
        const data = await fetchProductById(params.id)

        // Check if the product is manually entered or doesn't have a source specified
        if (data.source === "manual" || data.source === undefined) {
          setProduct(data)
        } else {
          // If the product is auto-generated, show an error or redirect
          console.error("Product is automatically generated and not available for display")
          // Optionally redirect to collection page or show error state
          router.push("/marketplace")
        }
      } catch (error) {
        console.error("Error fetching product:", error)
        // Set product to null but don't redirect - we'll show a "not found" message
        setProduct(null)
      } finally {
        setIsLoading(false)
      }
    }

    getProduct()
  }, [params.id, router])

  // Load more products when scrolled into view
  useEffect(() => {
    if (inView && loadedProductSets < 4) {
      setLoadedProductSets((prev) => prev + 1)
    }
  }, [inView, loadedProductSets])

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen)
  }

  // Mock total number of product sets available (for demonstration)
  const totalProductSets = 4 // Total of 24 products (4 sets of 6)
  const remainingProductSets = totalProductSets - loadedProductSets

  // Update the return statement to include a "Product not found" message
  // Add this after the isLoading check and before rendering the product
  return (
    <SiteLayout>
      <div className="container mx-auto px-4 py-8">
        <Link href="/marketplace" className="inline-flex items-center text-sm text-white/70 hover:text-white mb-8">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Collection
        </Link>

        {isLoading ? (
          <ProductDetailSkeleton />
        ) : !product ? (
          <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-8 text-center">
            <h2 className="text-xl font-medium text-white mb-4">Product Not Found</h2>
            <p className="text-white/70 mb-6">The product you're looking for doesn't exist or has been removed.</p>
            <Button asChild>
              <Link href="/marketplace">Browse Collection</Link>
            </Button>
          </div>
        ) : (
          <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all duration-300">
            <div className="grid grid-cols-3 md:grid-cols-5 gap-2 md:gap-8">
              {/* Image section - 1/3 width on mobile, 1/5 width on desktop */}
              <div className="col-span-1 p-3 md:p-4 flex items-center justify-center">
                <div className="aspect-square relative rounded-lg w-full overflow-visible">
                  <div
                    className="absolute flex items-center justify-center"
                    style={{
                      width: "70%",
                      height: "100%",
                      left: "15%",
                      transform: "scale(2.75) translateX(3%)",
                    }}
                  >
                    <Image
                      src={product?.image || "/placeholder.svg"}
                      alt={product?.name || "Product"}
                      fill
                      className="object-contain"
                      sizes="(max-width: 768px) 33vw, 20vw"
                      priority
                      loading="eager"
                    />
                  </div>
                </div>
              </div>

              {/* Product info section - 2/3 width on mobile, 4/5 width on desktop */}
              <div className="col-span-2 md:col-span-4 p-3 md:p-8 flex flex-col">
                <div className="mb-1 md:mb-2 text-[10px] md:text-xs font-medium text-white/70">{product?.brand}</div>
                <h1 className="text-base md:text-xl font-bold text-white mb-2 md:mb-4">{product?.name}</h1>
                <div className="text-sm md:text-lg font-bold text-white mb-3 md:mb-6">
                  ${product?.price?.toLocaleString()}
                </div>

                <div className="mb-3 md:mb-6 p-2 md:p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-[10px] text-white/60 mb-1">Case Size</h3>
                      <p className="text-xs font-medium text-white">{product?.caseSize || "41mm"}</p>
                    </div>
                    <div>
                      <h3 className="text-[10px] text-white/60 mb-1">Case Material</h3>
                      <p className="text-xs font-medium text-white">{product?.caseMaterial || "Oystersteel"}</p>
                    </div>
                    <div>
                      <h3 className="text-[10px] text-white/60 mb-1">Dial Color</h3>
                      <p className="text-xs font-medium text-white">{product?.dialColor || "Black"}</p>
                    </div>
                    <div>
                      <h3 className="text-[10px] text-white/60 mb-1">Bracelet / Strap</h3>
                      <p className="text-xs font-medium text-white">{product?.bracelet || "Oystersteel - Oyster"}</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 md:gap-4 mt-auto">
                  <Button
                    className="flex-1 text-xs md:text-sm rounded-full bg-white text-black hover:bg-white/90 h-8 md:h-10 cursor-pointer"
                    onClick={toggleChat}
                  >
                    <ShoppingBag className="mr-1 md:mr-2 h-3 md:h-4 w-3 md:w-4" />
                    Inquire
                  </Button>
                  <Button
                    variant="outline"
                    className={`flex-1 text-xs md:text-sm rounded-full text-white h-8 md:h-10 cursor-pointer ${
                      isIOS
                        ? "bg-white/10 border border-white/20"
                        : "bg-white/5 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 border-0"
                    }`}
                    style={isIOS ? {} : { backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)" }}
                    onClick={toggleChat}
                  >
                    Sell Mine
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        <section className="py-8 md:py-16">
          <h2 className="text-xl md:text-2xl font-bold text-white mb-4 md:mb-8">You May Also Like</h2>

          {/* Initial set of products (always shown) */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6 overflow-x-auto pb-4">
            <Suspense fallback={<ProductGridSkeleton />}>
              <ProductGrid noHoverAnimation={true} />
            </Suspense>
          </div>

          {/* Additional sets of products based on loadedProductSets */}
          {Array.from({ length: loadedProductSets - 1 }).map((_, index) => (
            <div
              key={index}
              className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6 overflow-x-auto pb-4 mt-6"
            >
              <Suspense fallback={<ProductGridSkeleton />}>
                <ProductGrid noHoverAnimation={true} />
              </Suspense>
            </div>
          ))}

          {/* Load more trigger */}
          {remainingProductSets > 0 && (
            <div ref={loadMoreRef} className="flex justify-center mt-8">
              <Button
                variant="outline"
                className="inline-flex items-center text-white px-4 py-2 bg-white/10 rounded-md"
              >
                <span className="mr-2">Loading more products...</span>
                <div className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
              </Button>
            </div>
          )}
        </section>
        {product && (
          <section className="py-8 md:py-16">
            <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-6 md:p-8">
              <ProductComments productId={params.id} />
            </div>
          </section>
        )}
      </div>

      {/* Chat Box - Lazy loaded */}
      {isChatOpen && (
        <Suspense
          fallback={
            <div className="fixed bottom-4 right-4 w-80 md:w-96 bg-black/40 backdrop-blur-xl border border-white/20 rounded-lg shadow-lg h-96 animate-pulse"></div>
          }
        >
          <ProductChat productId={params.id} productName={product?.name} onClose={toggleChat} />
        </Suspense>
      )}
    </SiteLayout>
  )
}
