"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Eye, EyeOff, ArrowLeft, ArrowRight, CreditCard } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Check } from "lucide-react"
import { GlassNavbar } from "@/components/glass-navbar"
import { BeamsBackground } from "@/components/beams-background"

// Define our subscription plan with fixed pricing
const SUBSCRIPTION_PLAN = {
  id: "standard",
  name: "Standard",
  description: "Complete access to all features",
  priceId: {
    monthly: "price_standard_monthly",
    annual: "price_standard_annual",
  },
  price: {
    monthly: 1000, // $10.00
    annual: 10000, // $100.00
  },
  features: [
    { name: "Unlimited Rolex Serial Number Lookup", included: true },
    { name: "Real-time Market Price Data", included: true },
    { name: "Advanced Authentication Guides", included: true },
    { name: "Dealer Network Access", included: true },
    { name: "Authentication Certificates", included: true },
    { name: "Price Alerts", included: true },
    { name: "Discount in Repairs", included: true },
    { name: "Automatic Giveaway Entries", included: true },
    { name: "Discounts in Products", included: true },
  ],
}

export default function SignupPage() {
  const router = useRouter()
  const { signup, isAuthenticated } = useAuth()
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    company: "",
    agreeToTerms: false,
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
  })
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("annual")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Redirect if already authenticated
  if (isAuthenticated) {
    router.push("/dashboard")
    return null
  }

  const updateFormData = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Calculate savings percentage for annual billing
  const calculateSavings = () => {
    const monthlyCost = SUBSCRIPTION_PLAN.price.monthly * 12
    const savings = ((monthlyCost - SUBSCRIPTION_PLAN.price.annual) / monthlyCost) * 100
    return Math.round(savings)
  }

  const handleBillingCycleChange = (isAnnual: boolean) => {
    setBillingCycle(isAnnual ? "annual" : "monthly")
  }

  const validateStep1 = () => {
    if (!formData.email) {
      setError("Please enter your email address")
      return false
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError("Please enter a valid email address")
      return false
    }

    if (!formData.password) {
      setError("Please enter a password")
      return false
    }

    if (formData.password.length < 8) {
      setError("Password must be at least 8 characters long")
      return false
    }

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match")
      return false
    }

    return true
  }

  const validateStep2 = () => {
    if (!formData.firstName) {
      setError("Please enter your first name")
      return false
    }

    if (!formData.lastName) {
      setError("Please enter your last name")
      return false
    }

    return true
  }

  const validateStep3 = () => {
    // No validation needed for billing cycle selection
    return true
  }

  const validateStep4 = () => {
    if (!formData.cardNumber || formData.cardNumber.length < 16) {
      setError("Please enter a valid card number")
      return false
    }

    if (!formData.cardName) {
      setError("Please enter the name on your card")
      return false
    }

    if (!formData.expiryDate || !/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
      setError("Please enter a valid expiry date (MM/YY)")
      return false
    }

    if (!formData.cvv || formData.cvv.length < 3) {
      setError("Please enter a valid CVV")
      return false
    }

    if (!formData.agreeToTerms) {
      setError("You must agree to the terms and conditions")
      return false
    }

    return true
  }

  const nextStep = () => {
    setError("")

    if (currentStep === 1 && !validateStep1()) {
      return
    }

    if (currentStep === 2 && !validateStep2()) {
      return
    }

    if (currentStep === 3 && !validateStep3()) {
      return
    }

    setCurrentStep((prev) => prev + 1)
    window.scrollTo(0, 0)
  }

  const prevStep = () => {
    setError("")
    setCurrentStep((prev) => prev - 1)
    window.scrollTo(0, 0)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!validateStep4()) {
      return
    }

    setIsSubmitting(true)
    try {
      // In a real implementation, you would:
      // 1. Process the payment with Stripe - charging exactly $10 monthly or $100 yearly
      // 2. Create the user account only after successful payment
      // 3. Associate the subscription with the user account

      // Simulate API call for payment processing
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Create user account after successful payment
      await signup(formData.email, formData.password, `${formData.firstName} ${formData.lastName}`, {
        plan: SUBSCRIPTION_PLAN.id,
        billingCycle,
        amount: billingCycle === "annual" ? 10000 : 1000, // $100 or $10 in cents
      })

      // Redirect to dashboard (this would happen in the useAuth hook)
      router.push("/dashboard")
    } catch (err: any) {
      setError(err.message || "An error occurred during payment processing. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatPrice = (price: number) => {
    return `$${(price / 100).toFixed(2)}`
  }

  return (
    <div className="relative min-h-screen">
      <BeamsBackground className="absolute inset-0 z-0" />
      <div className="relative z-10 min-h-screen flex flex-col">
        <GlassNavbar />

        <main className="flex-1 pt-24 pb-12 px-4">
          <div className="container mx-auto max-w-4xl">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-white">Create Your Account</h1>
              <p className="text-gray-400 mt-2">Join our premium subscription service</p>
            </div>

            <Card className="bg-gray-800/50 border-gray-700 backdrop-blur-sm shadow-xl">
              <CardHeader>
                <div className="flex justify-between items-center mb-2">
                  <CardTitle className="text-xl text-white">
                    Step {currentStep} of 4:{" "}
                    {currentStep === 1
                      ? "Account"
                      : currentStep === 2
                        ? "Profile"
                        : currentStep === 3
                          ? "Subscription"
                          : "Payment"}
                  </CardTitle>
                </div>
                <div className="flex gap-1 mb-2">
                  {[1, 2, 3, 4].map((step) => (
                    <div
                      key={step}
                      className={`h-1 flex-1 rounded-full ${step <= currentStep ? "bg-stone-400" : "bg-gray-600"}`}
                    />
                  ))}
                </div>
                <CardDescription className="text-gray-400">
                  {currentStep === 1
                    ? "Create your login credentials"
                    : currentStep === 2
                      ? "Tell us about yourself"
                      : currentStep === 3
                        ? "Choose your billing cycle"
                        : "Enter your payment details"}
                </CardDescription>
              </CardHeader>
              <form onSubmit={currentStep === 4 ? handleSubmit : (e) => e.preventDefault()}>
                <CardContent className="space-y-4">
                  {error && (
                    <Alert variant="destructive" className="bg-red-900/20 border-red-600">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  {currentStep === 1 && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-white">
                          Email
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => updateFormData("email", e.target.value)}
                          placeholder="you@example.com"
                          className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                          autoComplete="email"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="password" className="text-white">
                          Password
                        </Label>
                        <div className="relative">
                          <Input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            value={formData.password}
                            onChange={(e) => updateFormData("password", e.target.value)}
                            placeholder="••••••••"
                            className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500 pr-10"
                            autoComplete="new-password"
                          />
                          <button
                            type="button"
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
                            onClick={() => setShowPassword(!showPassword)}
                            aria-label={showPassword ? "Hide password" : "Show password"}
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                        <p className="text-xs text-gray-500">Password must be at least 8 characters long</p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword" className="text-white">
                          Confirm Password
                        </Label>
                        <Input
                          id="confirmPassword"
                          type={showPassword ? "text" : "password"}
                          value={formData.confirmPassword}
                          onChange={(e) => updateFormData("confirmPassword", e.target.value)}
                          placeholder="••••••••"
                          className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                          autoComplete="new-password"
                        />
                      </div>
                    </>
                  )}

                  {currentStep === 2 && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="firstName" className="text-white">
                          First Name
                        </Label>
                        <Input
                          id="firstName"
                          type="text"
                          value={formData.firstName}
                          onChange={(e) => updateFormData("firstName", e.target.value)}
                          placeholder="John"
                          className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                          autoComplete="given-name"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="lastName" className="text-white">
                          Last Name
                        </Label>
                        <Input
                          id="lastName"
                          type="text"
                          value={formData.lastName}
                          onChange={(e) => updateFormData("lastName", e.target.value)}
                          placeholder="Doe"
                          className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                          autoComplete="family-name"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="company" className="text-white">
                          Company (Optional)
                        </Label>
                        <Input
                          id="company"
                          type="text"
                          value={formData.company}
                          onChange={(e) => updateFormData("company", e.target.value)}
                          placeholder="Acme Inc."
                          className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                          autoComplete="organization"
                        />
                      </div>
                    </>
                  )}

                  {currentStep === 3 && (
                    <>
                      <div className="text-center mb-6">
                        <h3 className="text-xl font-bold text-white mb-2">{SUBSCRIPTION_PLAN.name} Subscription</h3>
                        <p className="text-gray-400">{SUBSCRIPTION_PLAN.description}</p>
                      </div>

                      <Card className="bg-gray-800/30 border-gray-700 mb-6">
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            {SUBSCRIPTION_PLAN.features.map((feature) => (
                              <div key={feature.name} className="flex items-start">
                                <Check className="h-5 w-5 text-stone-400 mr-2 shrink-0" />
                                <div className="text-sm text-white">{feature.name}</div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      <div className="flex items-center justify-center space-x-2 mb-6">
                        <Label htmlFor="billing-toggle" className="text-gray-400">
                          Monthly Billing
                        </Label>
                        <Switch
                          id="billing-toggle"
                          checked={billingCycle === "annual"}
                          onCheckedChange={handleBillingCycleChange}
                          className="data-[state=checked]:bg-stone-400"
                        />
                        <Label htmlFor="billing-toggle" className="flex items-center">
                          <span className="text-gray-400">Annual Billing</span>
                          <Badge className="ml-2 bg-stone-400 text-black border-none">Save {calculateSavings()}%</Badge>
                        </Label>
                      </div>

                      <div className="bg-gray-700/30 p-6 rounded-lg">
                        <div className="text-center mb-4">
                          <div className="text-3xl font-bold text-white">
                            {formatPrice(
                              billingCycle === "annual"
                                ? SUBSCRIPTION_PLAN.price.annual
                                : SUBSCRIPTION_PLAN.price.monthly,
                            )}
                          </div>
                          <div className="text-gray-400 text-sm">
                            {billingCycle === "annual" ? "per year" : "per month"}
                          </div>
                        </div>

                        <div className="text-center text-sm text-gray-400">
                          {billingCycle === "annual"
                            ? "You'll be charged $100.00 once yearly"
                            : "You'll be charged $10.00 every month"}
                        </div>
                      </div>
                    </>
                  )}

                  {currentStep === 4 && (
                    <>
                      <div className="bg-gray-700/30 p-4 rounded-lg mb-6">
                        <h3 className="text-white font-medium mb-2">Subscription Summary</h3>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="text-gray-400">Plan:</div>
                          <div className="text-white">{SUBSCRIPTION_PLAN.name}</div>
                          <div className="text-gray-400">Billing:</div>
                          <div className="text-white">{billingCycle === "annual" ? "Annual" : "Monthly"}</div>
                          <div className="text-gray-400">Price:</div>
                          <div className="text-white">
                            {formatPrice(
                              billingCycle === "annual"
                                ? SUBSCRIPTION_PLAN.price.annual
                                : SUBSCRIPTION_PLAN.price.monthly,
                            )}{" "}
                            {billingCycle === "annual" ? "per year" : "per month"}
                          </div>
                          <div className="text-gray-400">Today's charge:</div>
                          <div className="text-white font-medium">
                            {formatPrice(
                              billingCycle === "annual"
                                ? SUBSCRIPTION_PLAN.price.annual
                                : SUBSCRIPTION_PLAN.price.monthly,
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="cardNumber" className="text-white">
                            Card Number
                          </Label>
                          <Input
                            id="cardNumber"
                            placeholder="1234 5678 9012 3456"
                            value={formData.cardNumber}
                            onChange={(e) => updateFormData("cardNumber", e.target.value)}
                            className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="cardName" className="text-white">
                            Name on Card
                          </Label>
                          <Input
                            id="cardName"
                            placeholder="John Doe"
                            value={formData.cardName}
                            onChange={(e) => updateFormData("cardName", e.target.value)}
                            className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="expiryDate" className="text-white">
                              Expiry Date
                            </Label>
                            <Input
                              id="expiryDate"
                              placeholder="MM/YY"
                              value={formData.expiryDate}
                              onChange={(e) => updateFormData("expiryDate", e.target.value)}
                              className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="cvv" className="text-white">
                              CVV
                            </Label>
                            <Input
                              id="cvv"
                              placeholder="123"
                              value={formData.cvv}
                              onChange={(e) => updateFormData("cvv", e.target.value)}
                              className="bg-gray-700/50 border-gray-600 text-white placeholder:text-gray-500"
                            />
                          </div>
                        </div>

                        <div className="flex items-start space-x-2 mt-4">
                          <Checkbox
                            id="terms"
                            checked={formData.agreeToTerms}
                            onCheckedChange={(checked) => updateFormData("agreeToTerms", checked)}
                            className="mt-1 data-[state=checked]:bg-stone-400 data-[state=checked]:border-stone-400"
                          />
                          <div className="grid gap-1.5 leading-none">
                            <label
                              htmlFor="terms"
                              className="text-sm font-medium leading-none text-white peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              I agree to the terms and conditions
                            </label>
                            <p className="text-xs text-gray-500">
                              By creating an account, you agree to our{" "}
                              <Link href="/terms" className="text-stone-400 hover:text-stone-300 underline">
                                Terms of Service
                              </Link>{" "}
                              and{" "}
                              <Link href="/privacy" className="text-stone-400 hover:text-stone-300 underline">
                                Privacy Policy
                              </Link>
                              .
                            </p>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
                <CardFooter className="flex flex-col space-y-4">
                  <div className="flex gap-2 w-full">
                    {currentStep > 1 && (
                      <Button
                        type="button"
                        onClick={prevStep}
                        className="flex-1 bg-gray-700 hover:bg-gray-600 text-white"
                      >
                        <ArrowLeft className="h-4 w-4 mr-2" />
                        Back
                      </Button>
                    )}
                    {currentStep < 4 ? (
                      <Button
                        type="button"
                        onClick={nextStep}
                        className="flex-1 bg-stone-400 hover:bg-stone-500 text-black"
                      >
                        Next
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    ) : (
                      <Button
                        type="submit"
                        className="flex-1 bg-stone-400 hover:bg-stone-500 text-black"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                            Processing Payment...
                          </>
                        ) : (
                          <>
                            <CreditCard className="h-4 w-4 mr-2" />
                            Pay{" "}
                            {formatPrice(
                              billingCycle === "annual"
                                ? SUBSCRIPTION_PLAN.price.annual
                                : SUBSCRIPTION_PLAN.price.monthly,
                            )}
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                  <div className="text-center text-gray-400">
                    Already have an account?{" "}
                    <Link href="/login" className="text-stone-400 hover:text-stone-300 transition-colors">
                      Sign in
                    </Link>
                  </div>
                </CardFooter>
              </form>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
