"use client"

interface AccountCreationStepProps {
  subscriptionData: any
  updateSubscriptionData: (data: any) => void
  onNext: () => void
}
