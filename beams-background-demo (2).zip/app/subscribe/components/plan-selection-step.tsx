"use client"

import { Check, X, HelpCircle, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface PlanSelectionStepProps {
  subscriptionData: any
  updateSubscriptionData: (data: any) => void
  onNext: () => void
}

// Feature item component
function FeatureItem({ name, included }: { name: string; included: boolean }) {
  return (
    <div className="flex items-start">
      {included ? (
        <Check className="h-5 w-5 text-emerald-500 mr-2 shrink-0" />
      ) : (
        <X className="h-5 w-5 text-rose-500 mr-2 shrink-0" />
      )}
      <div className="text-sm">
        {name}
        {name.includes("Limited") && (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <HelpCircle className="h-3 w-3 inline ml-1 text-white/50" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="w-[200px] text-xs">Limited to 10 lookups per month</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        )}
      </div>
    </div>
  )
}

export function PlanSelectionStep({ subscriptionData, updateSubscriptionData, onNext }: PlanSelectionStepProps) {
  // Mock plans data
  const plans = [
    {
      id: "basic",
      name: "Basic",
      description: "Essential features for casual watch enthusiasts",
      price: { monthly: 19.99, annual: 199.99 },
      features: [
        { name: "Rolex Serial Number Lookup (Limited)", included: true },
        { name: "Basic Market Price Data", included: true },
        { name: "Authentication Guides", included: true },
        { name: "Dealer Network Access", included: false },
        { name: "Authentication Certificates", included: false },
        { name: "Price Alerts", included: false },
      ],
    },
    {
      id: "premium",
      name: "Premium",
      description: "Complete access for serious collectors",
      price: { monthly: 49.99, annual: 499.99 },
      features: [
        { name: "Unlimited Rolex Serial Number Lookup", included: true },
        { name: "Real-time Market Price Data", included: true },
        { name: "Advanced Authentication Guides", included: true },
        { name: "Dealer Network Access", included: true },
        { name: "Authentication Certificates", included: true },
        { name: "Price Alerts", included: true },
      ],
      popular: true,
    },
    {
      id: "business",
      name: "Business",
      description: "Enterprise solutions for dealers and businesses",
      price: { monthly: 99.99, annual: 999.99 },
      features: [
        { name: "Unlimited Serial Number Lookup (All Brands)", included: true },
        { name: "Real-time Market Price Data", included: true },
        { name: "Advanced Authentication Guides", included: true },
        { name: "Dealer Network Access", included: true },
        { name: "Unlimited Authentication Certificates", included: true },
        { name: "Price Alerts", included: true },
      ],
    },
  ]

  // Calculate savings percentage for annual billing
  const calculateSavings = (monthly: number, annual: number) => {
    const monthlyCost = monthly * 12
    const savings = ((monthlyCost - annual) / monthlyCost) * 100
    return Math.round(savings)
  }

  const handlePlanChange = (planId: string) => {
    updateSubscriptionData({ plan: planId })
  }

  const handleBillingCycleChange = (isAnnual: boolean) => {
    updateSubscriptionData({ billingCycle: isAnnual ? "annual" : "monthly" })
  }

  const handleContinue = () => {
    if (!subscriptionData.plan) {
      // If no plan is selected, default to premium
      updateSubscriptionData({ plan: "premium" })
    }
    onNext()
  }

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Choose Your Plan</h1>
        <p className="text-white/70 max-w-xl mx-auto">
          Select the subscription plan that best fits your needs. All plans include a 14-day free trial.
        </p>
      </div>

      <div className="flex items-center justify-center space-x-2 mb-8">
        <Label htmlFor="billing-toggle" className="text-white/70">
          Monthly Billing
        </Label>
        <Switch
          id="billing-toggle"
          checked={subscriptionData.billingCycle === "annual"}
          onCheckedChange={handleBillingCycleChange}
        />
        <Label htmlFor="billing-toggle" className="flex items-center">
          Annual Billing
          <Badge className="ml-2 bg-emerald-500 text-white border-none">Save 16-20%</Badge>
        </Label>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`relative overflow-hidden border-2 transition-all duration-200 ${
              subscriptionData.plan === plan.id
                ? "border-[#d4af37] bg-white/15"
                : "border-transparent bg-white/5 hover:bg-white/10"
            }`}
            onClick={() => handlePlanChange(plan.id)}
          >
            {plan.popular && (
              <div className="absolute top-0 right-0">
                <Badge className="rounded-none rounded-bl-lg bg-[#d4af37] text-black">Most Popular</Badge>
              </div>
            )}
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription className="text-white/70">{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-3xl font-bold">
                  ${subscriptionData.billingCycle === "annual" ? plan.price.annual : plan.price.monthly}
                </div>
                <div className="text-white/70 text-sm">
                  {subscriptionData.billingCycle === "annual" ? "per year" : "per month"}
                </div>
                {subscriptionData.billingCycle === "annual" && (
                  <div className="text-emerald-400 text-xs mt-1">
                    Save {calculateSavings(plan.price.monthly, plan.price.annual)}%
                  </div>
                )}
              </div>

              <div className="space-y-2">
                {plan.features.map((feature) => (
                  <FeatureItem key={feature.name} name={feature.name} included={feature.included} />
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button
                onClick={() => handlePlanChange(plan.id)}
                className={
                  subscriptionData.plan === plan.id
                    ? "w-full bg-[#d4af37] hover:bg-[#c4a030] text-black"
                    : "w-full bg-white/10 hover:bg-white/20 text-white"
                }
              >
                {subscriptionData.plan === plan.id ? "Selected" : "Select Plan"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="flex justify-center mt-8">
        <Button onClick={handleContinue} className="bg-white text-black hover:bg-white/90 px-8" size="lg">
          Continue
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>

      <div className="text-white/70 text-sm text-center max-w-xl mx-auto mt-4">
        By continuing, you agree to our Terms of Service and Privacy Policy. You can cancel your subscription at any
        time from your account settings.
      </div>
    </div>
  )
}
