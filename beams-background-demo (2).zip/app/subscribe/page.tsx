"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { StripeProvider } from "@/lib/stripe-context"
import { SubscriptionPlanSelector } from "@/components/subscription-plan-selector"
import { PaymentForm } from "@/components/payment-form"
import { PaymentConfirmation } from "@/components/payment-confirmation"
import { PaymentError } from "@/components/payment-error"
import { useToast } from "@/hooks/use-toast"

// Define our subscription plans
const SUBSCRIPTION_PLANS = [
  {
    id: "basic",
    name: "Basic",
    description: "Essential features for casual watch enthusiasts",
    priceId: {
      monthly: "price_basic_monthly",
      annual: "price_basic_annual",
    },
    price: {
      monthly: 1999, // $19.99
      annual: 19999, // $199.99
    },
    features: [
      { name: "Rolex Serial Number Lookup (Limited)", included: true },
      { name: "Basic Market Price Data", included: true },
      { name: "Authentication Guides", included: true },
      { name: "Dealer Network Access", included: false },
      { name: "Authentication Certificates", included: false },
      { name: "Price Alerts", included: false },
    ],
  },
  {
    id: "premium",
    name: "Premium",
    description: "Complete access for serious collectors",
    priceId: {
      monthly: "price_premium_monthly",
      annual: "price_premium_annual",
    },
    price: {
      monthly: 4999, // $49.99
      annual: 49999, // $499.99
    },
    features: [
      { name: "Unlimited Rolex Serial Number Lookup", included: true },
      { name: "Real-time Market Price Data", included: true },
      { name: "Advanced Authentication Guides", included: true },
      { name: "Dealer Network Access", included: true },
      { name: "Authentication Certificates", included: true },
      { name: "Price Alerts", included: true },
    ],
    popular: true,
  },
  {
    id: "business",
    name: "Business",
    description: "Enterprise solutions for dealers and businesses",
    priceId: {
      monthly: "price_business_monthly",
      annual: "price_business_annual",
    },
    price: {
      monthly: 9999, // $99.99
      annual: 99999, // $999.99
    },
    features: [
      { name: "Unlimited Serial Number Lookup (All Brands)", included: true },
      { name: "Real-time Market Price Data", included: true },
      { name: "Advanced Authentication Guides", included: true },
      { name: "Dealer Network Access", included: true },
      { name: "Unlimited Authentication Certificates", included: true },
      { name: "Price Alerts", included: true },
    ],
  },
]

type SubscriptionStep = "select-plan" | "payment" | "confirmation" | "error"

export default function SubscribePage() {
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [currentStep, setCurrentStep] = useState<SubscriptionStep>("select-plan")
  const [selectedPlan, setSelectedPlan] = useState<any>(null)
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("annual")
  const [paymentError, setPaymentError] = useState<any>(null)
  const [subscriptionDetails, setSubscriptionDetails] = useState<any>(null)

  // Redirect if not authenticated
  if (!user) {
    router.push("/login")
    return null
  }

  const handlePlanSelection = (plan: any, cycle: "monthly" | "annual") => {
    setSelectedPlan(plan)
    setBillingCycle(cycle)
    setCurrentStep("payment")
    window.scrollTo(0, 0)
  }

  const handlePaymentSuccess = (data: any) => {
    // In a real app, you would get this data from the API response
    setSubscriptionDetails({
      planName: selectedPlan.name,
      billingCycle,
      amount: billingCycle === "annual" ? selectedPlan.price.annual : selectedPlan.price.monthly,
      currency: "usd",
      startDate: new Date(),
      nextBillingDate: new Date(new Date().setMonth(new Date().getMonth() + (billingCycle === "annual" ? 12 : 1))),
    })
    setCurrentStep("confirmation")
    window.scrollTo(0, 0)
  }

  const handlePaymentError = (error: any) => {
    setPaymentError({
      message: error.message || "An error occurred during payment processing",
      code: error.code,
    })
    setCurrentStep("error")
    window.scrollTo(0, 0)
  }

  const handleRetry = () => {
    setCurrentStep("payment")
    window.scrollTo(0, 0)
  }

  const handleSupport = () => {
    toast({
      title: "Support Request Sent",
      description: "Our team will contact you shortly to assist with your payment.",
    })
    router.push("/dashboard")
  }

  const handleContinueToDashboard = () => {
    router.push("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black p-4">
      <div className="container mx-auto max-w-4xl py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Subscribe to REAL TIME</h1>
          <p className="text-gray-400 max-w-xl mx-auto">
            Choose the plan that best fits your needs and get access to premium features.
          </p>
        </div>

        <StripeProvider>
          {currentStep === "select-plan" && (
            <SubscriptionPlanSelector
              plans={SUBSCRIPTION_PLANS}
              onSelectPlan={handlePlanSelection}
              defaultSelected="premium"
              defaultBillingCycle="annual"
            />
          )}

          {currentStep === "payment" && selectedPlan && (
            <PaymentForm
              priceId={billingCycle === "annual" ? selectedPlan.priceId.annual : selectedPlan.priceId.monthly}
              amount={billingCycle === "annual" ? selectedPlan.price.annual : selectedPlan.price.monthly}
              currency="usd"
              interval={billingCycle}
              planName={selectedPlan.name}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
              userId={user.id}
              email={user.email}
              name={user.name}
            />
          )}

          {currentStep === "confirmation" && subscriptionDetails && (
            <PaymentConfirmation subscriptionDetails={subscriptionDetails} onContinue={handleContinueToDashboard} />
          )}

          {currentStep === "error" && paymentError && (
            <PaymentError error={paymentError} onRetry={handleRetry} onSupport={handleSupport} />
          )}
        </StripeProvider>
      </div>
    </div>
  )
}
