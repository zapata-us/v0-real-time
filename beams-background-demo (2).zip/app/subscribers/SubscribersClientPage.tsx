"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import BeamsBackground from "@/components/beams-background"
import { TermsModal } from "@/components/terms-modal"
import {
  User,
  Clock,
  LogOut,
  BarChart3,
  ShieldCheck,
  Tag,
  CheckCircle2,
  CreditCard,
  ArrowLeft,
  TrendingUp,
  RefreshCw,
  DollarSign,
  Shield,
  Users,
  Store,
  Glasses,
  Building,
  Heart,
  ClipboardCheck,
  Lock,
  Search,
} from "lucide-react"

// Rolex serial number database - comprehensive list from 1926 to 2018
const SERIAL_YEAR_DATABASE = [
  { serial_number: "Random", year: 2018 },
  { serial_number: "Random", year: 2017 },
  { serial_number: "Random", year: 2016 },
  { serial_number: "Random", year: 2015 },
  { serial_number: "Random", year: 2014 },
  { serial_number: "Random", year: 2013 },
  { serial_number: "Random", year: 2012 },
  { serial_number: "Random", year: 2011 },
  { serial_number: "G", year: 2010 },
  { serial_number: "V", year: 2009 },
  { serial_number: "M OR V", year: 2008 },
  { serial_number: "M OR Z", year: 2007 },
  { serial_number: "D OR Z", year: 2006 },
  { serial_number: "D", year: 2005 },
  { serial_number: "F", year: 2005 },
  { serial_number: "F", year: 2004 },
  { serial_number: "F", year: 2003 },
  { serial_number: "Y", year: 2002 },
  { serial_number: "K OR Y", year: 2001 },
  { serial_number: "K,000,001", year: 2000 },
  { serial_number: "P,000,001", year: 2000 },
  { serial_number: "A,000,001", year: 1999 },
  { serial_number: "U,932,144", year: 1998 },
  { serial_number: "U,000,001", year: 1997 },
  { serial_number: "T,000,001", year: 1996 },
  { serial_number: "W,000,001", year: 1995 },
  { serial_number: "S,860,880", year: 1994 },
  { serial_number: "S,000,001", year: 1993 },
  { serial_number: "C,000,001", year: 1992 },
  { serial_number: "N,000,001", year: 1991 },
  { serial_number: "X,000,001", year: 1991 },
  { serial_number: "E,000,001", year: 1990 },
  { serial_number: "L,980,000", year: 1989 },
  { serial_number: "R,598,200", year: 1988 },
  { serial_number: "R,000,001", year: 1987 },
  { serial_number: "9,400,000", year: 1987 },
  { serial_number: "8,900,000", year: 1986 },
  { serial_number: "8,614,000", year: 1985 },
  { serial_number: "8,070,022", year: 1984 },
  { serial_number: "7,400,000", year: 1983 },
  { serial_number: "7,100,000", year: 1982 },
  { serial_number: "6,520,870", year: 1981 },
  { serial_number: "6,434,000", year: 1980 },
  { serial_number: "5,737,030", year: 1979 },
  { serial_number: "5,000,000", year: 1978 },
  { serial_number: "5,008,000", year: 1977 },
  { serial_number: "4,115,299", year: 1976 },
  { serial_number: "3,862,196", year: 1975 },
  { serial_number: "3,567,927", year: 1974 },
  { serial_number: "3,200,268", year: 1973 },
  { serial_number: "2,890,459", year: 1972 },
  { serial_number: "2,589,295", year: 1971 },
  { serial_number: "2,241,882", year: 1970 },
  { serial_number: "1,900,000", year: 1969 },
  { serial_number: "1,752,000", year: 1968 },
  { serial_number: "1,538,435", year: 1967 },
  { serial_number: "1,200,000", year: 1966 },
  { serial_number: "1,100,000", year: 1965 },
  { serial_number: "1,008,889", year: 1964 },
  { serial_number: "824,000", year: 1963 },
  { serial_number: "744,000", year: 1962 },
  { serial_number: "643,153", year: 1961 },
  { serial_number: "516,000", year: 1960 },
  { serial_number: "399,453", year: 1959 },
  { serial_number: "328,000", year: 1958 },
  { serial_number: "224,000", year: 1957 },
  { serial_number: "133,061", year: 1956 },
  { serial_number: "97,000", year: 1955 },
  { serial_number: "23,000", year: 1954 },
  { serial_number: "855,726", year: 1953 },
  { serial_number: "726,639", year: 1952 },
  { serial_number: "709,249", year: 1951 },
  { serial_number: "", year: 1950 },
  { serial_number: "", year: 1949 },
  { serial_number: "628,840", year: 1948 },
  { serial_number: "529,163", year: 1947 },
  { serial_number: "367,946", year: 1946 },
  { serial_number: "302,459", year: 1945 },
  { serial_number: "269,561", year: 1944 },
  { serial_number: "230,878", year: 1943 },
  { serial_number: "143,509", year: 1942 },
  { serial_number: "106,047", year: 1941 },
  { serial_number: "99,775", year: 1940 },
  { serial_number: "71,224", year: 1939 },
  { serial_number: "43,739", year: 1938 },
  { serial_number: "40,920", year: 1937 },
  { serial_number: "36,856", year: 1936 },
  { serial_number: "34,336", year: 1935 },
  { serial_number: "30,823", year: 1934 },
  { serial_number: "29,562", year: 1933 },
  { serial_number: "29,132", year: 1932 },
  { serial_number: "", year: 1931 },
  { serial_number: "23,186", year: 1930 },
  { serial_number: "", year: 1929 },
  { serial_number: "23,969", year: 1928 },
  { serial_number: "20,190", year: 1927 },
  { serial_number: "00,001", year: 1926 },
]

// Define privacy policy content as a structured object to avoid JSX parsing issues
const privacyPolicyContent = [
  {
    title: "Privacy Policy for Real Time",
    subtitle: "Effective Date: May 7, 2025",
    content: "",
  },
  {
    title: "1. Introduction",
    content:
      "Welcome to Real Time. We are committed to protecting your personal information and your right to privacy. This Privacy Policy outlines how we collect, use, disclose, and safeguard your information when you visit our website and subscribe to our services.",
  },
  {
    title: "2. Information We Collect",
    content:
      "We collect personal information that you voluntarily provide to us when registering for our services, expressing an interest in obtaining information about us or our products and services, or otherwise contacting us. The personal information we collect may include:\n\nPersonal Identifiers: Full name, email address, mailing address, phone number.\n\nAccount Information: Username, password, subscription details.\n\nPayment Information: Credit/debit card numbers, billing address.\n\nUsage Data: Information on how you use our website and services.\n\nMarketing Preferences: Your preferences in receiving marketing from us.",
  },
  {
    title: "3. How We Use Your Information",
    content:
      "We use the information we collect for various purposes, including:\n\nTo provide, operate, and maintain our services.\n\nTo improve, personalize, and expand our services.\n\nTo process transactions and send related information.\n\nTo communicate with you, including sending newsletters, marketing materials, and promotional offers.\n\nTo send you updates, security alerts, and administrative messages.\n\nTo comply with legal obligations and enforce our terms and policies.",
  },
  {
    title: "4. Sharing Your Information",
    content:
      "We may share your information with third parties in the following situations:\n\nService Providers: We may share your information with third-party vendors, service providers, contractors, or agents who perform services on our behalf.\n\nLegal Requirements: We may disclose your information if required to do so by law or in response to valid requests by public authorities.\n\nBusiness Transfers: In connection with any merger, sale of company assets, financing, or acquisition of all or a portion of our business.\n\nWe do not sell or rent your personal information to third parties for their marketing purposes.",
  },
  {
    title: "5. Cookies and Tracking Technologies",
    content:
      "We use cookies and similar tracking technologies to track the activity on our website and store certain information. Cookies are files with a small amount of data which may include an anonymous unique identifier.\n\nYou can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.",
  },
  {
    title: "6. Data Security",
    content:
      "We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, use, or disclosure. However, no method of transmission over the Internet or method of electronic storage is 100% secure.",
  },
  {
    title: "7. Your Data Protection Rights",
    content:
      "Depending on your location, you may have the following rights regarding your personal information:\n\nThe right to access – You have the right to request copies of your personal data.\n\nThe right to rectification – You have the right to request that we correct any information you believe is inaccurate.\n\nThe right to erasure – You have the right to request that we erase your personal data, under certain conditions.\n\nThe right to restrict processing – You have the right to request that we restrict the processing of your personal data, under certain conditions.\n\nThe right to object to processing – You have the right to object to our processing of your personal data, under certain conditions.\n\nThe right to data portability – You have the right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.",
  },
]

// Format the privacy policy content as a single string
const formatPrivacyPolicy = (sections) => {
  return sections
    .map((section) => {
      if (section.subtitle) {
        return `${section.title}\n${section.subtitle}\n\n${section.content}`
      }
      return `${section.title}\n\n${section.content}`
    })
    .join("\n\n")
}

export default function SubscribersClientPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loginEmail, setLoginEmail] = useState("")
  const [loginPassword, setLoginPassword] = useState("")
  const [activeTab, setActiveTab] = useState("login")
  const [showSubscriptionDetails, setShowSubscriptionDetails] = useState(false)
  const [isTermsModalOpen, setIsTermsModalOpen] = useState(false)
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false)

  // Serial number search states
  const [serialNumber, setSerialNumber] = useState("")
  const [searchResult, setSearchResult] = useState<{ year: number; match: string; exact: boolean } | null>(null)
  const [isSearching, setIsSearching] = useState(false)

  // Subscription form states
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [error, setError] = useState("")
  const [selectedPlan, setSelectedPlan] = useState("annual")
  const [paymentMethod, setPaymentMethod] = useState("credit")
  const [yearlyBilling, setYearlyBilling] = useState(true)
  const [showReviewSection, setShowReviewSection] = useState(false)
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")

  // Add iOS-specific optimizations
  useEffect(() => {
    // Check if running on iOS
    const isIOS =
      /iPad|iPhone|iPod/.test(typeof navigator !== "undefined" ? navigator.userAgent : "") && !(window as any).MSStream

    if (isIOS) {
      // Fix for iOS input zooming
      const viewportMeta = document.querySelector('meta[name="viewport"]')
      if (viewportMeta) {
        viewportMeta.setAttribute("content", "width=device-width, initial-scale=1, maximum-scale=1")
      }

      // Fix for iOS 100vh issue
      const fixIOSHeight = () => {
        const vh = window.innerHeight * 0.01
        document.documentElement.style.setProperty("--vh", `${vh}px`)
      }

      fixIOSHeight()
      window.addEventListener("resize", fixIOSHeight)
      window.addEventListener("orientationchange", fixIOSHeight)

      return () => {
        window.removeEventListener("resize", fixIOSHeight)
        window.removeEventListener("orientationchange", fixIOSHeight)
      }
    }
  }, [])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, you would validate credentials against a backend
    if (loginEmail && loginPassword) {
      console.log("Logging in with:", loginEmail)
      setIsLoggedIn(true)
    }
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setLoginEmail("")
    setLoginPassword("")
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Validate email
    if (!email) {
      setError("Email is required")
      return
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address")
      return
    }

    // Validate address if printed version is selected
    // Show review section instead of submitting immediately
    setShowReviewSection(true)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleFinalSubmit = () => {
    // Show loading state
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSuccess(true)

      // Reset form after success
      setTimeout(() => {
        setIsSuccess(false)
        setEmail("")
        setShowReviewSection(false)
      }, 5000)
    }, 1500)
  }

  // Function to normalize serial number for comparison
  const normalizeSerial = (serial: string): string => {
    return serial.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()
  }

  // Function to check if a serial number matches a pattern
  const matchesPattern = (input: string, pattern: string): boolean => {
    // Handle empty patterns
    if (!pattern) return false

    // Handle "Random" pattern (2011-2018)
    if (pattern.toLowerCase() === "random") {
      // Check if input is 8 digits (typical for random serials)
      return /^\d{8}$/.test(normalizeSerial(input))
    }

    // Handle patterns with "OR" (e.g., "M OR V")
    if (pattern.includes("OR")) {
      const options = pattern.split("OR").map((opt) => normalizeSerial(opt.trim()))
      const normalizedInput = normalizeSerial(input)

      // Check if input starts with any of the options
      return options.some((opt) => normalizedInput.startsWith(opt))
    }

    // Handle numeric ranges (e.g., "9,400,000")
    if (/[\d,]+/.test(pattern)) {
      const patternNum = Number.parseInt(pattern.replace(/,/g, ""))
      const inputNum = Number.parseInt(normalizeSerial(input))

      // If both can be parsed as numbers, compare them
      if (!isNaN(patternNum) && !isNaN(inputNum)) {
        return inputNum >= patternNum
      }
    }

    // Default: check if input starts with the pattern
    return normalizeSerial(input).startsWith(normalizeSerial(pattern))
  }

  // Simplify the findBestMatch function
  const findBestMatch = (input: string) => {
    const normalizedInput = normalizeSerial(input)
    
    // First try to find an exact match
    const exactMatch = SERIAL_YEAR_DATABASE.find(entry => 
      matchesPattern(normalizedInput, entry.serial_number)
    )
    
    if (exactMatch) {
      return {
        year: exactMatch.year,
        match: exactMatch.serial_number,
        exact: true,
      }
    }
    
    // If no exact match and input is 8 digits (modern Rolex), return most recent year
    if (/^\d{8}$/.test(normalizedInput)) {
      return {
        year: 2018,
        match: "Random",
        exact: false,
      }
    }
    
    // For other cases, try to find the closest match
    if (normalizedInput.length > 0) {
      const firstChar = normalizedInput[0]
      
      // Check for letter matches
      const letterMatch = SERIAL_YEAR_DATABASE.find(entry => 
        entry.serial_number && entry.serial_number.toUpperCase().startsWith(firstChar)
      )
      
      if (letterMatch) {
        return {
          year: letterMatch.year,
          match: letterMatch.serial_number,
          exact: false,
        }
      }
      
      // For numeric inputs, find closest numeric range
      if (/^\d+$/.test(normalizedInput)) {
        const inputNum = Number.parseInt(normalizedInput)
        
        let closestEntry = null
        let smallestDiff = Number.MAX_SAFE_INTEGER
        
        for (const entry of SERIAL_YEAR_DATABASE) {
          if (/[\d,]+/.test(entry.serial_number)) {
            const entryNum = Number.parseInt(entry.serial_number.replace(/,/g, ""))
            if (!isNaN(entryNum)) {
              const diff = Math.abs(inputNum - entryNum)
              if (diff < smallestDiff) {
                smallestDiff = diff
                closestEntry = entry
              }
            }
          }
        }
        
        if (closestEntry) {
          return {
            year: closestEntry.year,
            match: closestEntry.serial_number,
            exact: false,
          }
        }
      }
    }
    
    // If all else fails, return null
    return null
  }

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!serialNumber.trim()) return

    setIsSearching(true)

    // Simulate API delay
    setTimeout(() => {
      const result = findBestMatch(serialNumber)
      setSearchResult(result)
      setIsSearching(false)
    }, 300)
  }

  // iOS specific styles
  const iosStyles = `
    .ios-safe-inset {
      padding-left: env(safe-area-inset-left);
      padding-right: env(safe-area-inset-right);
    }
    
    @supports (-webkit-touch-callout: none) {
      .min-h-screen {
        min-height: 100vh;
        min-height: calc(var(--vh, 1vh) * 100);
      }
      
      input, select, textarea {
        font-size: 16px !important; /* Prevents iOS zoom on focus */
      }
      
      button, a, [role="button"] {
        cursor: pointer;
        touch-action: manipulation;
        min-height: 44px; /* iOS HIG minimum touch target */
      }
    }
  `

  // Animation styles
  const animateFadeIn = {
    "@keyframes fadeIn": {
      "0%": { opacity: 0, transform: "translateY(10px)" },
      "100%": { opacity: 1, transform: "translateY(0)" },
    },
    ".animate-fade-in": {
      animation: "fadeIn 0.6s ease-out forwards",
    },
  }

  // Calculate pricing
  const monthlyPrice = 12.49
  const yearlyPrice = 99.99
  const totalPrice = yearlyBilling ? yearlyPrice : monthlyPrice

  if (showReviewSection) {
    return (
      <BeamsBackground>
        <style jsx global>{`${iosStyles}`}</style>
        <div className="relative min-h-screen w-full overflow-hidden">
          {/* Glass overlay */}
          <div className="absolute inset-0 bg-black/30 backdrop-blur-md z-0"></div>

          {/* Main content container */}
          <div className="relative z-10 container mx-auto px-4 py-16 md:py-24 animate-fade-in">
            {/* Back button */}
            <div className="mb-8">
              <button
                onClick={() => setShowReviewSection(false)}
                className="group inline-flex items-center text-white hover:text-amber-300 transition-colors"
              >
                <ArrowLeft className="h-4 w-4 mr-2 group-hover:-translate-x-1 transition-transform" />
                <span>Back to subscription form</span>
              </button>
            </div>

            {/* Page title */}
            <div className="text-center mb-12">
              <h1 className="text-3xl md:text-4xl font-bold mb-3 text-white">Complete Your Subscription</h1>
              <p className="text-lg text-white/80 max-w-2xl mx-auto">
                Review your plan details and payment information before confirming your subscription.
              </p>
            </div>

            {/* Main card */}
            <div className="max-w-5xl mx-auto">
              <div className="bg-black/40 backdrop-blur-xl rounded-2xl overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.3)] relative">
                {/* Card header */}
                <div className="bg-gradient-to-r from-amber-500/20 via-amber-600/10 to-transparent p-6 flex items-center">
                  <div className="h-10 w-10 rounded-full bg-amber-500/30 flex items-center justify-center mr-4">
                    <ClipboardCheck className="h-5 w-5 text-amber-400" />
                  </div>
                  <h2 className="text-xl font-semibold text-white">Review and subscribe</h2>
                </div>

                {/* Card content */}
                <div className="p-6 md:p-8">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-8 md:gap-12">
                    {/* Left column - Payment details */}
                    <div className="md:col-span-3 space-y-8">
                      {/* Billing toggle */}
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                        <div className="flex justify-between items-center mb-4">
                          <div>
                            <h3 className="font-medium text-white text-lg mb-1">Billing cycle</h3>
                            <p className="text-white/70 text-xs inline-block ml-2">(Choose billing cycle)</p>
                          </div>
                          <div className="relative inline-block w-14 h-7">
                            <input
                              type="checkbox"
                              id="toggle"
                              className="sr-only"
                              checked={yearlyBilling}
                              onChange={() => setYearlyBilling(!yearlyBilling)}
                            />
                            <label
                              htmlFor="toggle"
                              className={`absolute inset-0 rounded-full transition-all duration-300 cursor-pointer ${
                                yearlyBilling ? "bg-[#d4af37]" : "bg-gray-600"
                              } shadow-inner`}
                            >
                              <span
                                className={`absolute inset-y-1 left-1 bg-white w-5 h-5 rounded-full transition-all duration-300 shadow-md ${
                                  yearlyBilling ? "transform translate-x-7" : ""
                                }`}
                              ></span>
                            </label>
                          </div>
                        </div>

                        <div className="bg-black/20 backdrop-blur-md rounded-xl p-3 transition-all duration-300 shadow-sm">
                          {yearlyBilling ? (
                            <div className="animate-fadeIn">
                              <div className="flex justify-between items-center mb-2">
                                <div className="flex items-center">
                                  <span className="bg-[#d4af37]/20 p-1 rounded-full mr-2 flex items-center justify-center">
                                    <CheckCircle2 className="h-3.5 w-3.5 text-[#d4af37]" />
                                  </span>
                                  <span className="font-medium text-white text-sm">Annual Plan</span>
                                </div>
                                <span className="text-white font-medium text-sm">$99.99/year</span>
                              </div>
                              <div className="bg-[#d4af37]/10 backdrop-blur-sm rounded-lg p-2 flex items-center shadow-inner">
                                <span className="text-[#d4af37] text-sm mr-1.5 flex-shrink-0">💰</span>
                                <span className="text-white/90 text-sm">Save 33% vs monthly billing</span>
                              </div>
                            </div>
                          ) : (
                            <div className="animate-fadeIn">
                              <div className="flex justify-between items-center mb-2">
                                <div className="flex items-center">
                                  <span className="bg-gray-500/20 p-1 rounded-full mr-2 flex items-center justify-center">
                                    <CheckCircle2 className="h-3.5 w-3.5 text-gray-400" />
                                  </span>
                                  <span className="font-medium text-white text-sm">Monthly Plan</span>
                                </div>
                                <span className="text-white font-medium text-sm">$12.49/month</span>
                              </div>
                              <div className="bg-gray-500/10 backdrop-blur-sm rounded-lg p-2 flex items-center shadow-inner">
                                <span className="text-gray-400 text-sm mr-1.5 flex-shrink-0">ℹ️</span>
                                <span className="text-white/90 text-sm">Switch to yearly to save 20% plus</span>
                              </div>
                            </div>
                          )}
                        </div>

                        <style jsx>{`
                        @keyframes fadeIn {
                          from { opacity: 0; transform: translateY(5px); }
                          to { opacity: 1; transform: translateY(0); }
                        }
                        .animate-fadeIn {
                          animation: fadeIn 0.3s cubic-bezier(0.23, 1, 0.32, 1) forwards;
                        }
                      `}</style>
                      </div>

                      {/* Payment method */}
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300">
                        <h3 className="font-medium text-white text-lg mb-4">Payment method</h3>

                        <div className="grid grid-cols-1 gap-4">
                          <div
                            className={`flex items-center p-4 rounded-xl cursor-pointer transition-all h-16 ${
                              paymentMethod === "credit"
                                ? "bg-amber-500/20 border border-amber-400/30"
                                : "bg-black/20 hover:bg-black/30 border border-transparent"
                            }`}
                            onClick={() => setPaymentMethod("credit")}
                          >
                            <div className="flex items-center">
                              <div
                                className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${
                                  paymentMethod === "credit" ? "border-amber-400" : "border-white/40"
                                }`}
                              >
                                {paymentMethod === "credit" && (
                                  <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                                )}
                              </div>
                              <span className="text-white whitespace-nowrap text-sm">Credit or debit card</span>
                            </div>
                            <div className="ml-auto flex space-x-2">
                              <div className="w-8 h-5 bg-white rounded flex items-center justify-center shadow-sm">
                                <span className="text-blue-800 text-xs font-bold">VISA</span>
                              </div>
                              <div className="w-8 h-5 bg-white rounded flex items-center justify-center shadow-sm">
                                <div className="flex items-center">
                                  <div className="w-2 h-2 bg-red-500 rounded-full opacity-80"></div>
                                  <div className="w-2 h-2 bg-yellow-500 rounded-full -ml-1 opacity-80"></div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div
                            className={`flex items-center p-4 rounded-xl cursor-pointer transition-all h-16 ${
                              paymentMethod === "paypal"
                                ? "bg-amber-500/20 border border-amber-400/30"
                                : "bg-black/20 hover:bg-black/30 border border-transparent"
                            }`}
                            onClick={() => setPaymentMethod("paypal")}
                          >
                            <div className="flex items-center">
                              <div
                                className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${
                                  paymentMethod === "paypal" ? "border-amber-400" : "border-white/40"
                                }`}
                              >
                                {paymentMethod === "paypal" && (
                                  <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                                )}
                              </div>
                              <span className="text-white">PayPal</span>
                            </div>
                            <div className="ml-auto">
                              <div className="w-8 h-5 bg-white rounded flex items-center justify-center shadow-sm">
                                <div className="bg-blue-600 w-full h-full rounded flex items-center justify-center">
                                  <span className="text-white text-xs font-bold">PP</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {paymentMethod === "credit" && (
                          <div className="mt-6 space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="block text-white/80 text-sm font-medium mb-2">First name</label>
                                <Input
                                  value={firstName || "Bryan"}
                                  onChange={(e) => setFirstName(e.target.value)}
                                  className="bg-black/30 text-white border-white/10 focus:border-amber-400 focus:ring-amber-400/20"
                                />
                              </div>
                              <div>
                                <label className="block text-white/80 text-sm font-medium mb-2">Last name</label>
                                <Input
                                  value={lastName || "Zapata"}
                                  onChange={(e) => setLastName(e.target.value)}
                                  className="bg-black/30 text-white border-white/10 focus:border-amber-400 focus:ring-amber-400/20"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="block text-white/80 text-sm font-medium mb-2">Card number</label>
                              <div className="relative">
                                <Input
                                  placeholder="•••• •••• •••• ••••"
                                  className="bg-black/30 text-white border-white/10 focus:border-amber-400 focus:ring-amber-400/20 pr-10"
                                />
                                <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/40" />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="block text-white/80 text-sm font-medium mb-2">MM / YY</label>
                                <Input
                                  placeholder="MM / YY"
                                  className="bg-black/30 text-white border-white/10 focus:border-amber-400 focus:ring-amber-400/20"
                                />
                              </div>
                              <div>
                                <label className="block text-white/80 text-sm font-medium mb-2">CVV</label>
                                <div className="relative">
                                  <Input
                                    placeholder="123"
                                    className="bg-black/30 text-white border-white/10 focus:border-amber-400 focus:ring-amber-400/20 pr-10"
                                  />
                                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/40 cursor-help">
                                    ℹ️
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right column - Plan summary */}
                    <div className="md:col-span-2">
                      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 sticky top-5 shadow-lg hover:shadow-xl transition-all duration-300">
                        <div className="border-b border-white/10 pb-4 mb-4">
                          <h3 className="font-medium text-white text-lg mb-1">Order summary</h3>
                          <p className="text-white/70 text-sm">Review your subscription details</p>
                        </div>

                        <div className="space-y-4 mb-5">
                          <div className="flex items-start">
                            <div className="flex-1">
                              <h4 className="font-medium text-white">
                                Real Time {yearlyBilling ? "Annual" : "Monthly"}
                              </h4>
                              <p className="text-white/70 text-sm">Full access</p>
                            </div>
                            <div className="text-right">
                              <p className="text-white font-medium">${yearlyBilling ? "99.99" : "12.49"}</p>
                              <p className="text-white/70 text-xs">{yearlyBilling ? "/year" : "/month"}</p>
                            </div>
                          </div>

                          <div className="flex items-center text-sm text-white/70">
                            <div className="w-3 h-3 rounded-full bg-[#d4af37] mr-2"></div>
                            <div className="flex-1">First billing today</div>
                            <div>${yearlyBilling ? "99.99" : "12.49"}</div>
                          </div>

                          {yearlyBilling && (
                            <div className="bg-green-900/30 text-green-400 text-sm p-3 rounded-lg flex items-center">
                              <CheckCircle2 className="h-4 w-4 mr-2 flex-shrink-0" />
                              <span>You save $49.89 with annual billing</span>
                            </div>
                          )}
                        </div>

                        <div className="border-t border-white/10 pt-4 mb-5">
                          <div className="flex justify-between mb-1">
                            <p className="text-white font-medium">Total due today</p>
                            <p className="text-white font-medium">${yearlyBilling ? "99.99" : "12.49"}</p>
                          </div>
                          <p className="text-white/50 text-xs">Plus applicable taxes</p>
                        </div>

                        <div className="mb-4 flex items-center justify-center gap-3">
                          <label className="flex items-center space-x-3 cursor-pointer group">
                            <div className="relative">
                              <input
                                type="checkbox"
                                id="terms-checkbox"
                                checked={termsAccepted}
                                onChange={(e) => setTermsAccepted(e.target.checked)}
                                className="sr-only"
                              />
                              <div className={`w-5 h-5 rounded bg-black/40 border ${termsAccepted ? 'border-[#d4af37]' : 'border-white/20'} transition-colors group-hover:border-[#d4af37]/70`}>
                                {termsAccepted && (
                                  <CheckCircle2 className="h-4 w-4 text-[#d4af37] absolute top-0.5 left-0.5" />
                                )}
                              </div>
                            </div>
                            <span className="text-white/70 text-xs">
                              I agree to the{" "}
                              <a
                                href="#"
                                className="text-[#d4af37] hover:underline"
                                onClick={(e) => {
                                  e.preventDefault()
                                  setIsTermsModalOpen(true)
                                }}
                              >
                                Terms
                              </a>{" "}
                              and{" "}
                              <a
                                href="#"
                                className="text-[#d4af37] hover:underline"
                                onClick={(e) => {
                                  e.preventDefault()
                                  setIsPrivacyModalOpen(true)
                                }}
                              >
                                Privacy Policy
                              </a>
                            </span>
                          </label>
                        </div>

                        <Button
                          onClick={handleFinalSubmit}
                          className={`w-full py-6 font-medium text-base transition-all ${
                            isSuccess
                              ? "bg-green-500 hover:bg-green-600 text-white"
                              : "bg-[#d4af37] hover:bg-[#b8860b] text-black"
                          } hover:transform hover:scale-[1.02] min-h-[56px] rounded-xl ${!termsAccepted ? 'opacity-50 cursor-not-allowed' : ''}`}
                          disabled={isSubmitting || isSuccess || !termsAccepted}
                        >
                          {isSubmitting ? (
                            <div className="flex items-center justify-center">
                              <div className="animate-spin h-5 w-5 border-2 border-current border-t-transparent rounded-full mr-2"></div>
                              Processing...
                            </div>
                          ) : isSuccess ? (
                            <div className="flex items-center justify-center">
                              <CheckCircle2 className="h-5 w-5 mr-2" />
                              Subscription Confirmed!
                            </div>
                          ) : (
                            <div className="flex items-center justify-center">
                              <CreditCard className="h-5 w-5 mr-2" />
                              Subscribe Now
                            </div>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </BeamsBackground>
    )
  }

  return (
    <BeamsBackground>
      <style jsx global>{`${iosStyles}`}</style>
      <div className="min-h-screen pt-12 pb-8 px-3 bg-white/10 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400 whitespace-nowrap overflow-hidden">
              {isLoggedIn ? "Subscriber Dashboard" : "Subscriber Portal"}
            </h1>
            <p className="text-lg text-white/80 max-w-3xl mx-auto">
              {isLoggedIn
                ? `Welcome back, ${loginEmail.split("@")[0]}. Access your exclusive subscriber content below.`
                : "Access exclusive content and features with your REAL TIME subscription."}
            </p>
          </div>

          {isLoggedIn ? (
            // Dashboard Content
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* User Profile Card */}
              <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-4">
                    <div className="h-16 w-16 rounded-full bg-white/10 flex items-center justify-center">
                      <User className="h-8 w-8 text-white/70" />
                    </div>
                    <div>
                      <CardTitle>{loginEmail.split("@")[0]}</CardTitle>
                      <CardDescription className="text-white/70">Subscriber</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <div className="grid gap-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-white/70">Membership Status</span>
                      <span className="font-medium text-emerald-400">Active</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-white/70">Next Billing Date</span>
                      <span>June 15, 2025</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-white/70">Subscription Plan</span>
                      <span>Premium Annual</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full bg-black/30 text-white hover:bg-white/10 hover:text-white transition-all duration-200 flex items-center justify-center gap-2 py-2 rounded-lg"
                    onClick={() => setShowSubscriptionDetails(!showSubscriptionDetails)}
                  >
                    <CreditCard className="h-4 w-4" />
                    Manage Subscription
                  </Button>
                </CardFooter>
                {showSubscriptionDetails && (
                  <div className="px-6 pb-6 pt-2 animate-fade-in">
                    <div className="bg-black/20 rounded-lg p-4 space-y-4">
                      <h3 className="font-medium text-white text-sm">Payment & Subscription Details</h3>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-white/70">Payment Method</span>
                          <span className="text-white flex items-center">
                            <CreditCard className="h-3 w-3 mr-1.5" />
                            •••• •••• •••• 4242
                          </span>
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-white/70">Billing Cycle</span>
                          <span className="text-white">Annual</span>
                        </div>

                        <div className="flex justify-between text-sm">
                          <span className="text-white/70">Next Payment</span>
                          <span className="text-white">$99.99 on June 15, 2025</span>
                        </div>
                      </div>

                      <div className="pt-2 flex justify-between">
                        <Button variant="link" className="text-amber-400 hover:text-amber-300 p-0 h-auto text-xs">
                          Update Payment Method
                        </Button>

                        <Button variant="link" className="text-rose-400 hover:text-rose-300 p-0 h-auto text-xs">
                          Cancel Subscription
                        </Button>
                      </div>
                    </div>

                    <div className="mt-4">
                      <Button
                        variant="link"
                        className="text-white/70 hover:text-white p-0 h-auto text-xs flex items-center"
                        onClick={handleLogout}
                      >
                        <LogOut className="h-3 w-3 mr-1.5" />
                        Sign Out
                      </Button>
                    </div>
                  </div>
                )}
              </Card>

              {/* Main Dashboard Area */}
              <div className="lg:col-span-2 grid gap-6">
                {/* Recent Activity */}
                <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Clock className="h-5 w-5 mr-2" />
                      Recent Activity
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          icon: ShieldCheck,
                          text: "Authentication request completed for Rolex Submariner",
                          time: "2 hours ago",
                        },
                        { icon: BarChart3, text: "Market report for May 2025 is now available", time: "1 day ago" },
                        {
                          icon: Tag,
                          text: "Private sale: Patek Philippe Nautilus available for 48 hours",
                          time: "3 days ago",
                        },
                      ].map((item, i) => (
                        <div key={i} className="flex items-start gap-3 pb-3">
                          <div className="h-8 w-8 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                            <item.icon className="h-4 w-4 text-white/70" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm">{item.text}</p>
                            <p className="text-xs text-white/50">{item.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Exclusive Content */}
                <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                  <CardHeader>
                    <CardTitle>Exclusive Content</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-6 p-4 bg-black/20 rounded-lg">
                      <h3 className="text-lg font-medium mb-3 flex items-center">
                        <Search className="h-5 w-5 mr-2 text-amber-400" />
                        Watch Serial Number Lookup
                      </h3>
                      <p className="text-sm text-white/70 mb-4">
                        Find the production year of your Rolex watch by entering the serial number below.
                      </p>
                      <form onSubmit={handleSearch} className="space-y-4">
                        <div className="flex gap-2">
                          <Input
                            type="text"
                            placeholder="Enter serial number"
                            value={serialNumber}
                            onChange={(e) => setSerialNumber(e.target.value)}
                            className="bg-black/30 border-0 text-white"
                          />
                          <Button
                            type="submit"
                            disabled={isSearching || !serialNumber.trim()}
                            className="bg-amber-400 text-black hover:bg-amber-500"
                          >
                            {isSearching ? "Searching..." : "Search"}
                          </Button>
                        </div>

                        {searchResult && (
                          <div className="p-3 bg-white/10 rounded-lg animate-fade-in">
                            <div className="flex justify-between items-center">
                              <div>
                                <p className="text-sm text-white/70">Production Year:</p>
                                <p className="text-xl font-bold text-white">{searchResult.year}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-sm text-white/70">Match Type:</p>
                                <p className="text-sm text-white">
                                  {searchResult.exact ? "Exact Match" : "Approximate Match"}
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </form>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        { title: "Investment Guide 2025", description: "Top watches to invest in this year" },
                        { title: "Authentication Masterclass", description: "Learn to spot fakes like an expert" },
                        { title: "Market Trends Report", description: "Q2 2025 luxury watch market analysis" },
                        {
                          title: "Collector Interview Series",
                          description: "Exclusive interviews with top collectors",
                        },
                      ].map((item, i) => (
                        <div
                          key={i}
                          className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                        >
                          <h3 className="font-medium mb-1">{item.title}</h3>
                          <p className="text-sm text-white/70">{item.description}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            // Login/Subscribe Tabs
            <div className="max-w-md mx-auto mb-12 flex flex-col items-center">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="flex w-full justify-center items-center bg-black/10 backdrop-blur-md rounded-full p-1 shadow-inner shadow-black/20">
                  <TabsTrigger
                    value="login"
                    className="flex-1 rounded-full py-2 text-white/70 data-[state=active]:bg-white/20 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all duration-200 flex justify-center items-center"
                  >
                    Login
                  </TabsTrigger>
                  <TabsTrigger
                    value="subscribe"
                    className="flex-1 rounded-full py-2 text-white/70 data-[state=active]:bg-white/20 data-[state=active]:text-white data-[state=active]:shadow-sm transition-all duration-200 flex justify-center items-center"
                  >
                    Subscribe
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="login">
                  <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                    <CardHeader>
                      <CardTitle>Subscriber Login</CardTitle>
                      <CardDescription className="text-white/70">
                        Enter your credentials to access your account
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleLogin}>
                        <div className="grid gap-4">
                          <div className="grid gap-2">
                            <Label htmlFor="email" className="text-white">
                              Email
                            </Label>
                            <Input
                              id="email"
                              type="email"
                              placeholder="name@example.com"
                              className="bg-black/20 text-white border-0"
                              required
                              value={loginEmail}
                              onChange={(e) => setLoginEmail(e.target.value)}
                            />
                          </div>
                          <div className="grid gap-2">
                            <div className="flex items-center justify-between">
                              <Label htmlFor="password" className="text-white">
                                Password
                              </Label>
                              <a href="/forgot-password" className="text-sm text-white/70 hover:text-white">
                                Forgot password?
                              </a>
                            </div>
                            <Input
                              id="password"
                              type="password"
                              className="bg-black/20 text-white border-0"
                              required
                              value={loginPassword}
                              onChange={(e) => setLoginPassword(e.target.value)}
                            />
                          </div>
                          <Button type="submit" className="bg-white text-black hover:bg-white/90">
                            Login
                          </Button>
                        </div>
                      </form>
                    </CardContent>
                  </Card>
                </TabsContent>
                <TabsContent value="subscribe">
                  <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                    <CardHeader>
                      <CardTitle>Subscribe to Real Time</CardTitle>
                      <CardDescription className="text-white/70">Complete the form below to subscribe</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-6 mb-6">
                        {/* Plan selection */}
                        <div className="space-y-4">
                          <h3 className="font-medium text-white text-base">Choose Your Plan</h3>

                          <div className="grid grid-cols-1 gap-4">
                            <div
                              className={`p-4 rounded-lg cursor-pointer transition-all hover:transform hover:scale-[1.01] ${
                                selectedPlan === "monthly"
                                  ? "bg-amber-400/20 border border-amber-400/50"
                                  : "bg-black/30 hover:bg-black/40 border-0"
                              }`}
                              onClick={() => setSelectedPlan("monthly")}
                            >
                              <div className="flex justify-between items-start">
                                <h3 className="font-medium text-white text-base">Monthly</h3>
                                {selectedPlan === "monthly" && <CheckCircle2 className="h-5 w-5 text-amber-400" />}
                              </div>
                              <div className="mb-2">
                                <span className="text-2xl font-bold text-white">$12.49</span>
                                <span className="text-white/70 text-sm">/month</span>
                              </div>
                              <p className="text-white/70 text-xs">Billed monthly, cancel anytime</p>
                            </div>

                            <div
                              className={`p-4 rounded-lg cursor-pointer transition-all relative hover:transform hover:scale-[1.01] ${
                                selectedPlan === "annual"
                                  ? "bg-amber-400/20 border border-amber-400/50"
                                  : "bg-black/30 hover:bg-black/40 border-0"
                              }`}
                              onClick={() => setSelectedPlan("annual")}
                            >
                              {/* Best value badge */}
                              <div className="absolute -top-2 -right-2 bg-amber-400 text-black text-xs font-bold px-2 py-0.5 rounded-md shadow-lg">
                                BEST VALUE
                              </div>

                              <div className="flex justify-between items-start">
                                <h3 className="font-medium text-white text-base">Annual</h3>
                                {selectedPlan === "annual" && <CheckCircle2 className="h-5 w-5 text-amber-400" />}
                              </div>
                              <div className="mb-2">
                                <span className="text-2xl font-bold text-white">$99.99</span>
                                <span className="text-white/70 text-sm">/year</span>
                              </div>
                              <p className="text-white/70 text-xs">Save over 15% with yearly access</p>
                            </div>
                          </div>
                        </div>

                        {/* Basic information */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="grid gap-2">
                            <Label htmlFor="firstName" className="text-white">
                              First Name*
                            </Label>
                            <Input
                              id="firstName"
                              type="text"
                              placeholder="First Name"
                              className="bg-black/20 text-white border-0"
                              required
                              value={firstName}
                              onChange={(e) => setFirstName(e.target.value)}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="lastName" className="text-white">
                              Last Name*
                            </Label>
                            <Input
                              id="lastName"
                              type="text"
                              placeholder="Last Name"
                              className="bg-black/20 text-white border-0"
                              required
                              value={lastName}
                              onChange={(e) => setLastName(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="grid gap-2">
                          <Label htmlFor="subEmail" className="text-white">
                            Email*
                          </Label>
                          <Input
                            id="subEmail"
                            type="email"
                            placeholder="email@example.com"
                            className="bg-black/20 text-white border-0"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                          />
                        </div>

                        {error && <p className="text-rose-400 text-sm">{error}</p>}

                        <Button
                          onClick={() => setShowReviewSection(true)}
                          className="bg-amber-400 hover:bg-amber-500 text-black hover:transform hover:scale-[1.02] transition-all py-5"
                        >
                          <CreditCard className="h-5 w-5 mr-2" />
                          Continue to Payment
                        </Button>
                      </div>

                      
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}

          {/* Benefits Section - Only show when not logged in */}
          {!isLoggedIn && (
            <>
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold mb-2 text-white">Subscriber Benefits</h2>
                <p className="text-white/70 mb-8">Enjoy these exclusive features with your subscription</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                <CardHeader>
                  <CardTitle>Market Insights</CardTitle>
                  <CardDescription className="text-white/70">Real-time market data and analysis</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Get exclusive access to market trends, price predictions, and expert analysis on luxury
                    timepieces.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                <CardHeader>
                  <CardTitle>Authentication Services</CardTitle>
                  <CardDescription className="text-white/70">Verify your timepiece authenticity</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>Submit photos and details of your watches for authentication by our team of experts.</p>
                </CardContent>
              </Card>

              <Card className="bg-black/30 backdrop-blur-md text-white border-0">
                <CardHeader>
                  <CardTitle>Private Sales</CardTitle>
                  <CardDescription className="text-white/70">Exclusive access to limited releases</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>
                    Be the first to know about and purchase rare timepieces before they're available to the public.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Additional Benefits Section */}
            <div className="bg-black/30 backdrop-blur-md rounded-xl p-8 transition-all duration-300 shadow-xl hover:shadow-yellow-600/10 group mb-12 border-0">
              <h2 className="text-2xl font-semibold text-white mb-6 flex items-center">
                <span className="bg-yellow-600/10 p-2 rounded-lg mr-3 group-hover:bg-yellow-600/20 transition-colors">
                  <TrendingUp className="h-6 w-6 text-yellow-600" />
                </span>
                The Real Time Advantage:
              </h2>

              <div className="space-y-6">
                <div className="flex items-start transition-transform hover:translate-x-1 duration-200">
                  <div className="bg-yellow-600/10 p-2 rounded-lg mr-3 hover:bg-yellow-600/20 transition-colors">
                    <RefreshCw className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <p className="text-white/90 text-base leading-relaxed">
                      It's for this reason that the Real Time watch price list is updated with current values on a
                      monthly basis, always reflecting the market and maximizing profits.
                    </p>
                  </div>
                </div>

                <div className="flex items-start transition-transform hover:translate-x-1 duration-200">
                  <div className="bg-yellow-600/10 p-2 rounded-lg mr-3 hover:bg-yellow-600/20 transition-colors">
                    <DollarSign className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <p className="text-white/90 text-base leading-relaxed">
                      Just $12.49 per month affords access to this invaluable pricing data resource, along with the
                      support of our watch pricing, authentication, and repair specialists at any time via our
                      toll-free number.
                    </p>
                  </div>
                </div>

                <div className="flex items-start transition-transform hover:translate-x-1 duration-200">
                  <div className="bg-yellow-600/10 p-2 rounded-lg mr-3 hover:bg-yellow-600/20 transition-colors">
                    <Shield className="h-5 w-5 text-yellow-600" />
                  </div>
                  <div>
                    <p className="text-white/90 text-base leading-relaxed">
                      Trusted by watch dealers, appraisers, pawnbrokers, and avid watch collectors for over thirty
                      years, Real Time pays for itself in the pricing mistakes it'll ensure you avoid.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8">
                <p className="text-white font-medium mb-3 text-lg flex items-center">
                  <span className="bg-yellow-600/10 p-2 rounded-lg mr-3 group-hover:bg-yellow-600/20 transition-colors">
                    <Users className="h-5 w-5 text-yellow-600" />
                  </span>
                  Trusted By Industry Professionals:
                </p>
                <div className="flex flex-wrap gap-3">
                  <span className="bg-black/40 text-white/90 text-sm px-4 py-2 rounded-full hover:bg-yellow-600/20 hover:text-white transition-colors cursor-default flex items-center">
                    <Store className="h-4 w-4 mr-2" />
                    Watch Dealers
                  </span>
                  <span className="bg-black/40 text-white/90 text-sm px-4 py-2 rounded-full hover:bg-yellow-600/20 hover:text-white transition-colors cursor-default flex items-center">
                    <Glasses className="h-4 w-4 mr-2" />
                    Appraisers
                  </span>
                  <span className="bg-black/40 text-white/90 text-sm px-4 py-2 rounded-full hover:bg-yellow-600/20 hover:text-white transition-colors cursor-default flex items-center">
                    <Building className="h-4 w-4 mr-2" />
                    Pawnbrokers
                  </span>
                  <span className="bg-black/40 text-white/90 text-sm px-4 py-2 rounded-full hover:bg-yellow-600/20 hover:text-white transition-colors cursor-default flex items-center">
                    <Heart className="h-4 w-4 mr-2" />
                    Collectors
                  </span>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
    <TermsModal 
      isOpen={isTermsModalOpen} 
      onClose={() => setIsTermsModalOpen(false)} 
    />
    <TermsModal
      isOpen={isPrivacyModalOpen}
      onClose={() => setIsPrivacyModalOpen(false)}
      title="Privacy Policy"
      content={formatPrivacyPolicy(privacyPolicyContent)}
    />
  )
}
