"use server"

import { fetchSubscribers, updateSubscriptionStatus, deleteSubscriber } from "@/lib/subscriber-service"
import type { SubscriberType } from "@/types/subscriber"

export type SubscriberFilters = {
  status?: string[]
  type?: string[]
  search?: string
}

export type SubscriberListResponse = {
  subscribers: SubscriberType[]
  totalCount: number
  pageCount: number
}

export async function getSubscribers(
  page = 1,
  pageSize = 10,
  filters: SubscriberFilters = {},
): Promise<SubscriberListResponse> {
  try {
    const offset = (page - 1) * pageSize

    // First get all subscribers to calculate total count with filters
    const allSubscribers = await fetchSubscribers({
      filters,
    })

    // Then get paginated results
    const paginatedSubscribers = await fetchSubscribers({
      offset,
      limit: pageSize,
      filters,
    })

    return {
      subscribers: paginatedSubscribers,
      totalCount: allSubscribers.length,
      pageCount: Math.ceil(allSubscribers.length / pageSize),
    }
  } catch (error) {
    console.error("Failed to fetch subscribers:", error)
    throw new Error("Failed to fetch subscribers. Please try again later.")
  }
}

export async function updateSubscriber(id: string, data: Partial<SubscriberType>): Promise<SubscriberType> {
  try {
    // In a real implementation, you would update all subscriber fields
    // For this demo, we'll just use the updateSubscriptionStatus function
    if (data.subscriptionStatus) {
      return await updateSubscriptionStatus(
        id,
        data.subscriptionStatus as "active" | "cancelled" | "expired" | "pending",
      )
    }
    throw new Error("Only status updates are supported in this demo")
  } catch (error) {
    console.error("Failed to update subscriber:", error)
    throw new Error("Failed to update subscriber. Please try again later.")
  }
}

export async function removeSubscriber(id: string): Promise<void> {
  try {
    await deleteSubscriber(id)
  } catch (error) {
    console.error("Failed to delete subscriber:", error)
    throw new Error("Failed to delete subscriber. Please try again later.")
  }
}

// This would be a server endpoint in a real application
export async function createSubscriber(formData: FormData): Promise<SubscriberType> {
  try {
    // Validate the form data
    const firstName = formData.get("firstName") as string
    const lastName = formData.get("lastName") as string
    const email = formData.get("email") as string
    const companyName = formData.get("companyName") as string
    const phone = formData.get("phone") as string
    const subscriptionType = formData.get("subscriptionType") as "monthly" | "annual"

    if (!firstName || !lastName || !email) {
      throw new Error("First name, last name, and email are required")
    }

    // In a real app, this would create a new subscriber in the database
    // For this demo, we'll just return a mock subscriber
    const now = Date.now()
    const newSubscriber: SubscriberType = {
      id: `sub_${now}`,
      firstName,
      lastName,
      email,
      companyName: companyName || "",
      phone: phone || "",
      address: {
        street: "",
        city: "",
        state: "",
        zip: "",
        country: "USA",
      },
      username: `${firstName.toLowerCase()}${lastName.toLowerCase().substring(0, 1)}`,
      subscriptionType: subscriptionType || "monthly",
      subscriptionStatus: "active",
      startDate: now,
      nextBillingDate: subscriptionType === "annual" ? now + 365 * 24 * 60 * 60 * 1000 : now + 30 * 24 * 60 * 60 * 1000,
      createdAt: now,
      lastLoginAt: undefined,
    }

    // In a real app, you would add this to the database
    // For this demo, we'll just return the new subscriber
    return newSubscriber
  } catch (error) {
    console.error("Failed to create subscriber:", error)
    throw new Error(error instanceof Error ? error.message : "Failed to create subscriber. Please try again later.")
  }
}
