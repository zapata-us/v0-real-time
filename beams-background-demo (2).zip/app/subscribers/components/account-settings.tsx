"use client"

import type React from "react"

import { useState } from "react"
import { User, Mail, Phone, Building, Key, Save, Bell, Shield, AlertTriangle, CreditCard } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

interface UserType {
  id: string
  name: string
  email: string
}

interface AccountSettingsProps {
  user: UserType
}

export function AccountSettings({ user }: AccountSettingsProps) {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isPasswordSubmitting, setIsPasswordSubmitting] = useState(false)
  const [notifications, setNotifications] = useState({
    email: true,
    marketing: false,
    security: true,
    billing: true,
  })

  const handleUpdateProfile = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call to update profile
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      })
    }, 1500)
  }

  const handleUpdatePassword = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsPasswordSubmitting(true)

    // Simulate API call to update password
    setTimeout(() => {
      setIsPasswordSubmitting(false)
      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
      })
    }, 1500)
  }

  const handleToggleNotification = (key: keyof typeof notifications) => {
    setNotifications((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))

    toast({
      title: "Notification preferences updated",
      description: `${key.charAt(0).toUpperCase() + key.slice(1)} notifications ${
        notifications[key] ? "disabled" : "enabled"
      }.`,
    })
  }

  return (
    <div className="space-y-6">
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
          <CardDescription className="text-white/70">
            Update your personal information and contact details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label htmlFor="firstName">First Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                  <Input
                    id="firstName"
                    defaultValue={user?.name?.split(" ")[0] || "John"}
                    className="pl-10 bg-white/10 border-white/20 text-white"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <Label htmlFor="lastName">Last Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                  <Input
                    id="lastName"
                    defaultValue={user?.name?.split(" ")[1] || "Doe"}
                    className="pl-10 bg-white/10 border-white/20 text-white"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="email">Email Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  id="email"
                  type="email"
                  defaultValue={user?.email || "john.doe@example.com"}
                  className="pl-10 bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  id="phone"
                  type="tel"
                  defaultValue="+1 (305) 555-1234"
                  className="pl-10 bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="company">Company (Optional)</Label>
              <div className="relative">
                <Building className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  id="company"
                  defaultValue="REAL TIME Watches"
                  className="pl-10 bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <Button type="submit" disabled={isSubmitting} className="bg-white text-black hover:bg-white/90">
                {isSubmitting ? (
                  <>
                    <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Security</CardTitle>
          <CardDescription className="text-white/70">Update your password and security settings</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpdatePassword} className="space-y-4">
            <div className="space-y-1">
              <Label htmlFor="currentPassword">Current Password</Label>
              <div className="relative">
                <Key className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  id="currentPassword"
                  type="password"
                  required
                  className="pl-10 bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>

            <Separator className="bg-white/10 my-4" />

            <div className="space-y-1">
              <Label htmlFor="newPassword">New Password</Label>
              <div className="relative">
                <Key className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  id="newPassword"
                  type="password"
                  required
                  className="pl-10 bg-white/10 border-white/20 text-white"
                />
              </div>
              <p className="text-xs text-white/50 mt-1">
                Password must be at least 8 characters and include a number and special character
              </p>
            </div>

            <div className="space-y-1">
              <Label htmlFor="confirmPassword">Confirm New Password</Label>
              <div className="relative">
                <Key className="absolute left-3 top-3 h-4 w-4 text-white/50" />
                <Input
                  id="confirmPassword"
                  type="password"
                  required
                  className="pl-10 bg-white/10 border-white/20 text-white"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <Button type="submit" disabled={isPasswordSubmitting} className="bg-white text-black hover:bg-white/90">
                {isPasswordSubmitting ? (
                  <>
                    <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                    Updating...
                  </>
                ) : (
                  <>
                    <Key className="mr-2 h-4 w-4" />
                    Update Password
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
          <CardDescription className="text-white/70">Manage how and when we contact you</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center">
                  <Mail className="h-5 w-5 text-white/70" />
                </div>
                <div>
                  <h4 className="font-medium">Email Notifications</h4>
                  <p className="text-sm text-white/70">Receive email updates about your subscription</p>
                </div>
              </div>
              <Switch checked={notifications.email} onCheckedChange={() => handleToggleNotification("email")} />
            </div>

            <Separator className="bg-white/10" />

            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center">
                  <Bell className="h-5 w-5 text-white/70" />
                </div>
                <div>
                  <h4 className="font-medium">Marketing Communications</h4>
                  <p className="text-sm text-white/70">Receive offers, promotions and updates</p>
                </div>
              </div>
              <Switch checked={notifications.marketing} onCheckedChange={() => handleToggleNotification("marketing")} />
            </div>

            <Separator className="bg-white/10" />

            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-white/70" />
                </div>
                <div>
                  <h4 className="font-medium">Security Alerts</h4>
                  <p className="text-sm text-white/70">Get notified about security events</p>
                </div>
              </div>
              <Switch checked={notifications.security} onCheckedChange={() => handleToggleNotification("security")} />
            </div>

            <Separator className="bg-white/10" />

            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center">
                  <CreditCard className="h-5 w-5 text-white/70" />
                </div>
                <div>
                  <h4 className="font-medium">Billing Notifications</h4>
                  <p className="text-sm text-white/70">Get updates about your billing and receipts</p>
                </div>
              </div>
              <Switch checked={notifications.billing} onCheckedChange={() => handleToggleNotification("billing")} />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Account Actions</CardTitle>
          <CardDescription className="text-white/70">Manage your account settings and preferences</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                </div>
                <div>
                  <h4 className="font-medium">Cancel Subscription</h4>
                  <p className="text-sm text-white/70">Pause or cancel your current subscription</p>
                </div>
              </div>
              <Button variant="outline" size="sm" className="text-white border-white/20 hover:bg-white/10">
                Manage
              </Button>
            </div>

            <Separator className="bg-white/10" />

            <div className="flex items-center justify-between py-2">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-rose-500/20 flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-rose-500" />
                </div>
                <div>
                  <h4 className="font-medium text-rose-500">Delete Account</h4>
                  <p className="text-sm text-white/70">Permanently delete your account and all associated data</p>
                </div>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="text-rose-500 border-white/20 hover:bg-rose-500/10">
                    Delete Account
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-white/10 border-white/20 text-white">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription className="text-white/70">
                      This action cannot be undone. This will permanently delete your account and remove all your data
                      from our servers.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="bg-transparent text-white border-white/20 hover:bg-white/10">
                      Cancel
                    </AlertDialogCancel>
                    <AlertDialogAction className="bg-rose-500 text-white hover:bg-rose-600">
                      Delete Account
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
