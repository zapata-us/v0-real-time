"use client"

import type React from "react"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { createSubscriber } from "../actions"
import { useToast } from "@/hooks/use-toast"

interface AddSubscriberFormProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export default function AddSubscriberForm({ isOpen, onClose, onSuccess }: AddSubscriberFormProps) {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [subscriptionType, setSubscriptionType] = useState("monthly")
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateForm = (formData: FormData) => {
    const newErrors: Record<string, string> = {}

    const firstName = formData.get("firstName") as string
    const lastName = formData.get("lastName") as string
    const email = formData.get("email") as string

    if (!firstName?.trim()) {
      newErrors.firstName = "First name is required"
    }

    if (!lastName?.trim()) {
      newErrors.lastName = "Last name is required"
    }

    if (!email?.trim()) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Email is invalid"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (isSubmitting) return

    const form = e.currentTarget
    const formData = new FormData(form)

    // Add the subscription type
    formData.set("subscriptionType", subscriptionType)

    // Validate the form
    if (!validateForm(formData)) {
      return
    }

    setIsSubmitting(true)

    try {
      await createSubscriber(formData)
      toast({
        title: "Subscriber added",
        description: "The new subscriber has been successfully added.",
      })
      form.reset()
      onSuccess()
    } catch (error) {
      toast({
        title: "Failed to add subscriber",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white/10 backdrop-blur-md border-white/20 text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle>Add New Subscriber</DialogTitle>
          <DialogDescription className="text-white/70">
            Enter the subscriber's details below to create a new subscription
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName" className={errors.firstName ? "text-rose-500" : ""}>
                First Name *
              </Label>
              <Input
                id="firstName"
                name="firstName"
                placeholder="John"
                required
                className={`bg-white/5 border-white/20 text-white ${errors.firstName ? "border-rose-500" : ""}`}
              />
              {errors.firstName && <p className="text-rose-500 text-xs mt-1">{errors.firstName}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName" className={errors.lastName ? "text-rose-500" : ""}>
                Last Name *
              </Label>
              <Input
                id="lastName"
                name="lastName"
                placeholder="Doe"
                required
                className={`bg-white/5 border-white/20 text-white ${errors.lastName ? "border-rose-500" : ""}`}
              />
              {errors.lastName && <p className="text-rose-500 text-xs mt-1">{errors.lastName}</p>}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className={errors.email ? "text-rose-500" : ""}>
              Email *
            </Label>
            <Input
              id="email"
              name="email"
              type="email"
              placeholder="john.doe@example.com"
              required
              className={`bg-white/5 border-white/20 text-white ${errors.email ? "border-rose-500" : ""}`}
            />
            {errors.email && <p className="text-rose-500 text-xs mt-1">{errors.email}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">Company Name</Label>
              <Input
                id="companyName"
                name="companyName"
                placeholder="Acme Inc."
                className="bg-white/5 border-white/20 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                name="phone"
                placeholder="(555) 123-4567"
                className="bg-white/5 border-white/20 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="subscriptionType">Subscription Type *</Label>
            <Select value={subscriptionType} onValueChange={setSubscriptionType}>
              <SelectTrigger id="subscriptionType" className="bg-white/5 border-white/20 text-white">
                <SelectValue placeholder="Select subscription type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="monthly">Monthly ($12.49/month)</SelectItem>
                <SelectItem value="annual">Annual ($99.99/year)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="ghost"
              onClick={onClose}
              disabled={isSubmitting}
              className="bg-transparent text-white border-white/20 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-white text-black hover:bg-white/90">
              {isSubmitting ? "Creating..." : "Add Subscriber"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
