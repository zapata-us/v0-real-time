"use client"

import { useState } from "react"
import { Download, FileText, Receipt, ExternalLink, Search, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Invoice {
  id: string
  date: Date
  amount: number
  status: string
  description: string
}

// Invoice row component
function InvoiceRow({
  invoice,
  formatDate,
  getStatusBadge,
}: {
  invoice: Invoice
  formatDate: (date: Date) => string
  getStatusBadge: (status: string) => JSX.Element
}) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 p-4 hover:bg-white/5 rounded-lg transition-colors">
      <div className="col-span-3 flex items-center">
        <FileText className="h-4 w-4 text-white/30 mr-2 md:hidden" />
        <div>
          <div className="font-medium md:hidden">Invoice</div>
          <div>{invoice.id}</div>
        </div>
      </div>

      <div className="col-span-3">
        <div className="font-medium md:hidden">Date</div>
        <div>{formatDate(invoice.date)}</div>
      </div>

      <div className="col-span-3">
        <div className="font-medium md:hidden">Description</div>
        <div>{invoice.description}</div>
      </div>

      <div className="col-span-1">
        <div className="font-medium md:hidden">Amount</div>
        <div>${invoice.amount.toFixed(2)}</div>
      </div>

      <div className="col-span-1">
        <div className="font-medium md:hidden">Status</div>
        <div>{getStatusBadge(invoice.status)}</div>
      </div>

      <div className="col-span-1 flex justify-end items-center space-x-2">
        <Button variant="ghost" size="icon" className="h-8 w-8 text-white/70 hover:text-white">
          <Download className="h-4 w-4" />
          <span className="sr-only">Download</span>
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-white/70 hover:text-white">
          <ExternalLink className="h-4 w-4" />
          <span className="sr-only">View</span>
        </Button>
      </div>
    </div>
  )
}

export function BillingHistory() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [yearFilter, setYearFilter] = useState("all")

  // Mock billing history data
  const invoices: Invoice[] = [
    {
      id: "INV-2023-0012",
      date: new Date("2023-12-15"),
      amount: 499.99,
      status: "paid",
      description: "Annual Premium Subscription",
    },
    {
      id: "INV-2023-0011",
      date: new Date("2023-06-15"),
      amount: 49.99,
      status: "paid",
      description: "Monthly Premium Subscription",
    },
    {
      id: "INV-2022-0010",
      date: new Date("2022-12-15"),
      amount: 499.99,
      status: "paid",
      description: "Annual Premium Subscription",
    },
    {
      id: "INV-2022-0009",
      date: new Date("2022-06-15"),
      amount: 399.99,
      status: "paid",
      description: "Annual Basic Subscription",
    },
    {
      id: "INV-2021-0008",
      date: new Date("2021-12-15"),
      amount: 49.99,
      status: "refunded",
      description: "Monthly Premium Subscription",
    },
  ]

  // Format date to readable string
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  // Get status badge based on payment status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return <Badge className="bg-emerald-500 hover:bg-emerald-600">Paid</Badge>
      case "pending":
        return <Badge className="bg-amber-500 hover:bg-amber-600">Pending</Badge>
      case "failed":
        return <Badge className="bg-rose-500 hover:bg-rose-600">Failed</Badge>
      case "refunded":
        return <Badge className="bg-blue-500 hover:bg-blue-600">Refunded</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  // Filter invoices based on search query and filters
  const filteredInvoices = invoices.filter((invoice) => {
    // Filter by search query
    const matchesSearch =
      searchQuery === "" ||
      invoice.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      invoice.description.toLowerCase().includes(searchQuery.toLowerCase())

    // Filter by status
    const matchesStatus = statusFilter === "all" || invoice.status === statusFilter

    // Filter by year
    const invoiceYear = invoice.date.getFullYear().toString()
    const matchesYear = yearFilter === "all" || invoiceYear === yearFilter

    return matchesSearch && matchesStatus && matchesYear
  })

  // Get unique years from invoices for the year filter
  const years = [...new Set(invoices.map((invoice) => invoice.date.getFullYear().toString()))]

  return (
    <div className="space-y-6">
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div className="space-y-1">
            <CardTitle>Billing Summary</CardTitle>
            <CardDescription className="text-white/70">Your subscription and payment information</CardDescription>
          </div>
          <Button variant="outline" className="text-white border-white/20 hover:bg-white/10 hover:text-white">
            <Receipt className="mr-2 h-4 w-4" />
            View Payment Methods
          </Button>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-white/5 rounded-lg p-4">
              <div className="space-y-1">
                <div className="text-white/70 text-sm">Current Plan</div>
                <div className="text-xl font-semibold">Annual Premium</div>
              </div>
              <div className="space-y-1">
                <div className="text-white/70 text-sm">Next Billing Date</div>
                <div className="text-xl font-semibold">May 15, 2024</div>
              </div>
              <div className="space-y-1">
                <div className="text-white/70 text-sm">Amount</div>
                <div className="text-xl font-semibold">$499.99/year</div>
              </div>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 bg-white/5 rounded-lg p-4">
                <div className="text-white/70 text-sm mb-1">Payment Method</div>
                <div className="flex items-center">
                  <div className="h-8 w-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded mr-3"></div>
                  <div>
                    <div className="font-medium">Visa ending in 4242</div>
                    <div className="text-sm text-white/50">Expires 12/2025</div>
                  </div>
                </div>
              </div>

              <div className="flex-1 bg-white/5 rounded-lg p-4">
                <div className="text-white/70 text-sm mb-1">Billing Address</div>
                <div>
                  <div className="font-medium">John Doe</div>
                  <div className="text-sm text-white/70">123 Watch Ave, Suite 100</div>
                  <div className="text-sm text-white/70">Miami, FL 33101</div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Invoice History</CardTitle>
          <CardDescription className="text-white/70">Your past invoices and payment history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
              <Input
                placeholder="Search invoices..."
                className="pl-9 bg-white/10 border-white/20 text-white"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <div className="w-40">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-white/20 text-white">
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                    <SelectItem value="refunded">Refunded</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-40">
                <Select value={yearFilter} onValueChange={setYearFilter}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue placeholder="Year" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-white/20 text-white">
                    <SelectItem value="all">All Years</SelectItem>
                    {years.map((year) => (
                      <SelectItem key={year} value={year}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button
                variant="outline"
                size="icon"
                className="text-white border-white/20 hover:bg-white/10"
                onClick={() => {
                  setSearchQuery("")
                  setStatusFilter("all")
                  setYearFilter("all")
                }}
              >
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="rounded-md border border-white/10">
            <div className="hidden md:grid grid-cols-12 gap-4 p-4 bg-white/5 text-white/70 text-sm font-medium">
              <div className="col-span-3">Invoice</div>
              <div className="col-span-3">Date</div>
              <div className="col-span-3">Description</div>
              <div className="col-span-1">Amount</div>
              <div className="col-span-1">Status</div>
              <div className="col-span-1 text-right">Actions</div>
            </div>

            <div className="divide-y divide-white/10">
              {filteredInvoices.length > 0 ? (
                filteredInvoices.map((invoice) => (
                  <InvoiceRow
                    key={invoice.id}
                    invoice={invoice}
                    formatDate={formatDate}
                    getStatusBadge={getStatusBadge}
                  />
                ))
              ) : (
                <div className="p-8 text-center text-white/70">No invoices found matching your filters.</div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
