"use client"

import type React from "react"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import type { SubscriberType } from "@/types/subscriber"
import { updateSubscriber } from "../actions"
import { useToast } from "@/hooks/use-toast"

interface EditSubscriberFormProps {
  subscriber: SubscriberType
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export default function EditSubscriberForm({ subscriber, isOpen, onClose, onSuccess }: EditSubscriberFormProps) {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [status, setStatus] = useState(subscriber.subscriptionStatus)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (isSubmitting) return
    setIsSubmitting(true)

    try {
      // For this demo, we're only updating the status
      // In a real app, you'd update all fields
      await updateSubscriber(subscriber.id, {
        subscriptionStatus: status as any,
      })

      toast({
        title: "Subscriber updated",
        description: `${subscriber.firstName} ${subscriber.lastName}'s subscription status has been updated.`,
      })

      onSuccess()
    } catch (error) {
      toast({
        title: "Failed to update subscriber",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white/10 backdrop-blur-md border-white/20 text-white max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit Subscriber</DialogTitle>
          <DialogDescription className="text-white/70">
            Update {subscriber.firstName} {subscriber.lastName}'s information
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input
                id="firstName"
                defaultValue={subscriber.firstName}
                disabled
                className="bg-white/5 border-white/20 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input
                id="lastName"
                defaultValue={subscriber.lastName}
                disabled
                className="bg-white/5 border-white/20 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              defaultValue={subscriber.email}
              disabled
              className="bg-white/5 border-white/20 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Subscription Status</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger id="status" className="bg-white/5 border-white/20 text-white">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-white/50 mt-1">Note: In this demo, only status can be updated.</p>
          </div>

          <DialogFooter className="pt-4">
            <Button
              type="button"
              variant="ghost"
              onClick={onClose}
              disabled={isSubmitting}
              className="bg-transparent text-white border-white/20 hover:bg-white/10 hover:text-white"
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-white text-black hover:bg-white/90">
              {isSubmitting ? "Updating..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
