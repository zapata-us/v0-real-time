"use client"

import type React from "react"

import { useState } from "react"
import { CreditCard, PlusCircle, Trash2, CheckCircle2, AlertCircle, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface PaymentCard {
  id: string
  type: string
  last4: string
  expMonth: number
  expYear: number
  isDefault: boolean
}

// Payment card component
function PaymentCardItem({
  card,
  onSetDefault,
  onDelete,
}: {
  card: PaymentCard
  onSetDefault: (id: string) => void
  onDelete: (id: string) => void
}) {
  // Get card icon based on card type
  const getCardIcon = (type: string) => {
    // In a real app, you would use actual card brand icons
    return (
      <div
        className={`h-8 w-12 rounded ${
          type === "visa"
            ? "bg-gradient-to-r from-blue-600 to-purple-600"
            : "bg-gradient-to-r from-red-600 to-orange-600"
        }`}
      ></div>
    )
  }

  return (
    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/5 rounded-lg p-4 border border-white/10">
      <div className="flex items-center gap-3">
        {getCardIcon(card.type)}
        <div>
          <div className="font-medium flex items-center">
            {card.type.charAt(0).toUpperCase() + card.type.slice(1)} ending in {card.last4}
            {card.isDefault && <Badge className="ml-2 bg-white/20 text-white hover:bg-white/30">Default</Badge>}
          </div>
          <div className="text-sm text-white/70">
            Expires {card.expMonth}/{card.expYear}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 w-full sm:w-auto">
        {!card.isDefault && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onSetDefault(card.id)}
            className="text-white border-white/20 hover:bg-white/10 hover:text-white sm:w-auto w-full"
          >
            <CheckCircle2 className="mr-2 h-4 w-4" />
            Set as Default
          </Button>
        )}
        <Button
          variant="outline"
          size="sm"
          onClick={() => onDelete(card.id)}
          className="text-rose-500 border-white/20 hover:bg-rose-500/10 hover:text-rose-500 sm:w-auto w-full"
          disabled={card.isDefault}
        >
          <Trash2 className="mr-2 h-4 w-4" />
          Remove
        </Button>
      </div>
    </div>
  )
}

// Add card form component
function AddCardForm({
  onSubmit,
  onCancel,
  isSubmitting,
}: {
  onSubmit: (e: React.FormEvent) => void
  onCancel: () => void
  isSubmitting: boolean
}) {
  const [cardNumber, setCardNumber] = useState("")
  const [cardName, setCardName] = useState("")
  const [expMonth, setExpMonth] = useState("")
  const [expYear, setExpYear] = useState("")
  const [cvc, setCvc] = useState("")

  // Format card number with spaces
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "")
    const matches = v.match(/\d{4,16}/g)
    const match = (matches && matches[0]) || ""
    const parts = []

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4))
    }

    if (parts.length) {
      return parts.join(" ")
    } else {
      return value
    }
  }

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedValue = formatCardNumber(e.target.value)
    setCardNumber(formattedValue)
  }

  // Generate month options
  const months = Array.from({ length: 12 }, (_, i) => {
    const month = i + 1
    return month < 10 ? `0${month}` : `${month}`
  })

  // Generate year options (current year + 20 years)
  const currentYear = new Date().getFullYear()
  const years = Array.from({ length: 21 }, (_, i) => `${currentYear + i}`)

  return (
    <form onSubmit={onSubmit} className="space-y-4 bg-white/5 rounded-lg p-6">
      <div className="space-y-1">
        <Label htmlFor="cardName">Name on Card</Label>
        <Input
          id="cardName"
          placeholder="John Doe"
          required
          className="bg-white/10 border-white/20 text-white"
          value={cardName}
          onChange={(e) => setCardName(e.target.value)}
        />
      </div>

      <div className="space-y-1">
        <Label htmlFor="cardNumber">Card Number</Label>
        <Input
          id="cardNumber"
          placeholder="1234 5678 9012 3456"
          required
          className="bg-white/10 border-white/20 text-white"
          value={cardNumber}
          onChange={handleCardNumberChange}
          maxLength={19}
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-1">
          <Label htmlFor="expMonth">Month</Label>
          <Select value={expMonth} onValueChange={setExpMonth}>
            <SelectTrigger id="expMonth" className="bg-white/10 border-white/20 text-white">
              <SelectValue placeholder="MM" />
            </SelectTrigger>
            <SelectContent className="bg-gray-900 border-white/20 text-white">
              {months.map((month) => (
                <SelectItem key={month} value={month}>
                  {month}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1">
          <Label htmlFor="expYear">Year</Label>
          <Select value={expYear} onValueChange={setExpYear}>
            <SelectTrigger id="expYear" className="bg-white/10 border-white/20 text-white">
              <SelectValue placeholder="YYYY" />
            </SelectTrigger>
            <SelectContent className="bg-gray-900 border-white/20 text-white">
              {years.map((year) => (
                <SelectItem key={year} value={year}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-1">
          <Label htmlFor="cvc">CVC</Label>
          <Input
            id="cvc"
            placeholder="123"
            required
            className="bg-white/10 border-white/20 text-white"
            value={cvc}
            onChange={(e) => setCvc(e.target.value.replace(/\D/g, ""))}
            maxLength={4}
          />
        </div>
      </div>

      <div className="flex items-center gap-2 text-white/70 text-sm mt-2">
        <Shield className="h-4 w-4 text-emerald-500" />
        Your payment information is encrypted and secure
      </div>

      <div className="pt-4 flex justify-end space-x-2">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          className="text-white border-white/20 hover:bg-white/10 hover:text-white"
          disabled={isSubmitting}
        >
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting} className="bg-white text-black hover:bg-white/90">
          {isSubmitting ? (
            <>
              <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
              Processing...
            </>
          ) : (
            "Add Card"
          )}
        </Button>
      </div>
    </form>
  )
}

export function PaymentMethods() {
  const { toast } = useToast()
  const [showAddCard, setShowAddCard] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [selectedCard, setSelectedCard] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Mock payment methods
  const paymentMethods: PaymentCard[] = [
    {
      id: "pm_1",
      type: "visa",
      last4: "4242",
      expMonth: 12,
      expYear: 2025,
      isDefault: true,
    },
    {
      id: "pm_2",
      type: "mastercard",
      last4: "5555",
      expMonth: 8,
      expYear: 2024,
      isDefault: false,
    },
  ]

  const handleAddCard = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call to add card
    setTimeout(() => {
      setIsSubmitting(false)
      setShowAddCard(false)
      toast({
        title: "Payment method added",
        description: "Your new card has been added successfully.",
      })
    }, 1500)
  }

  const handleDeleteCard = (cardId: string) => {
    setSelectedCard(cardId)
    setShowDeleteDialog(true)
  }

  const confirmDeleteCard = () => {
    // Simulate API call to delete card
    setTimeout(() => {
      setShowDeleteDialog(false)
      toast({
        title: "Payment method removed",
        description: "Your card has been removed successfully.",
      })
    }, 500)
  }

  const handleSetDefault = (cardId: string) => {
    // Simulate API call to set default card
    setTimeout(() => {
      toast({
        title: "Default payment method updated",
        description: "Your default payment method has been updated.",
      })
    }, 500)
  }

  return (
    <div className="space-y-6">
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div className="space-y-1">
            <CardTitle>Payment Methods</CardTitle>
            <CardDescription className="text-white/70">
              Manage your payment methods and billing information
            </CardDescription>
          </div>
          <Button
            onClick={() => setShowAddCard(true)}
            className="bg-white text-black hover:bg-white/90"
            disabled={showAddCard}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Payment Method
          </Button>
        </CardHeader>
        <CardContent className="pt-6">
          {showAddCard ? (
            <AddCardForm onSubmit={handleAddCard} onCancel={() => setShowAddCard(false)} isSubmitting={isSubmitting} />
          ) : (
            <div className="space-y-4">
              {paymentMethods.map((card) => (
                <PaymentCardItem
                  key={card.id}
                  card={card}
                  onSetDefault={handleSetDefault}
                  onDelete={handleDeleteCard}
                />
              ))}

              <div className="text-white/70 text-sm bg-amber-500/10 border border-amber-500/20 rounded-lg p-4 flex items-start">
                <AlertCircle className="h-5 w-5 text-amber-500 mr-2 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-amber-500">Important</p>
                  <p>
                    Your default payment method cannot be removed. To remove it, please set another payment method as
                    default first.
                  </p>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Billing Address</CardTitle>
          <CardDescription className="text-white/70">Your billing address for invoices and receipts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" defaultValue="John" className="bg-white/10 border-white/20 text-white" />
              </div>

              <div className="space-y-1">
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" defaultValue="Doe" className="bg-white/10 border-white/20 text-white" />
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="address1">Address Line 1</Label>
              <Input
                id="address1"
                defaultValue="123 Watch Ave, Suite 100"
                className="bg-white/10 border-white/20 text-white"
              />
            </div>

            <div className="space-y-1">
              <Label htmlFor="address2">Address Line 2 (Optional)</Label>
              <Input id="address2" className="bg-white/10 border-white/20 text-white" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label htmlFor="city">City</Label>
                <Input id="city" defaultValue="Miami" className="bg-white/10 border-white/20 text-white" />
              </div>

              <div className="space-y-1">
                <Label htmlFor="state">State</Label>
                <Input id="state" defaultValue="FL" className="bg-white/10 border-white/20 text-white" />
              </div>

              <div className="space-y-1">
                <Label htmlFor="zip">ZIP Code</Label>
                <Input id="zip" defaultValue="33101" className="bg-white/10 border-white/20 text-white" />
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button className="bg-white text-black hover:bg-white/90">
            <CreditCard className="mr-2 h-4 w-4" />
            Update Billing Information
          </Button>
        </CardFooter>
      </Card>

      {/* Delete Card Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-white/10 border-white/20 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Payment Method</AlertDialogTitle>
            <AlertDialogDescription className="text-white/70">
              Are you sure you want to remove this payment method? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-transparent text-white border-white/20 hover:bg-white/10 hover:text-white">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteCard} className="bg-rose-500 text-white hover:bg-rose-600">
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
