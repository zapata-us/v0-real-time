"use client"

import { useState, memo } from "react"
import { Check, X, HelpCircle, CreditCard } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { TermsModal } from "@/components/terms-modal"
import { useToast } from "@/hooks/use-toast"

interface PlanSelectionProps {
  isLoading: boolean
}

// Memoized feature item component to prevent unnecessary re-renders
const FeatureItem = memo(({ name, included }: { name: string; included: boolean }) => (
  <div className="flex items-start">
    {included ? (
      <Check className="h-5 w-5 text-emerald-500 mr-2 shrink-0" />
    ) : (
      <X className="h-5 w-5 text-rose-500 mr-2 shrink-0" />
    )}
    <div className="text-sm">
      {name}
      {name.includes("Limited") && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <HelpCircle className="h-3 w-3 inline ml-1 text-white/50" />
            </TooltipTrigger>
            <TooltipContent>
              <p className="w-[200px] text-xs">Limited to 10 lookups per month</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  </div>
))

FeatureItem.displayName = "FeatureItem"

// Memoized plan card component to prevent unnecessary re-renders
const PlanCard = memo(
  ({
    plan,
    selectedPlan,
    billingCycle,
    onSelect,
  }: {
    plan: any
    selectedPlan: string
    billingCycle: "monthly" | "annual"
    onSelect: (id: string) => void
  }) => {
    // Calculate savings percentage for annual billing
    const calculateSavings = (monthly: number, annual: number) => {
      const monthlyCost = monthly * 12
      const savings = ((monthlyCost - annual) / monthlyCost) * 100
      return Math.round(savings)
    }

    return (
      <Card
        className={`relative overflow-hidden border-2 transition-all duration-200 ${
          selectedPlan === plan.id ? "border-[#d4af37] bg-white/15" : "border-transparent bg-white/5 hover:bg-white/10"
        }`}
      >
        {plan.popular && (
          <div className="absolute top-0 right-0">
            <Badge className="rounded-none rounded-bl-lg bg-[#d4af37] text-black">Most Popular</Badge>
          </div>
        )}
        <CardHeader>
          <CardTitle>{plan.name}</CardTitle>
          <CardDescription className="text-white/70">{plan.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-3xl font-bold">
              ${billingCycle === "annual" ? plan.price.annual : plan.price.monthly}
            </div>
            <div className="text-white/70 text-sm">{billingCycle === "annual" ? "per year" : "per month"}</div>
            {billingCycle === "annual" && (
              <div className="text-emerald-400 text-xs mt-1">
                Save {calculateSavings(plan.price.monthly, plan.price.annual)}%
              </div>
            )}
          </div>

          <div className="space-y-2">
            {plan.features.map((feature: any) => (
              <FeatureItem key={feature.name} name={feature.name} included={feature.included} />
            ))}
          </div>
        </CardContent>
        <CardFooter>
          <Button
            onClick={() => onSelect(plan.id)}
            className={
              selectedPlan === plan.id
                ? "w-full bg-[#d4af37] hover:bg-[#c4a030] text-black"
                : "w-full bg-white/10 hover:bg-white/20 text-white"
            }
          >
            {selectedPlan === plan.id ? "Selected" : "Select Plan"}
          </Button>
        </CardFooter>
      </Card>
    )
  },
)

PlanCard.displayName = "PlanCard"

export function PlanSelection({ isLoading }: PlanSelectionProps) {
  const { toast } = useToast()
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("annual")
  const [selectedPlan, setSelectedPlan] = useState<string>("premium")
  const [showTerms, setShowTerms] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  // Mock plans data - moved outside component to prevent recreation on each render
  const plans = [
    {
      id: "basic",
      name: "Basic",
      description: "Essential features for casual watch enthusiasts",
      price: { monthly: 19.99, annual: 199.99 },
      features: [
        { name: "Rolex Serial Number Lookup (Limited)", included: true },
        { name: "Basic Market Price Data", included: true },
        { name: "Authentication Guides", included: true },
        { name: "Dealer Network Access", included: false },
        { name: "Authentication Certificates", included: false },
        { name: "Price Alerts", included: false },
      ],
    },
    {
      id: "premium",
      name: "Premium",
      description: "Complete access for serious collectors",
      price: { monthly: 49.99, annual: 499.99 },
      features: [
        { name: "Unlimited Rolex Serial Number Lookup", included: true },
        { name: "Real-time Market Price Data", included: true },
        { name: "Advanced Authentication Guides", included: true },
        { name: "Dealer Network Access", included: true },
        { name: "Authentication Certificates", included: true },
        { name: "Price Alerts", included: true },
      ],
      popular: true,
    },
    {
      id: "business",
      name: "Business",
      description: "Enterprise solutions for dealers and businesses",
      price: { monthly: 99.99, annual: 999.99 },
      features: [
        { name: "Unlimited Serial Number Lookup (All Brands)", included: true },
        { name: "Real-time Market Price Data", included: true },
        { name: "Advanced Authentication Guides", included: true },
        { name: "Dealer Network Access", included: true },
        { name: "Unlimited Authentication Certificates", included: true },
        { name: "Price Alerts", included: true },
      ],
    },
  ]

  const handlePlanChange = (planId: string) => {
    setSelectedPlan(planId)
  }

  const handleSubscribe = () => {
    setShowTerms(true)
  }

  const handleTermsAccepted = () => {
    setShowTerms(false)
    setIsProcessing(true)

    // Simulate API call to update subscription
    setTimeout(() => {
      setIsProcessing(false)
      toast({
        title: "Subscription updated",
        description: `You are now subscribed to the ${
          plans.find((p) => p.id === selectedPlan)?.name
        } plan (${billingCycle}).`,
      })
    }, 1000) // Reduced timeout for better performance
  }

  // Get the selected plan details
  const selectedPlanDetails = plans.find((p) => p.id === selectedPlan)

  return (
    <div className="space-y-6">
      <Card className="bg-white/10 border-white/20 text-white">
        <CardHeader>
          <CardTitle>{isLoading ? <Skeleton className="h-7 w-48" /> : "Choose Your Plan"}</CardTitle>
          <CardDescription className="text-white/70">
            {isLoading ? <Skeleton className="h-5 w-72" /> : "Select the subscription plan that best fits your needs"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-10 w-48" />
          ) : (
            <div className="flex items-center justify-center space-x-2 mb-8">
              <Label htmlFor="billing-toggle" className="text-white/70">
                Monthly Billing
              </Label>
              <Switch
                id="billing-toggle"
                checked={billingCycle === "annual"}
                onCheckedChange={(checked) => setBillingCycle(checked ? "annual" : "monthly")}
              />
              <Label htmlFor="billing-toggle" className="flex items-center">
                Annual Billing
                <Badge className="ml-2 bg-emerald-500 text-white border-none">Save 16-20%</Badge>
              </Label>
            </div>
          )}

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Skeleton className="h-[450px] w-full" />
              <Skeleton className="h-[450px] w-full" />
              <Skeleton className="h-[450px] w-full" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plans.map((plan) => (
                <PlanCard
                  key={plan.id}
                  plan={plan}
                  selectedPlan={selectedPlan}
                  billingCycle={billingCycle}
                  onSelect={handlePlanChange}
                />
              ))}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          {!isLoading && (
            <>
              <div className="text-white/70 text-sm text-center max-w-xl mx-auto">
                By subscribing, you agree to our Terms of Service and Privacy Policy. You can cancel your subscription
                at any time from your account settings.
              </div>
              <Button
                onClick={handleSubscribe}
                disabled={isProcessing}
                className="bg-[#d4af37] hover:bg-[#c4a030] text-black"
              >
                {isProcessing ? (
                  "Processing..."
                ) : (
                  <>
                    <CreditCard className="mr-2 h-4 w-4" />
                    Subscribe to {selectedPlanDetails?.name} Plan
                  </>
                )}
              </Button>
            </>
          )}
        </CardFooter>
      </Card>

      <TermsModal
        isOpen={showTerms}
        onClose={() => setShowTerms(false)}
        title="Subscription Terms & Conditions"
        onAccept={handleTermsAccepted}
      />
    </div>
  )
}
