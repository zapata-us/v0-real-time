import { Bell, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Subscriber {
  id: string
  name: string
  email: string
  subscriptionTier: string
  subscriptionStatus: string
}

interface SubscriberHeaderProps {
  user: Subscriber
}

export function SubscriberHeader({ user }: SubscriberHeaderProps) {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
      <div className="flex items-center gap-4">
        <div className="h-16 w-16 rounded-full bg-white/20 flex items-center justify-center text-white">
          <Bell className="h-8 w-8" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Welcome, {user.name}</h1>
          <div className="flex items-center gap-2 mt-1">
            <Badge className="bg-[#d4af37] text-black">Premium Subscriber</Badge>
            <span className="text-white/70 text-sm">Member since May 2023</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 w-full md:w-auto">
        <Button variant="outline" size="icon" className="text-white border-white/20 hover:bg-white/10 hover:text-white">
          <Bell className="h-5 w-5" />
          <span className="sr-only">Notifications</span>
        </Button>
        <Button
          variant="outline"
          className="text-white border-white/20 hover:bg-white/10 hover:text-white w-full md:w-auto"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  )
}
