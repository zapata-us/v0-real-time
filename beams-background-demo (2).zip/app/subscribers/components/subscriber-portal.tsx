"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LayoutDashboard, CreditCard, Receipt, Settings, LifeBuoy, Package } from "lucide-react"
import { SubscriberHeader } from "./subscriber-header"
import { SubscriptionDashboard } from "./subscription-dashboard"
import { SubscriptionPlans } from "./subscription-plans"
import { BillingHistory } from "./billing-history"
import { PaymentMethods } from "./payment-methods"
import { AccountSettings } from "./account-settings"
import { SupportSection } from "./support-section"

export function SubscriberPortal() {
  const [activeTab, setActiveTab] = useState("dashboard")

  // Mock user data - in a real app, this would come from an API or context
  const user = {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    subscriptionTier: "premium",
    subscriptionStatus: "active",
    subscriptionRenewalDate: "2024-05-15",
    createdAt: "2023-05-15",
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <SubscriberHeader user={user} />

        <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="mt-8">
          <TabsList className="grid grid-cols-3 md:grid-cols-6 bg-white/10 border border-white/20 rounded-lg p-1 mb-8">
            <TabsTrigger
              value="dashboard"
              className="flex items-center gap-2 text-white data-[state=active]:bg-white data-[state=active]:text-black"
            >
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger
              value="plans"
              className="flex items-center gap-2 text-white data-[state=active]:bg-white data-[state=active]:text-black"
            >
              <Package className="h-4 w-4" />
              <span className="hidden sm:inline">Plans</span>
            </TabsTrigger>
            <TabsTrigger
              value="billing"
              className="flex items-center gap-2 text-white data-[state=active]:bg-white data-[state=active]:text-black"
            >
              <Receipt className="h-4 w-4" />
              <span className="hidden sm:inline">Billing</span>
            </TabsTrigger>
            <TabsTrigger
              value="payment"
              className="flex items-center gap-2 text-white data-[state=active]:bg-white data-[state=active]:text-black"
            >
              <CreditCard className="h-4 w-4" />
              <span className="hidden sm:inline">Payment</span>
            </TabsTrigger>
            <TabsTrigger
              value="account"
              className="flex items-center gap-2 text-white data-[state=active]:bg-white data-[state=active]:text-black"
            >
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Account</span>
            </TabsTrigger>
            <TabsTrigger
              value="support"
              className="flex items-center gap-2 text-white data-[state=active]:bg-white data-[state=active]:text-black"
            >
              <LifeBuoy className="h-4 w-4" />
              <span className="hidden sm:inline">Support</span>
            </TabsTrigger>
          </TabsList>

          <div className="space-y-8">
            <TabsContent value="dashboard" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <SubscriptionDashboard user={user} />
            </TabsContent>

            <TabsContent value="plans" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <SubscriptionPlans user={user} />
            </TabsContent>

            <TabsContent value="billing" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <BillingHistory />
            </TabsContent>

            <TabsContent value="payment" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <PaymentMethods />
            </TabsContent>

            <TabsContent value="account" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <AccountSettings user={user} />
            </TabsContent>

            <TabsContent value="support" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <SupportSection />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  )
}
