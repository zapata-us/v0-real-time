"use client"

import { useState } from "react"
import { MoreHorizontal, Edit, Trash2, RefreshCw, Clock, CreditCard } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import type { SubscriberType } from "@/types/subscriber"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Skeleton } from "@/components/ui/skeleton"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Badge } from "@/components/ui/badge"
import EditSubscriberForm from "./edit-subscriber-form"
import { removeSubscriber } from "../actions"
import { useToast } from "@/hooks/use-toast"

interface SubscriberTableProps {
  subscribers: SubscriberType[]
  isLoading: boolean
  onRefresh: () => void
}

export default function SubscriberTable({ subscribers, isLoading, onRefresh }: SubscriberTableProps) {
  const { toast } = useToast()
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [selectedSubscriber, setSelectedSubscriber] = useState<SubscriberType | null>(null)

  const handleEdit = (subscriber: SubscriberType) => {
    setSelectedSubscriber(subscriber)
    setShowEditModal(true)
  }

  const handleDelete = (subscriber: SubscriberType) => {
    setSelectedSubscriber(subscriber)
    setShowDeleteDialog(true)
  }

  const confirmDelete = async () => {
    if (!selectedSubscriber) return

    try {
      await removeSubscriber(selectedSubscriber.id)
      toast({
        title: "Subscriber removed",
        description: `${selectedSubscriber.firstName} ${selectedSubscriber.lastName} has been removed.`,
      })
      onRefresh()
    } catch (error) {
      toast({
        title: "Failed to remove subscriber",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      })
    } finally {
      setShowDeleteDialog(false)
      setSelectedSubscriber(null)
    }
  }

  const handleRefresh = async () => {
    setIsRefreshing(true)
    await onRefresh()
    setIsRefreshing(false)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-emerald-500 hover:bg-emerald-600">Active</Badge>
      case "cancelled":
        return <Badge className="bg-rose-500 hover:bg-rose-600">Cancelled</Badge>
      case "expired":
        return <Badge className="bg-amber-500 hover:bg-amber-600">Expired</Badge>
      case "pending":
        return <Badge className="bg-blue-500 hover:bg-blue-600">Pending</Badge>
      default:
        return <Badge className="bg-gray-500 hover:bg-gray-600">{status}</Badge>
    }
  }

  return (
    <div className="overflow-hidden bg-white/5 backdrop-blur-sm rounded-lg border border-white/10">
      <div className="p-4 border-b border-white/10 flex justify-between items-center">
        <h2 className="text-lg font-medium text-white">Subscribers</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="text-white border-white/20 hover:bg-white/10 hover:text-white"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {/* Table header */}
      <div className="hidden md:grid grid-cols-12 gap-4 p-4 border-b border-white/10 text-white/70 text-sm font-medium">
        <div className="col-span-4">Name / Email</div>
        <div className="col-span-2">Subscription</div>
        <div className="col-span-2">Status</div>
        <div className="col-span-3">Billing Cycle</div>
        <div className="col-span-1 text-right">Actions</div>
      </div>

      {/* Loading state */}
      {isLoading && (
        <>
          {[...Array(5)].map((_, index) => (
            <div key={index} className="border-b border-white/10 p-4">
              <div className="flex flex-col md:grid md:grid-cols-12 md:gap-4 space-y-2 md:space-y-0">
                <div className="col-span-4">
                  <Skeleton className="h-5 w-36 mb-1" />
                  <Skeleton className="h-4 w-48" />
                </div>
                <div className="col-span-2">
                  <Skeleton className="h-5 w-20" />
                </div>
                <div className="col-span-2">
                  <Skeleton className="h-6 w-16" />
                </div>
                <div className="col-span-3">
                  <Skeleton className="h-5 w-32" />
                </div>
                <div className="col-span-1 text-right">
                  <Skeleton className="h-8 w-8 ml-auto" />
                </div>
              </div>
            </div>
          ))}
        </>
      )}

      {/* Subscriber rows */}
      {!isLoading &&
        subscribers.map((subscriber) => (
          <div key={subscriber.id} className="border-b border-white/10 p-4 hover:bg-white/5">
            <div className="flex flex-col md:grid md:grid-cols-12 md:gap-4 space-y-3 md:space-y-0">
              {/* Name and email */}
              <div className="col-span-4">
                <div className="font-medium text-white flex items-center">
                  {subscriber.firstName} {subscriber.lastName}
                </div>
                <div className="text-white/70 text-sm">{subscriber.email}</div>
                {subscriber.companyName && <div className="text-white/50 text-xs">{subscriber.companyName}</div>}
              </div>

              {/* Subscription type */}
              <div className="col-span-2 flex items-center">
                <CreditCard className="h-4 w-4 text-white/30 mr-2" />
                <span className="capitalize text-white">{subscriber.subscriptionType}</span>
              </div>

              {/* Status */}
              <div className="col-span-2 flex items-center">{getStatusBadge(subscriber.subscriptionStatus)}</div>

              {/* Billing cycle */}
              <div className="col-span-3 text-sm text-white/70 flex items-center">
                <Clock className="h-4 w-4 text-white/30 mr-2" />
                <div>
                  <div>
                    Next payment{" "}
                    {subscriber.subscriptionStatus === "active"
                      ? formatDistanceToNow(new Date(subscriber.nextBillingDate), { addSuffix: true })
                      : "N/A"}
                  </div>
                  <div className="text-xs text-white/50">
                    Started {formatDistanceToNow(new Date(subscriber.startDate), { addSuffix: true })}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="col-span-1 flex justify-end">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-white">
                      <span className="sr-only">Open menu</span>
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-[160px]">
                    <DropdownMenuItem onClick={() => handleEdit(subscriber)}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={() => handleDelete(subscriber)}
                      className="text-rose-500 focus:text-rose-500"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        ))}

      {/* Edit Modal */}
      {selectedSubscriber && (
        <EditSubscriberForm
          subscriber={selectedSubscriber}
          isOpen={showEditModal}
          onClose={() => {
            setShowEditModal(false)
            setSelectedSubscriber(null)
          }}
          onSuccess={() => {
            setShowEditModal(false)
            setSelectedSubscriber(null)
            onRefresh()
          }}
        />
      )}

      {/* Delete Confirmation */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription className="text-white/70">
              This will permanently delete {selectedSubscriber?.firstName} {selectedSubscriber?.lastName}'s subscription
              and all associated data. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-transparent text-white border-white/20 hover:bg-white/10 hover:text-white">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-rose-500 text-white hover:bg-rose-600">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
