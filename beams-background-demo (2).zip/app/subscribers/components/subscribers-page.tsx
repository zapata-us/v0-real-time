"use client"

import type React from "react"

import { useState, useEffect, useCallback, useTransition } from "react"
import { useSearchParams, useRouter, usePathname } from "next/navigation"
import { BeamsBackground } from "@/components/beams-background"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChevronLeft, ChevronRight, Search, PlusCircle, UserPlus, Filter, Users } from "lucide-react"
import { getSubscribers, type SubscriberFilters } from "../actions"
import AddSubscriberForm from "./add-subscriber-form"
import SubscriberTable from "./subscriber-table"
import { useToast } from "@/hooks/use-toast"

export default function SubscribersPage() {
  const [isPending, startTransition] = useTransition()
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const router = useRouter()
  const pathname = usePathname()

  const page = Number(searchParams.get("page") || "1")
  const pageSize = Number(searchParams.get("pageSize") || "10")
  const searchQuery = searchParams.get("search") || ""
  const statusFilter = searchParams.get("status") || ""
  const typeFilter = searchParams.get("type") || ""

  const [subscribers, setSubscribers] = useState([])
  const [totalCount, setTotalCount] = useState(0)
  const [pageCount, setPageCount] = useState(0)
  const [isLoading, setIsLoading] = useState(true)
  const [showAddForm, setShowAddForm] = useState(false)
  const [showFilters, setShowFilters] = useState(false)

  // Fetch subscribers with current filters and pagination
  const fetchData = useCallback(() => {
    setIsLoading(true)

    const filters: SubscriberFilters = {}
    if (searchQuery) filters.search = searchQuery
    if (statusFilter) filters.status = [statusFilter]
    if (typeFilter) filters.type = [typeFilter]

    startTransition(async () => {
      try {
        const result = await getSubscribers(page, pageSize, filters)
        setSubscribers(result.subscribers)
        setTotalCount(result.totalCount)
        setPageCount(result.pageCount)
      } catch (error) {
        toast({
          title: "Error fetching subscribers",
          description: error instanceof Error ? error.message : "Failed to load subscribers",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    })
  }, [page, pageSize, searchQuery, statusFilter, typeFilter, toast])

  // When params change, fetch data
  useEffect(() => {
    fetchData()
  }, [fetchData])

  // Update URL when filters or pagination change
  const setParams = useCallback(
    (params: Record<string, string>) => {
      const newParams = new URLSearchParams(searchParams.toString())

      // Update or delete each param based on value
      Object.entries(params).forEach(([key, value]) => {
        if (value) {
          newParams.set(key, value)
        } else {
          newParams.delete(key)
        }
      })

      router.push(`${pathname}?${newParams.toString()}`)
    },
    [searchParams, router, pathname],
  )

  // Handle page changes
  const handlePageChange = (newPage: number) => {
    setParams({ page: newPage.toString() })
  }

  // Handle page size changes
  const handlePageSizeChange = (newSize: string) => {
    setParams({ pageSize: newSize, page: "1" }) // Reset to page 1 when changing page size
  }

  // Handle search
  const handleSearch = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)
    const searchValue = formData.get("search") as string
    setParams({ search: searchValue, page: "1" }) // Reset to page 1 when searching
  }

  // Handle filter changes
  const handleFilterChange = (key: string, value: string) => {
    setParams({ [key]: value, page: "1" }) // Reset to page 1 when filtering
  }

  // Clear all filters
  const clearFilters = () => {
    setParams({
      search: "",
      status: "",
      type: "",
      page: "1",
    })
    setShowFilters(false)
  }

  // Handle subscriber added
  const handleSubscriberAdded = () => {
    fetchData()
    setShowAddForm(false)
    toast({
      title: "Subscriber added",
      description: "The new subscriber was added successfully",
    })
  }

  return (
    <BeamsBackground>
      <div className="container mx-auto py-8 px-4">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center">
              <Users className="mr-2 h-6 w-6" />
              Subscriber Management
            </h1>
            <p className="text-white/70">Manage your subscribers and subscription plans</p>
          </div>

          <Button onClick={() => setShowAddForm(true)} className="bg-white text-black hover:bg-white/90 shadow-lg">
            <UserPlus className="mr-2 h-4 w-4" />
            Add Subscriber
          </Button>
        </div>

        {/* Filters */}
        <div className="bg-white/5 backdrop-blur-sm rounded-lg border border-white/10 p-4 mb-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
            <form onSubmit={handleSearch} className="w-full sm:max-w-sm">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-white/50" />
                <Input
                  type="search"
                  name="search"
                  placeholder="Search subscribers..."
                  defaultValue={searchQuery}
                  className="pl-9 bg-white/10 border-white/10 text-white placeholder:text-white/50"
                />
              </div>
            </form>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                className="text-white border-white/20 hover:bg-white/10 hover:text-white"
              >
                <Filter className="mr-2 h-4 w-4" />
                Filters
              </Button>

              {(statusFilter || typeFilter || searchQuery) && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={clearFilters}
                  className="text-white/70 hover:text-white hover:bg-white/10"
                >
                  Clear All
                </Button>
              )}
            </div>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4 p-4 bg-white/5 rounded-lg animate-in fade-in duration-200">
              <div>
                <label className="text-sm text-white/70 mb-1 block">Status</label>
                <Select value={statusFilter} onValueChange={(value) => handleFilterChange("status", value)}>
                  <SelectTrigger className="bg-white/10 border-white/10 text-white">
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm text-white/70 mb-1 block">Subscription Type</label>
                <Select value={typeFilter} onValueChange={(value) => handleFilterChange("type", value)}>
                  <SelectTrigger className="bg-white/10 border-white/10 text-white">
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="annual">Annual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Active filters */}
          {(statusFilter || typeFilter) && (
            <div className="flex flex-wrap gap-2 mt-4">
              {statusFilter && (
                <Badge className="bg-white/10 text-white hover:bg-white/20 px-3 py-1">
                  Status: {statusFilter}
                  <button
                    onClick={() => handleFilterChange("status", "")}
                    className="ml-2 text-white/70 hover:text-white"
                  >
                    ×
                  </button>
                </Badge>
              )}

              {typeFilter && (
                <Badge className="bg-white/10 text-white hover:bg-white/20 px-3 py-1">
                  Type: {typeFilter}
                  <button
                    onClick={() => handleFilterChange("type", "")}
                    className="ml-2 text-white/70 hover:text-white"
                  >
                    ×
                  </button>
                </Badge>
              )}
            </div>
          )}
        </div>

        {/* Subscribers Table */}
        <SubscriberTable subscribers={subscribers} isLoading={isLoading || isPending} onRefresh={fetchData} />

        {/* Pagination */}
        {pageCount > 0 && (
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-white/70 text-sm">
              Showing {(page - 1) * pageSize + 1}-{Math.min(page * pageSize, totalCount)} of {totalCount} subscribers
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center">
                <Select value={pageSize.toString()} onValueChange={handlePageSizeChange}>
                  <SelectTrigger className="w-[120px] bg-white/10 border-white/10 text-white">
                    <SelectValue placeholder="10 per page" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 per page</SelectItem>
                    <SelectItem value="10">10 per page</SelectItem>
                    <SelectItem value="20">20 per page</SelectItem>
                    <SelectItem value="50">50 per page</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-1">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handlePageChange(page - 1)}
                  disabled={page <= 1 || isLoading}
                  className="text-white border-white/20 hover:bg-white/10 hover:text-white disabled:opacity-50"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>

                <div className="text-white mx-2">
                  {page} / {pageCount}
                </div>

                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => handlePageChange(page + 1)}
                  disabled={page >= pageCount || isLoading}
                  className="text-white border-white/20 hover:bg-white/10 hover:text-white disabled:opacity-50"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Empty state */}
        {!isLoading && subscribers.length === 0 && (
          <div className="text-center py-12 bg-white/5 backdrop-blur-sm rounded-lg border border-white/10">
            <Users className="mx-auto h-12 w-12 text-white/30" />
            <h3 className="mt-4 text-lg font-medium text-white">No subscribers found</h3>
            <p className="mt-1 text-white/70">
              {searchQuery || statusFilter || typeFilter
                ? "Try adjusting your filters to find subscribers"
                : "Add your first subscriber to get started"}
            </p>
            <div className="mt-6">
              <Button onClick={() => setShowAddForm(true)} className="bg-white text-black hover:bg-white/90">
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Subscriber
              </Button>

              {(searchQuery || statusFilter || typeFilter) && (
                <Button
                  variant="outline"
                  className="ml-3 text-white border-white/20 hover:bg-white/10 hover:text-white"
                  onClick={clearFilters}
                >
                  Clear Filters
                </Button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Add Subscriber Modal */}
      <AddSubscriberForm isOpen={showAddForm} onClose={() => setShowAddForm(false)} onSuccess={handleSubscriberAdded} />
    </BeamsBackground>
  )
}
