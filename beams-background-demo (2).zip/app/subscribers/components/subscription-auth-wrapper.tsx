"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { SubscriberSkeleton } from "./subscriber-skeleton"

export function SubscriptionAuthWrapper({ children }: { children: React.ReactNode }) {
  const { user, isLoading, isAuthenticated } = useAuth()
  const router = useRouter()
  const [isCheckingAuth, setIsCheckingAuth] = useState(true)

  useEffect(() => {
    // Check authentication status
    if (!isLoading) {
      if (!isAuthenticated) {
        // Redirect to login with return URL
        router.push(`/login?redirect=${encodeURIComponent("/subscribers")}`)
      }
      setIsCheckingAuth(false)
    }
  }, [isLoading, isAuthenticated, router])

  // Show loading state while checking authentication
  if (isLoading || isCheckingAuth) {
    return <SubscriberSkeleton />
  }

  // If authenticated, show the children
  if (isAuthenticated) {
    return <>{children}</>
  }

  // This should not be visible as we redirect, but just in case
  return null
}
