import { Calendar, CreditCard, Clock, CheckCircle, ArrowRight, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface User {
  id: string
  name: string
  subscriptionTier: string
  subscriptionStatus: string
  subscriptionRenewalDate: string
  createdAt: string
}

interface SubscriptionDashboardProps {
  user: User
}

export function SubscriptionDashboard({ user }: SubscriptionDashboardProps) {
  // Format date to readable string
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  // Calculate days remaining in subscription
  const calculateDaysRemaining = () => {
    const nextBillingDate = new Date(user.subscriptionRenewalDate)
    const today = new Date()
    const diffTime = nextBillingDate.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays > 0 ? diffDays : 0
  }

  const daysRemaining = calculateDaysRemaining()
  const totalDays = 365 // Annual subscription
  const progressPercentage = 100 - (daysRemaining / totalDays) * 100

  // Recent invoices data
  const recentInvoices = [
    {
      id: "INV-2023-0012",
      date: new Date("2023-05-15"),
      amount: 499.99,
      description: "Annual Premium Subscription",
    },
    {
      id: "INV-2022-0011",
      date: new Date("2022-05-15"),
      amount: 499.99,
      description: "Annual Premium Subscription",
    },
  ]

  return (
    <div className="space-y-6">
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Subscription Overview</CardTitle>
          <CardDescription className="text-white/70">Current plan details and subscription status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <div className="text-white/70 text-sm">Current Plan</div>
                <div className="text-xl font-semibold mt-1 flex items-center">
                  {user.subscriptionTier.charAt(0).toUpperCase() + user.subscriptionTier.slice(1)} Annual
                  <Badge className="ml-2 bg-emerald-500 text-white">Active</Badge>
                </div>
                <div className="text-sm text-white/70 mt-1">Started on {formatDate(user.createdAt)}</div>
              </div>

              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <div className="text-white/70 text-sm">Next Billing Date</div>
                <div className="text-xl font-semibold mt-1">{formatDate(user.subscriptionRenewalDate)}</div>
                <div className="text-sm text-white/70 mt-1">Annual billing cycle</div>
              </div>

              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <div className="text-white/70 text-sm">Amount</div>
                <div className="text-xl font-semibold mt-1">$499.99/year</div>
                <div className="text-sm text-white/70 mt-1">Save $99.89 vs monthly</div>
              </div>
            </div>

            <div className="bg-white/5 rounded-lg p-4 border border-white/10">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="text-white/70 text-sm">Subscription Period</div>
                  <div className="text-lg font-medium mt-1">{daysRemaining} days remaining in your billing cycle</div>
                </div>
                <Button variant="outline" className="text-white border-white/20 hover:bg-white/10">
                  <Calendar className="mr-2 h-4 w-4" />
                  View Billing Schedule
                </Button>
              </div>
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{formatDate(user.createdAt)}</span>
                  <span>{formatDate(user.subscriptionRenewalDate)}</span>
                </div>
                <Progress value={progressPercentage} className="h-2 bg-white/10" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle>Recent Invoices</CardTitle>
            <CardDescription className="text-white/70">Your most recent billing statements</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentInvoices.map((invoice) => (
                <div key={invoice.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <div className="flex items-center gap-3">
                    <FileText className="h-5 w-5 text-white/70" />
                    <div>
                      <div className="font-medium">{invoice.description}</div>
                      <div className="text-sm text-white/70">
                        {formatDate(invoice.date)} • ${invoice.amount.toFixed(2)}
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="link" className="text-white w-full">
              View All Invoices
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription className="text-white/70">Manage your subscription and account</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start text-white border-white/20 hover:bg-white/10">
                <CreditCard className="mr-2 h-4 w-4" />
                Update Payment Method
              </Button>
              <Button variant="outline" className="w-full justify-start text-white border-white/20 hover:bg-white/10">
                <Clock className="mr-2 h-4 w-4" />
                Change Billing Cycle
              </Button>
              <Button variant="outline" className="w-full justify-start text-white border-white/20 hover:bg-white/10">
                <CheckCircle className="mr-2 h-4 w-4" />
                Manage Plan Features
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
