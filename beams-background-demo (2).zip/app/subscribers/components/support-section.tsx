"use client"

import type React from "react"

import { useState } from "react"
import {
  MessageSquare,
  Mail,
  Phone,
  FileQuestion,
  Search,
  ArrowRight,
  Clock,
  CheckCircle2,
  HelpCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export function SupportSection() {
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Mock support tickets
  const supportTickets = [
    {
      id: "TKT-2023-0012",
      subject: "Question about authentication certificates",
      status: "open",
      date: new Date("2023-12-10"),
      lastUpdate: new Date("2023-12-12"),
    },
    {
      id: "TKT-2023-0008",
      subject: "Billing issue with recent charge",
      status: "closed",
      date: new Date("2023-11-05"),
      lastUpdate: new Date("2023-11-07"),
    },
  ]

  // Mock FAQs
  const faqs = [
    {
      question: "How do I update my payment method?",
      answer:
        "You can update your payment method by navigating to the Payment tab in your subscriber dashboard. Click on 'Add Payment Method' to add a new card, then set it as your default payment method.",
    },
    {
      question: "Can I switch between monthly and annual billing?",
      answer:
        "Yes, you can switch between monthly and annual billing at any time. Go to the Plans tab, select your preferred billing cycle, and confirm the change. If you switch from monthly to annual, you'll be charged the annual rate immediately. If you switch from annual to monthly, the change will take effect at the end of your current billing period.",
    },
    {
      question: "How do I cancel my subscription?",
      answer:
        "To cancel your subscription, go to the Account tab and click on 'Manage' next to 'Cancel Subscription'. Follow the prompts to complete the cancellation process. Your subscription will remain active until the end of your current billing period.",
    },
    {
      question: "What happens to my data if I cancel my subscription?",
      answer:
        "Your account data will be retained for 30 days after cancellation. If you reactivate within this period, you'll regain access to your data. After 30 days, your data will be permanently deleted from our systems.",
    },
    {
      question: "How do I download my invoices?",
      answer:
        "You can download your invoices from the Billing tab. Each invoice has a download button that will generate a PDF receipt for your records.",
    },
  ]

  // Format date to readable string
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  const handleSubmitTicket = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call to submit ticket
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Support ticket submitted",
        description: "We'll get back to you as soon as possible.",
      })

      // Reset form
      const form = e.target as HTMLFormElement
      form.reset()
    }, 1500)
  }

  // Filter FAQs based on search query
  const filteredFaqs = faqs.filter(
    (faq) =>
      searchQuery === "" ||
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Help & Support</CardTitle>
          <CardDescription className="text-white/70">Get help with your subscription and account</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/50" />
              <Input
                placeholder="Search for help articles..."
                className="pl-9 bg-white/10 border-white/20 text-white"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                variant="outline"
                className="h-auto py-4 px-4 flex flex-col items-center justify-center gap-2 text-white border-white/20 hover:bg-white/10"
              >
                <FileQuestion className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">Knowledge Base</div>
                  <div className="text-xs text-white/70">Browse help articles</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="h-auto py-4 px-4 flex flex-col items-center justify-center gap-2 text-white border-white/20 hover:bg-white/10"
              >
                <MessageSquare className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">Live Chat</div>
                  <div className="text-xs text-white/70">Chat with support</div>
                </div>
              </Button>

              <Button
                variant="outline"
                className="h-auto py-4 px-4 flex flex-col items-center justify-center gap-2 text-white border-white/20 hover:bg-white/10"
              >
                <Mail className="h-6 w-6" />
                <div className="text-center">
                  <div className="font-medium">Email Support</div>
                  <div className="text-xs text-white/70">support@realtime.com</div>
                </div>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
            <CardDescription className="text-white/70">Quick answers to common questions</CardDescription>
          </CardHeader>
          <CardContent>
            <div>
              {filteredFaqs.length > 0 ? (
                <Accordion type="single" collapsible className="w-full">
                  {filteredFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="border-white/10">
                      <AccordionTrigger className="text-white hover:text-white/90 hover:no-underline">
                        <div className="flex items-center gap-2 text-left">
                          <HelpCircle className="h-4 w-4 text-white/70 flex-shrink-0" />
                          <span>{faq.question}</span>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="text-white/70">{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              ) : (
                <div className="text-center py-8 text-white/70">
                  <FileQuestion className="h-12 w-12 mx-auto mb-2 text-white/50" />
                  <p className="mb-2">No FAQs found matching your search.</p>
                  <p className="text-sm">Try a different search term or browse all FAQs by clearing your search.</p>
                </div>
              )}

              <div className="mt-4 text-center">
                <Button variant="link" className="text-white">
                  View all FAQs
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle>Contact Support</CardTitle>
            <CardDescription className="text-white/70">Submit a support ticket for personalized help</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmitTicket} className="space-y-4">
              <div className="space-y-1">
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  placeholder="Brief description of your issue"
                  required
                  className="bg-white/10 border-white/20 text-white"
                />
              </div>

              <div className="space-y-1">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Please provide details about your issue or question"
                  required
                  className="min-h-[120px] bg-white/10 border-white/20 text-white"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <Button type="submit" disabled={isSubmitting} className="bg-white text-black hover:bg-white/90">
                  {isSubmitting ? (
                    <>
                      <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                      Submitting...
                    </>
                  ) : (
                    "Submit Ticket"
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Your Support Tickets</CardTitle>
          <CardDescription className="text-white/70">Track the status of your support requests</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {supportTickets.length > 0 ? (
              supportTickets.map((ticket) => (
                <div
                  key={ticket.id}
                  className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex items-start md:items-center gap-4">
                    <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-white/70" />
                    </div>
                    <div>
                      <div className="font-medium">{ticket.subject}</div>
                      <div className="text-sm text-white/70 flex flex-wrap gap-2 mt-1">
                        <span>Ticket ID: {ticket.id}</span>
                        <span className="hidden md:inline">•</span>
                        <span>Opened: {formatDate(ticket.date)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mt-4 md:mt-0">
                    <div className="flex items-center gap-2">
                      {ticket.status === "open" ? (
                        <Badge className="bg-amber-500 text-white">
                          <Clock className="h-3 w-3 mr-1" />
                          Open
                        </Badge>
                      ) : (
                        <Badge className="bg-emerald-500 text-white">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          Resolved
                        </Badge>
                      )}
                      <span className="text-sm text-white/70 hidden md:inline">
                        Last updated: {formatDate(ticket.lastUpdate)}
                      </span>
                    </div>
                    <Button variant="ghost" size="sm" className="text-white/70 hover:text-white">
                      View
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-white/70">
                <MessageSquare className="h-12 w-12 mx-auto mb-2 text-white/50" />
                <p className="mb-2">You don't have any support tickets yet.</p>
                <p className="text-sm">If you need help, submit a new ticket using the form above.</p>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <div className="w-full flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-white/70">
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4" />
              <span>Need immediate assistance? Call us at +1 (800) 555-1234</span>
            </div>
            <div>Support hours: Monday-Friday, 9am-6pm EST</div>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
