import type React from "react"
import { AuthProvider } from "@/lib/auth-context"
import { GlassNavbar } from "@/components/glass-navbar"
import { IOSPerformanceOptimizations } from "@/components/ios-performance-optimizations"
import { IOSScrollFix } from "@/components/ios-scroll-fix"

export default function SubscribersLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <AuthProvider>
      <GlassNavbar />
      <IOSPerformanceOptimizations />
      <IOSScrollFix />
      <main className="min-h-screen pt-16 ios-momentum-scrolling overscroll-none pb-safe">{children}</main>
    </AuthProvider>
  )
}
