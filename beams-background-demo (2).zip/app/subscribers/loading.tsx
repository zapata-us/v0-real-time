import { Skeleton } from "@/components/ui/skeleton"

export default function SubscribersLoading() {
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center justify-between mb-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-10 w-32" />
      </div>

      <div className="bg-white/5 backdrop-blur-sm rounded-lg border border-white/10 p-6 mb-6">
        <div className="flex flex-wrap gap-4 mb-4">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-64" />
        </div>
      </div>

      <div className="bg-white/5 backdrop-blur-sm rounded-lg border border-white/10 overflow-hidden">
        <div className="p-4 border-b border-white/10 flex items-center">
          <Skeleton className="h-6 w-60" />
        </div>

        {[...Array(5)].map((_, i) => (
          <div key={i} className="p-4 border-b border-white/10 flex flex-col md:flex-row gap-4">
            <Skeleton className="h-6 w-full md:w-1/4" />
            <Skeleton className="h-6 w-full md:w-1/5" />
            <Skeleton className="h-6 w-full md:w-1/5" />
            <Skeleton className="h-6 w-full md:w-1/5" />
            <Skeleton className="h-6 w-full md:w-1/6" />
          </div>
        ))}

        <div className="p-4 flex items-center justify-between">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-8 w-48" />
        </div>
      </div>
    </div>
  )
}
