import type { Metadata } from "next"
import { SubscriptionAuthWrapper } from "./components/subscription-auth-wrapper"
import { SubscriberPortal } from "./components/subscriber-portal"

export const metadata: Metadata = {
  title: "My Subscription | REAL TIME",
  description: "Manage your subscription, billing information, and account settings",
}

export default function SubscribersPage() {
  return (
    <SubscriptionAuthWrapper>
      <SubscriberPortal />
    </SubscriptionAuthWrapper>
  )
}
