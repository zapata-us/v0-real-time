"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { SiteLayout } from "@/components/site-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useIOSDetection } from "@/lib/use-ios-detection"
import {
  Search,
  ArrowLeft,
  MessageCircle,
  Mail,
  Phone,
  MapPin,
  ChevronDown,
  ChevronRight,
  X,
  Send,
  Package,
  RefreshCw,
  Info,
  Wrench,
} from "lucide-react"

// FAQ data structure
const faqData = [
  {
    category: "Orders & Shipping",
    icon: <Package className="h-5 w-5 text-white/70" />,
    items: [
      {
        question: "How do I track my order?",
        answer:
          "You can track your order by logging into your account and visiting the 'Order History' section. Alternatively, use the tracking number provided in your shipping confirmation email.",
      },
      {
        question: "What shipping methods do you offer?",
        answer:
          "We offer standard shipping (3-5 business days), expedited shipping (2-3 business days), and overnight shipping. All luxury timepieces are shipped fully insured with signature confirmation.",
      },
      {
        question: "Do you ship internationally?",
        answer:
          "Yes, we ship to most countries worldwide. International shipping times vary depending on the destination and customs processing.",
      },
    ],
  },
  {
    category: "Returns & Exchanges",
    icon: <RefreshCw className="h-5 w-5 text-white/70" />,
    items: [
      {
        question: "What is your return policy?",
        answer:
          "We offer a 14-day return policy for unworn watches in their original condition with all tags and protective coverings intact.",
      },
      {
        question: "How do I initiate a return?",
        answer:
          "Contact our customer service team at returns@realtimejewelry.com or call (305) 766-3058 for a return authorization number and instructions.",
      },
      {
        question: "Do you offer exchanges?",
        answer:
          "Yes, we offer exchanges within 14 days of purchase. The watch must be in unworn condition with all original packaging and documentation.",
      },
    ],
  },
  {
    category: "Product Information",
    icon: <Info className="h-5 w-5 text-white/70" />,
    items: [
      {
        question: "Are your watches authentic?",
        answer:
          "Yes, we guarantee 100% authenticity for all our timepieces. Each watch comes with its original box, papers, and manufacturer's warranty where applicable.",
      },
      {
        question: "What is the difference between new and pre-owned watches?",
        answer:
          "New watches have never been worn and come with the full manufacturer's warranty. Pre-owned watches have been previously owned but thoroughly inspected and authenticated.",
      },
      {
        question: "Do you offer watch customization?",
        answer:
          "Yes, we offer various customization options including custom dials, bezels, and straps for select models.",
      },
    ],
  },
  {
    category: "Services & Repairs",
    icon: <Wrench className="h-5 w-5 text-white/70" />,
    items: [
      {
        question: "Do you offer watch servicing?",
        answer:
          "Yes, our certified watchmakers provide comprehensive servicing for luxury timepieces including movement overhauls, water resistance testing, and polishing.",
      },
      {
        question: "How often should I service my watch?",
        answer: "Most luxury watches should be serviced every 3-5 years to maintain optimal performance.",
      },
      {
        question: "What does a complete service include?",
        answer:
          "A complete service includes disassembly of the movement, cleaning, replacement of worn parts, lubrication, reassembly, timing adjustment, and case refinishing if requested.",
      },
    ],
  },
]

export default function SupportPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null)
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<"faq" | "contact">("faq")
  const [showChat, setShowChat] = useState(false)
  const searchInputRef = useRef<HTMLInputElement>(null)
  const isIOS = useIOSDetection()
  const contentRef = useRef<HTMLDivElement>(null)

  // Scroll to top function
  const scrollToTop = () => {
    if (contentRef.current) {
      contentRef.current.scrollIntoView({ behavior: "smooth", block: "start" })
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  // Handle search
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setSearchResults([])
      return
    }

    const results: any[] = []
    faqData.forEach((category) => {
      category.items.forEach((item) => {
        if (
          item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.answer.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          results.push({
            category: category.category,
            icon: category.icon,
            ...item,
          })
        }
      })
    })
    setSearchResults(results)

    // Scroll to top when search results change
    scrollToTop()
  }, [searchQuery])

  // iOS-specific optimizations
  useEffect(() => {
    if (!isIOS) return

    // Fix for iOS input zoom
    const inputs = document.querySelectorAll("input, textarea")
    inputs.forEach((input) => {
      input.setAttribute("autocomplete", "off")
      input.setAttribute("autocorrect", "off")
      input.setAttribute("autocapitalize", "off")
      input.setAttribute("spellcheck", "false")
    })

    // Improve scrolling performance
    document.addEventListener("touchmove", () => {}, { passive: true })

    return () => {
      document.removeEventListener("touchmove", () => {})
    }
  }, [isIOS])

  // Toggle category expansion
  const toggleCategory = (category: string) => {
    setExpandedCategory(expandedCategory === category ? null : category)
    setExpandedFaq(null) // Close any open FAQ when changing category
    scrollToTop() // Scroll to top when toggling categories
  }

  // Toggle FAQ expansion
  const toggleFaq = (id: string) => {
    setExpandedFaq(expandedFaq === id ? null : id)
  }

  // Clear search
  const clearSearch = () => {
    setSearchQuery("")
    if (searchInputRef.current) {
      searchInputRef.current.focus()
    }
    scrollToTop() // Scroll to top when clearing search
  }

  // Handle tab change
  const handleTabChange = (tab: "faq" | "contact") => {
    setActiveTab(tab)
    scrollToTop() // Scroll to top when changing tabs
  }

  return (
    <SiteLayout>
      <div className="min-h-screen pb-safe">
        {/* Header */}
        <div className="bg-gradient-to-b from-black/50 to-transparent pt-safe" ref={contentRef}>
          <div className="container px-4 pt-6 pb-4">
            <Link
              href="/"
              className="inline-flex items-center text-sm text-white/80 hover:text-white mb-6 touch-callout-none"
              style={{ WebkitTapHighlightColor: "transparent" }}
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Back
            </Link>

            <h1 className="text-3xl font-bold text-white mb-2">Support Center</h1>
            <p className="text-white/70 text-sm mb-6">Find answers or contact our team for assistance</p>

            {/* Search bar */}
            <div className="relative w-full mb-6">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-white/50" />
              </div>
              <Input
                ref={searchInputRef}
                type="text"
                placeholder="Search for answers..."
                className="pl-10 py-5 bg-white/10 border-0 text-white placeholder:text-white/50 rounded-xl focus:ring-2 focus:ring-white/30 focus:border-transparent w-full shadow-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{ fontSize: "16px" }}
              />
              {searchQuery && (
                <button
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={clearSearch}
                  style={{ WebkitTapHighlightColor: "transparent" }}
                >
                  <X className="h-5 w-5 text-white/50" />
                </button>
              )}
            </div>

            {/* Tab navigation */}
            {!searchQuery && (
              <div className="flex border-b border-white/10 mb-6">
                <button
                  className={`flex-1 py-3 text-center text-sm font-medium ${
                    activeTab === "faq" ? "text-white border-b-2 border-white" : "text-white/60"
                  }`}
                  onClick={() => handleTabChange("faq")}
                  style={{ WebkitTapHighlightColor: "transparent" }}
                >
                  FAQs
                </button>
                <button
                  className={`flex-1 py-3 text-center text-sm font-medium ${
                    activeTab === "contact" ? "text-white border-b-2 border-white" : "text-white/60"
                  }`}
                  onClick={() => handleTabChange("contact")}
                  style={{ WebkitTapHighlightColor: "transparent" }}
                >
                  Contact Us
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Main content */}
        <div className="container px-4 pb-24">
          {/* Search results */}
          {searchQuery && (
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-white mb-4">
                {searchResults.length > 0
                  ? `Results for "${searchQuery}" (${searchResults.length})`
                  : `No results for "${searchQuery}"`}
              </h2>

              {searchResults.length > 0 ? (
                <div className="space-y-3">
                  {searchResults.map((result, index) => (
                    <div key={index} className="bg-white/5 backdrop-blur-md rounded-lg p-4">
                      <div className="flex items-start">
                        <div className="h-8 w-8 rounded-full bg-white/10 flex items-center justify-center mr-3 flex-shrink-0">
                          {result.icon}
                        </div>
                        <div>
                          <span className="text-white/50 text-xs">{result.category}</span>
                          <h3 className="text-white font-medium text-base">{result.question}</h3>
                          <p className="text-white/70 mt-2 text-sm">{result.answer}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-white/5 backdrop-blur-md rounded-lg p-6 text-center">
                  <p className="text-white/70 mb-2">We couldn't find any matches for your search.</p>
                  <button className="text-white underline text-sm" onClick={clearSearch}>
                    Clear search
                  </button>
                </div>
              )}
            </div>
          )}

          {/* FAQ Tab Content */}
          {!searchQuery && activeTab === "faq" && (
            <div className="space-y-4">
              {faqData.map((category) => (
                <div key={category.category} className="bg-white/5 backdrop-blur-md rounded-lg overflow-hidden">
                  <button
                    className="w-full p-4 flex justify-between items-center"
                    onClick={() => toggleCategory(category.category)}
                    style={{ WebkitTapHighlightColor: "transparent" }}
                  >
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-3">
                        {category.icon}
                      </div>
                      <h3 className="text-white font-medium">{category.category}</h3>
                    </div>
                    <ChevronDown
                      className={`h-5 w-5 text-white/70 transition-transform ${
                        expandedCategory === category.category ? "transform rotate-180" : ""
                      }`}
                    />
                  </button>

                  <AnimatePresence>
                    {expandedCategory === category.category && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <div className="p-4 pt-0 space-y-3">
                          {category.items.map((item, itemIndex) => {
                            const faqId = `${category.category}-${itemIndex}`
                            return (
                              <div key={faqId} className="border-t border-white/5 pt-3">
                                <button
                                  className="w-full flex justify-between items-start text-left"
                                  onClick={() => toggleFaq(faqId)}
                                  style={{ WebkitTapHighlightColor: "transparent" }}
                                >
                                  <h4 className="text-white text-sm font-medium pr-6">{item.question}</h4>
                                  <ChevronDown
                                    className={`h-4 w-4 flex-shrink-0 text-white/70 transition-transform mt-0.5 ${
                                      expandedFaq === faqId ? "transform rotate-180" : ""
                                    }`}
                                  />
                                </button>

                                <AnimatePresence>
                                  {expandedFaq === faqId && (
                                    <motion.div
                                      initial={{ height: 0, opacity: 0 }}
                                      animate={{ height: "auto", opacity: 1 }}
                                      exit={{ height: 0, opacity: 0 }}
                                      transition={{ duration: 0.2 }}
                                      className="overflow-hidden"
                                    >
                                      <p className="text-white/70 mt-2 text-sm">{item.answer}</p>
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            )
                          })}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          )}

          {/* Contact Tab Content */}
          {!searchQuery && activeTab === "contact" && (
            <div className="space-y-6">
              {/* Contact Methods */}
              <div className="bg-white/5 backdrop-blur-md rounded-lg p-4">
                <h3 className="text-white font-medium mb-4">Contact Methods</h3>

                <div className="space-y-4">
                  <a
                    href="tel:+13057663058"
                    className="flex items-center p-3 bg-white/5 rounded-lg"
                    style={{ WebkitTapHighlightColor: "transparent" }}
                    rel="noopener"
                  >
                    <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-3">
                      <Phone className="h-5 w-5 text-white/70" />
                    </div>
                    <div>
                      <div className="text-white font-medium">Call Us</div>
                      <div className="text-white/70 text-sm">+1 (305) 766-3058</div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-white/50 ml-auto" />
                  </a>
                  <a
                    href="tel:+17862382082"
                    className="flex items-center p-3 bg-white/5 rounded-lg"
                    style={{ WebkitTapHighlightColor: "transparent" }}
                    rel="noopener"
                  >
                    <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-3">
                      <Phone className="h-5 w-5 text-white/70" />
                    </div>
                    <div>
                      <div className="text-white font-medium">Call Us</div>
                      <div className="text-white/70 text-sm">+1 (786) 238-2082</div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-white/50 ml-auto" />
                  </a>

                  <a
                    href="mailto:info@realtimejewelry.com"
                    className="flex items-center p-3 bg-white/5 rounded-lg"
                    style={{ WebkitTapHighlightColor: "transparent" }}
                    rel="noopener"
                  >
                    <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-3">
                      <Mail className="h-5 w-5 text-white/70" />
                    </div>
                    <div>
                      <div className="text-white font-medium">Email Us</div>
                      <div className="text-white/70 text-sm">info@realtimejewelry.com</div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-white/50 ml-auto" />
                  </a>

                  <a
                    href="https://maps.google.com/maps?q=36+NE+1st+St,+Miami,+FL+33132"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-3 bg-white/5 rounded-lg"
                    style={{ WebkitTapHighlightColor: "transparent" }}
                  >
                    <div className="h-10 w-10 rounded-full bg-white/10 flex items-center justify-center mr-3">
                      <MapPin className="h-5 w-5 text-white/70" />
                    </div>
                    <div>
                      <div className="text-white font-medium">Visit Us</div>
                      <div className="text-white/70 text-sm">36 NE 1st St, Miami, FL 33132</div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-white/50 ml-auto" />
                  </a>
                </div>
              </div>

              {/* Contact Form */}
              <div className="bg-white/5 backdrop-blur-md rounded-lg p-4">
                <h3 className="text-white font-medium mb-4">Send a Message</h3>

                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-white/70 text-sm mb-1">
                      Name
                    </label>
                    <Input
                      id="name"
                      type="text"
                      className="bg-white/10 border-0 text-white placeholder:text-white/50"
                      placeholder="Your name"
                      style={{ fontSize: "16px" }}
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-white/70 text-sm mb-1">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      className="bg-white/10 border-0 text-white placeholder:text-white/50"
                      placeholder="Your email"
                      style={{ fontSize: "16px" }}
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-white/70 text-sm mb-1">
                      Message
                    </label>
                    <textarea
                      id="message"
                      rows={4}
                      className="w-full rounded-md bg-white/10 border-0 text-white placeholder:text-white/50 p-2"
                      placeholder="How can we help you?"
                      style={{ fontSize: "16px" }}
                    ></textarea>
                  </div>

                  <Button className="w-full py-5 bg-[#c0c0c0]/70 hover:bg-[#a8a8a8]/80 text-white rounded-xl">
                    Send Message
                  </Button>
                </form>
              </div>
            </div>
          )}
        </div>

        {/* Live Chat Button */}
        <div className="fixed bottom-6 right-6 z-50 mb-safe">
          <button
            onClick={() => setShowChat(!showChat)}
            className="h-14 w-14 rounded-full bg-[#c0c0c0]/70 hover:bg-[#a8a8a8]/80 flex items-center justify-center shadow-lg"
            aria-label="Live Chat"
            style={{ WebkitTapHighlightColor: "transparent" }}
          >
            {showChat ? <X className="h-6 w-6 text-white" /> : <MessageCircle className="h-6 w-6 text-white" />}
          </button>

          {/* Chat Window */}
          <AnimatePresence>
            {showChat && (
              <motion.div
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.9 }}
                transition={{ duration: 0.2 }}
                className="absolute bottom-16 right-0 w-full max-w-[320px] bg-black/80 backdrop-blur-lg rounded-lg shadow-xl overflow-hidden"
                style={{
                  WebkitOverflowScrolling: "touch",
                  maxHeight: "calc(100vh - 180px)",
                }}
              >
                <div className="p-3 border-b border-white/10 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
                    <h3 className="text-white text-sm font-medium">Live Support</h3>
                  </div>
                </div>

                <div className="h-[300px] overflow-y-auto p-3 space-y-3 ios-scroll">
                  <div className="flex items-start">
                    <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center mr-2 flex-shrink-0">
                      <span className="text-white text-sm">RT</span>
                    </div>
                    <div className="bg-white/10 rounded-lg p-3 max-w-[80%]">
                      <p className="text-white text-sm">Hello! How can I help you today?</p>
                      <span className="text-white/50 text-xs mt-1 block">
                        {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-3 border-t border-white/10">
                  <div className="flex items-center">
                    <Input
                      type="text"
                      placeholder="Type your message..."
                      className="bg-white/10 border-0 text-white placeholder:text-white/50"
                      style={{ fontSize: "16px" }}
                    />
                    <button className="ml-2 h-8 w-8 rounded-full bg-white/10 flex items-center justify-center text-white">
                      <Send className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </SiteLayout>
  )
}
