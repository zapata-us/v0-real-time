"use client"

import type React from "react"

import { useRef, useEffect, useState } from "react"
import { cn } from "@/lib/utils"

interface BeamsBackgroundProps {
  children: React.ReactNode
  className?: string
  density?: number
  speed?: number
  animateOnLoad?: boolean
  disableAnimation?: boolean
}

export function BeamsBackground({
  children,
  className,
  density = 40,
  speed = 1,
  animateOnLoad = true,
  disableAnimation = false,
}: BeamsBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 })

  // Optimization for iOS
  const isIOS = typeof navigator !== "undefined" && /iPad|iPhone|iPod/.test(navigator.userAgent)

  useEffect(() => {
    // Set loaded after initial render
    setIsLoaded(true)

    const container = containerRef.current
    if (!container) return

    const updateCanvasSize = () => {
      setCanvasSize({
        width: container.clientWidth,
        height: container.clientHeight,
      })
    }

    // Initial size
    updateCanvasSize()

    // Update canvas size on resize
    const resizeObserver = new ResizeObserver(updateCanvasSize)
    resizeObserver.observe(container)

    return () => {
      resizeObserver.disconnect()
    }
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || canvasSize.width === 0 || canvasSize.height === 0 || disableAnimation) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set actual canvas dimensions
    canvas.width = canvasSize.width
    canvas.height = canvasSize.height

    // Calculate how many beams to create
    const beamCount = Math.max(5, Math.floor(density * (canvasSize.width / 1000)))

    // Create beams
    const beams = Array.from({ length: beamCount }, () => {
      return {
        x: Math.random() * canvasSize.width,
        y: Math.random() * canvasSize.height,
        length: Math.random() * 200 + 100,
        width: Math.random() * 1.5 + 0.5,
        opacity: Math.random() * 0.2 + 0.05,
        color: Math.random() > 0.5 ? "#FFFFFF" : "#CCCCFF",
        speed: (Math.random() * 0.2 + 0.1) * speed,
        angle: Math.random() * Math.PI * 2,
      }
    })

    // Animation function
    let animationId: number

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Reduce animation complexity on iOS
      const simpleMode = isIOS && beamCount > 15

      beams.forEach((beam) => {
        ctx.save()

        // Move and rotate the beam
        beam.angle += beam.speed / 100

        const centerX = beam.x
        const centerY = beam.y

        ctx.translate(centerX, centerY)
        ctx.rotate(beam.angle)
        ctx.translate(-centerX, -centerY)

        // Create gradient
        if (!simpleMode) {
          const gradient = ctx.createLinearGradient(beam.x - beam.length / 2, beam.y, beam.x + beam.length / 2, beam.y)
          gradient.addColorStop(0, `rgba(255, 255, 255, 0)`)
          gradient.addColorStop(0.5, `rgba(255, 255, 255, ${beam.opacity})`)
          gradient.addColorStop(1, `rgba(255, 255, 255, 0)`)

          ctx.fillStyle = gradient
        } else {
          // Simpler rendering for iOS
          ctx.fillStyle = `rgba(255, 255, 255, ${beam.opacity})`
        }

        // Draw beam
        ctx.beginPath()
        ctx.roundRect(beam.x - beam.length / 2, beam.y - beam.width / 2, beam.length, beam.width, beam.width / 2)
        ctx.fill()

        ctx.restore()
      })

      animationId = requestAnimationFrame(animate)
    }

    if (animateOnLoad) {
      animate()
    }

    return () => {
      cancelAnimationFrame(animationId)
    }
  }, [canvasSize, density, speed, animateOnLoad, disableAnimation, isIOS])

  return (
    <div
      ref={containerRef}
      className={cn("relative min-h-screen w-full bg-gradient-to-br from-black to-gray-900", className)}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full opacity-80"
        style={{
          opacity: isLoaded ? 0.8 : 0,
          transition: "opacity 0.5s ease-in-out",
        }}
      />

      <div className="relative z-10">{children}</div>
    </div>
  )
}

export default BeamsBackground
