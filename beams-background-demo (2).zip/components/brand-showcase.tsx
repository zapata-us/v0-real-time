"use client"

import type React from "react"

import { useState, useMemo } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowUpRight, Search, Info } from "lucide-react"
import { getAllBrands } from "@/lib/brand-service"

// Rolex serial number database
const SERIAL_YEAR_DATABASE = [
  { serial_number: "Random", year: 2018 },
  { serial_number: "Random", year: 2017 },
  { serial_number: "Random", year: 2016 },
  { serial_number: "Random", year: 2015 },
  { serial_number: "Random", year: 2014 },
  { serial_number: "Random", year: 2013 },
  { serial_number: "Random", year: 2012 },
  { serial_number: "Random", year: 2011 },
  { serial_number: "G", year: 2010 },
  { serial_number: "V", year: 2009 },
  { serial_number: "M OR V", year: 2008 },
  { serial_number: "M OR Z", year: 2007 },
  { serial_number: "D OR Z", year: 2006 },
  { serial_number: "D", year: 2005 },
  { serial_number: "F", year: 2005 },
  { serial_number: "F", year: 2004 },
  { serial_number: "F", year: 2003 },
  { serial_number: "Y", year: 2002 },
  { serial_number: "K OR Y", year: 2001 },
  { serial_number: "K,000,001", year: 2000 },
  { serial_number: "P,000,001", year: 2000 },
  { serial_number: "A,000,001", year: 1999 },
  { serial_number: "U,932,144", year: 1998 },
  { serial_number: "U,000,001", year: 1997 },
  { serial_number: "T,000,001", year: 1996 },
  { serial_number: "W,000,001", year: 1995 },
  { serial_number: "S,860,880", year: 1994 },
  { serial_number: "S,000,001", year: 1993 },
  { serial_number: "C,000,001", year: 1992 },
  { serial_number: "N,000,001", year: 1991 },
  { serial_number: "X,000,001", year: 1991 },
  { serial_number: "E,000,001", year: 1990 },
  { serial_number: "L,980,000", year: 1989 },
  { serial_number: "R,598,200", year: 1988 },
  { serial_number: "R,000,001", year: 1987 },
  { serial_number: "9,400,000", year: 1987 },
  { serial_number: "8,900,000", year: 1986 },
  { serial_number: "8,614,000", year: 1985 },
  { serial_number: "8,070,022", year: 1984 },
  { serial_number: "7,400,000", year: 1983 },
  { serial_number: "7,100,000", year: 1982 },
  { serial_number: "6,520,870", year: 1981 },
  { serial_number: "6,434,000", year: 1980 },
  { serial_number: "5,737,030", year: 1979 },
  { serial_number: "5,000,000", year: 1978 },
  { serial_number: "5,008,000", year: 1977 },
  { serial_number: "4,115,299", year: 1976 },
  { serial_number: "3,862,196", year: 1975 },
  { serial_number: "3,567,927", year: 1974 },
  { serial_number: "3,200,268", year: 1973 },
  { serial_number: "2,890,459", year: 1972 },
  { serial_number: "2,589,295", year: 1971 },
  { serial_number: "2,241,882", year: 1970 },
  { serial_number: "1,900,000", year: 1969 },
  { serial_number: "1,752,000", year: 1968 },
  { serial_number: "1,538,435", year: 1967 },
  { serial_number: "1,200,000", year: 1966 },
  { serial_number: "1,100,000", year: 1965 },
  { serial_number: "1,008,889", year: 1964 },
  { serial_number: "824,000", year: 1963 },
  { serial_number: "744,000", year: 1962 },
  { serial_number: "643,153", year: 1961 },
  { serial_number: "516,000", year: 1960 },
  { serial_number: "399,453", year: 1959 },
  { serial_number: "328,000", year: 1958 },
  { serial_number: "224,000", year: 1957 },
  { serial_number: "133,061", year: 1956 },
  { serial_number: "97,000", year: 1955 },
  { serial_number: "23,000", year: 1954 },
  { serial_number: "855,726", year: 1953 },
  { serial_number: "726,639", year: 1952 },
  { serial_number: "709,249", year: 1951 },
  { serial_number: "", year: 1950 },
  { serial_number: "", year: 1949 },
  { serial_number: "628,840", year: 1948 },
  { serial_number: "529,163", year: 1947 },
  { serial_number: "367,946", year: 1946 },
  { serial_number: "302,459", year: 1945 },
  { serial_number: "269,561", year: 1944 },
  { serial_number: "230,878", year: 1943 },
  { serial_number: "143,509", year: 1942 },
  { serial_number: "106,047", year: 1941 },
  { serial_number: "99,775", year: 1940 },
  { serial_number: "71,224", year: 1939 },
  { serial_number: "43,739", year: 1938 },
  { serial_number: "40,920", year: 1937 },
  { serial_number: "36,856", year: 1936 },
  { serial_number: "34,336", year: 1935 },
  { serial_number: "30,823", year: 1934 },
  { serial_number: "29,562", year: 1933 },
  { serial_number: "29,132", year: 1932 },
  { serial_number: "", year: 1931 },
  { serial_number: "23,186", year: 1930 },
  { serial_number: "", year: 1929 },
  { serial_number: "23,969", year: 1928 },
  { serial_number: "20,190", year: 1927 },
  { serial_number: "00,001", year: 1926 },
]

export function BrandShowcase() {
  const [isImageLoading, setIsImageLoading] = useState<Record<string, boolean>>({})
  const [serialNumber, setSerialNumber] = useState("")
  const [searchResult, setSearchResult] = useState<{ year: number; match: string; exact: boolean } | null>(null)
  const [isSearching, setIsSearching] = useState(false)
  const [showFullTable, setShowFullTable] = useState(false)
  const brands = getAllBrands()

  // Collaborator data with actual logos
  const collaborators = [
    {
      name: "IWJG",
      logo: "/images/IWJG-REAL-TIME.png",
      width: 200,
      height: 70,
    },
    {
      name: "JIS",
      logo: "/images/JIS-01.png",
      width: 120,
      height: 50,
    },
    {
      name: "Original Vintage",
      logo: "/images/ORIGINALVINTAGE-REAL-TIME.png",
      width: 200,
      height: 70,
    },
    {
      name: "JCK",
      logo: "/images/jck-logo-white.png",
      width: 150,
      height: 50,
    },
    {
      name: "NYC JAWS",
      logo: "/images/nycjaws-logo-white.svg",
      width: 180,
      height: 50,
    },
  ]

  // Handle image load state
  const handleImageLoad = (brandId: string) => {
    setIsImageLoading((prev) => ({
      ...prev,
      [brandId]: false,
    }))
  }

  // Handle image load error
  const handleImageError = (brandId: string) => {
    setIsImageLoading((prev) => ({
      ...prev,
      [brandId]: false,
    }))
    // Error is handled by the onError attribute on the Image component
  }

  // Function to normalize serial number for comparison
  const normalizeSerial = (serial: string): string => {
    return serial.replace(/[^a-zA-Z0-9]/g, "").toUpperCase()
  }

  // Function to check if a serial number matches a pattern
  const matchesPattern = (input: string, pattern: string): boolean => {
    // Handle empty patterns
    if (!pattern) return false

    // Handle "Random" pattern (2011-2018)
    if (pattern.toLowerCase() === "random") {
      // Check if input is 8 digits (typical for random serials)
      return /^\d{8}$/.test(normalizeSerial(input))
    }

    // Handle patterns with "OR" (e.g., "M OR V")
    if (pattern.includes("OR")) {
      const options = pattern.split("OR").map((opt) => normalizeSerial(opt.trim()))
      const normalizedInput = normalizeSerial(input)

      // Check if input starts with any of the options
      return options.some((opt) => normalizedInput.startsWith(opt))
    }

    // Handle numeric ranges (e.g., "9,400,000")
    if (/[\d,]+/.test(pattern)) {
      const patternNum = Number.parseInt(pattern.replace(/,/g, ""))
      const inputNum = Number.parseInt(normalizeSerial(input))

      // If both can be parsed as numbers, compare them
      if (!isNaN(patternNum) && !isNaN(inputNum)) {
        return inputNum >= patternNum
      }
    }

    // Default: check if input starts with the pattern
    return normalizeSerial(input).startsWith(normalizeSerial(pattern))
  }

  // Function to find the best match for a serial number
  const findBestMatch = (input: string) => {
    const normalizedInput = normalizeSerial(input)

    // First try to find an exact match
    for (let i = 0; i < SERIAL_YEAR_DATABASE.length; i++) {
      const entry = SERIAL_YEAR_DATABASE[i]
      if (matchesPattern(normalizedInput, entry.serial_number)) {
        return {
          year: entry.year,
          match: entry.serial_number,
          exact: true,
        }
      }
    }

    // If no exact match, try to find the closest match based on first character
    if (normalizedInput.length > 0) {
      const firstChar = normalizedInput[0]

      // Check for letter matches (for modern Rolex serials)
      for (const entry of SERIAL_YEAR_DATABASE) {
        if (entry.serial_number && entry.serial_number.toUpperCase().startsWith(firstChar)) {
          return {
            year: entry.year,
            match: entry.serial_number,
            exact: false,
          }
        }
      }

      // Check for numeric ranges
      if (/^\d+$/.test(normalizedInput)) {
        const inputNum = Number.parseInt(normalizedInput)

        // Find the closest numeric range
        let closestEntry = null
        let smallestDiff = Number.MAX_SAFE_INTEGER

        for (const entry of SERIAL_YEAR_DATABASE) {
          if (/[\d,]+/.test(entry.serial_number)) {
            const entryNum = Number.parseInt(entry.serial_number.replace(/,/g, ""))
            if (!isNaN(entryNum)) {
              const diff = Math.abs(inputNum - entryNum)
              if (diff < smallestDiff) {
                smallestDiff = diff
                closestEntry = entry
              }
            }
          }
        }

        if (closestEntry) {
          return {
            year: closestEntry.year,
            match: closestEntry.serial_number,
            exact: false,
          }
        }
      }

      // If still no match, return the most recent year for modern watches
      if (/^\d{8}$/.test(normalizedInput)) {
        return {
          year: 2018,
          match: "Random",
          exact: false,
        }
      }
    }

    // If all else fails, return null
    return null
  }

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!serialNumber.trim()) return

    setIsSearching(true)

    // Simulate API delay
    setTimeout(() => {
      const result = findBestMatch(serialNumber)
      setSearchResult(result)
      setIsSearching(false)
    }, 300)
  }

  // Group years by decade for the reference table
  const decadeGroups = useMemo(() => {
    const groups: Record<string, typeof SERIAL_YEAR_DATABASE> = {}

    SERIAL_YEAR_DATABASE.forEach((entry) => {
      const decade = `${Math.floor(entry.year / 10) * 10}s`
      if (!groups[decade]) {
        groups[decade] = []
      }
      groups[decade].push(entry)
    })

    return Object.entries(groups).sort((a, b) => {
      // Sort decades in descending order (newest first)
      return Number.parseInt(b[0]) - Number.parseInt(a[0])
    })
  }, [])

  return (
    <section className="w-full py-[7%] overflow-hidden">
      {/* Collaborator Logos */}
      <div className="container mx-auto px-2 overflow-hidden">
        <div className="flex whitespace-nowrap animate-marquee gap-[2.3rem] md:gap-[3rem] mb-4 py-1">
          {/* First set of logos for continuous loop */}
          {collaborators.map((collab, index) => {
            const scaleFactor = collab.name === "JIS" ? 1.275 : 0.981
            return (
              <div
                key={`first-${collab.name}`}
                className="relative flex-shrink-0 flex items-center justify-center h-[5.1rem] md:h-[6.4rem] -mt-[0.5rem] md:-mt-[0.65rem]"
                style={{ width: collab.width * scaleFactor }}
              >
                <Image
                  src={collab.logo || "/placeholder.svg"}
                  alt={`${collab.name} logo`}
                  width={collab.width * scaleFactor}
                  height={collab.height * scaleFactor}
                  className="object-contain brightness-0 invert"
                  priority={index < 2}
                />
              </div>
            )
          })}

          {/* Duplicate set of logos for seamless loop */}
          {collaborators.map((collab, index) => {
            const scaleFactor = collab.name === "JIS" ? 1.275 : 0.981
            return (
              <div
                key={`second-${collab.name}`}
                className="relative flex-shrink-0 flex items-center justify-center h-[5.1rem] md:h-[6.4rem] -mt-[0.5rem] md:-mt-[0.65rem]"
                style={{ width: collab.width * scaleFactor }}
              >
                <Image
                  src={collab.logo || "/placeholder.svg"}
                  alt={`${collab.name} logo`}
                  width={collab.width * scaleFactor}
                  height={collab.height * scaleFactor}
                  className="object-contain brightness-0 invert"
                  priority={false}
                />
              </div>
            )
          })}
        </div>
      </div>

      {/* Brand Showcase Section */}
      <div className="container mx-auto px-2 mb-4">
        {/* Brand Section Title */}
        <div className="mb-4 text-center max-w-2xl mx-auto">
          <h3 className="text-white text-2xl font-medium mb-1">Luxury Watch Brands</h3>
          <p className="text-white/70 text-sm md:text-base">
            Explore our curated collection of prestigious timepieces from the world&apos;s most renowned watchmakers,
            each representing a unique heritage of craftsmanship and innovation.
          </p>
        </div>

        {/* Brand Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-6 gap-2 md:gap-3">
          {brands.map((brand, index) => (
            <Link
              key={brand.id}
              href={`/brands/${brand.id}`}
              className="block group focus:outline-none focus:ring-2 focus:ring-white/50 focus:rounded-xl"
              onClick={() => {
                // Pre-loading state for seamless transitions
                setIsImageLoading((prev) => ({
                  ...prev,
                  [brand.id]: true,
                }))
              }}
            >
              <div
                className="h-44 md:h-72 backdrop-blur-md bg-white/5 p-3 md:p-6 flex flex-col items-center justify-between 
                transition-all duration-300 hover:translate-y-[-4px] rounded-xl border border-transparent 
                hover:border-white/10 hover:bg-white/10"
              >
                {/* Brand Image Container */}
                <div className="flex-1 flex items-center justify-center mb-2 md:mb-4 min-h-[100px] md:min-h-[180px] relative w-full">
                  {/* Loading Skeleton */}
                  <div
                    className={`absolute inset-0 flex items-center justify-center ${isImageLoading[brand.id] ? "opacity-100" : "opacity-0"} transition-opacity duration-300`}
                  >
                    <Image
                      src="/placeholder.svg?key=jqvyu"
                      alt="Loading placeholder"
                      width={96}
                      height={96}
                      className="opacity-70"
                    />
                  </div>

                  {/* Actual Image */}
                  <Image
                    src={brand.imagePath || "/placeholder.svg"}
                    alt={`${brand.name} luxury watch`}
                    width={168}
                    height={168}
                    className={`max-h-[98px] md:max-h-[196px] w-auto object-contain 
                      transition-all duration-300 group-hover:scale-110 
                      ${isImageLoading[brand.id] ? "opacity-0" : "opacity-100"}`}
                    priority={index < 3}
                    sizes="(max-width: 640px) 40vw, (max-width: 768px) 25vw, (max-width: 1024px) 16vw, 168px"
                    loading={index < 3 ? "eager" : "lazy"}
                    onLoad={() => handleImageLoad(brand.id)}
                    onError={() => handleImageError(brand.id)}
                  />
                </div>

                {/* Brand Info */}
                <div className="text-center">
                  <h3
                    className="text-xs md:text-base font-medium text-white mb-0 md:whitespace-nowrap md:overflow-hidden md:text-ellipsis md:max-w-full"
                    title={brand.name}
                  >
                    {brand.name}
                  </h3>
                  <div className="flex items-center justify-center mt-1 text-white/70 text-[10px] md:text-xs">
                    <span>View all models</span>
                    <ArrowUpRight className="w-2 h-2 md:w-3 md:h-3 ml-1" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Add animation keyframes */}
      <style jsx global>{`
        @keyframes marquee {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
      `}</style>

      {/* Search Year by Serial Section */}
      <div id="serial-search" className="container mx-auto px-2 mt-16" style={{ scrollMarginTop: "5rem" }}>
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-6">
            <h3 className="text-white text-2xl font-medium mb-1">Search Year by Serial</h3>
            <p className="text-white/70 text-sm md:text-base">
              Enter your Rolex watch serial number to discover its production year
            </p>
          </div>

          <form onSubmit={handleSearch} className="relative max-w-md mx-auto mb-8">
            <div className="relative">
              <input
                type="text"
                value={serialNumber}
                onChange={(e) => setSerialNumber(e.target.value)}
                placeholder="Enter serial number..."
                className="w-full py-3 px-4 pr-12 bg-white/10 backdrop-blur-md 
                rounded-xl text-white placeholder:text-white/50 focus:outline-none focus:ring-2 
                focus:ring-white/30 transition-all"
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-white/70 hover:text-white 
                focus:outline-none focus:text-white transition-colors"
                aria-label="Search"
                disabled={isSearching}
              >
                {isSearching ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white/80 rounded-full animate-spin"></div>
                ) : (
                  <Search className="w-5 h-5" />
                )}
              </button>
            </div>

            {searchResult && (
              <div className="mt-4 p-4 bg-white/10 backdrop-blur-md rounded-xl text-center">
                <p className="text-white font-medium text-lg">Production Year: {searchResult.year}</p>
                <p className="text-white/70 text-sm mt-1">
                  {searchResult.exact
                    ? `Matched with serial pattern: ${searchResult.match || "Custom match"}`
                    : `Estimated based on similar serials`}
                </p>
              </div>
            )}
          </form>

          <div className="text-center mb-4">
            <button
              onClick={() => setShowFullTable(!showFullTable)}
              className="inline-flex items-center text-white/80 hover:text-white text-sm font-medium"
            >
              <Info className="w-4 h-4 mr-1" />
              {showFullTable ? "Hide" : "Show"} Serial Number Reference Table
            </button>
          </div>

          {showFullTable && (
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 overflow-hidden">
              <h4 className="text-white text-center text-lg font-medium mb-4">Rolex Serial Number Reference Table</h4>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {decadeGroups.map(([decade, entries]) => (
                  <div key={decade} className="bg-white/5 rounded-lg p-3">
                    <h5 className="text-white font-medium mb-2">{decade}</h5>
                    <div className="space-y-1">
                      {entries.map((entry, idx) => (
                        <div key={idx} className="flex justify-between text-sm">
                          <span className="text-white/80">{entry.year}</span>
                          <span className="text-white font-mono">{entry.serial_number || "—"}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <p className="text-white/60 text-xs text-center mt-4">
                Note: Serial numbers from 2011 onwards are randomized and cannot be precisely dated by serial number
                alone.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
