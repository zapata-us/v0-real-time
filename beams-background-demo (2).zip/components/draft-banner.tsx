"use client"

import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import { AlertTriangle, Eye, Rocket } from "lucide-react"
import { Button } from "@/components/ui/button"
import { fetchDraftProductById, publishDraft } from "@/lib/product-service"
import { useToast } from "@/hooks/use-toast"

export function DraftBanner() {
  const pathname = usePathname()
  const router = useRouter()
  const { toast } = useToast()
  const [showBanner, setShowBanner] = useState(false)
  const [productId, setProductId] = useState<string | null>(null)
  const [isPublishing, setIsPublishing] = useState(false)

  useEffect(() => {
    // Check if we're on a product page
    if (pathname.startsWith("/product/")) {
      const id = pathname.split("/").pop()
      if (id) {
        setProductId(id)
        checkForDraft(id)
      }
    }
  }, [pathname])

  const checkForDraft = async (id: string) => {
    try {
      const draft = await fetchDraftProductById(id)
      setShowBanner(!!draft)
    } catch (error) {
      console.error("Error checking for draft:", error)
    }
  }

  const handlePublish = async () => {
    if (!productId) return

    setIsPublishing(true)
    try {
      await publishDraft(productId)

      toast({
        title: "Changes Published",
        description: "Your draft changes have been published and are now visible to all users.",
      })

      setShowBanner(false)
      // Refresh the page to show the published version
      router.refresh()
    } catch (error) {
      toast({
        title: "Error Publishing Changes",
        description: "There was a problem publishing your changes. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsPublishing(false)
    }
  }

  const viewDraft = () => {
    if (!productId) return
    router.push(`/admin/products/edit/${productId}?draft=true`)
  }

  if (!showBanner) return null

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-yellow-900/80 backdrop-blur-md z-50 p-3 border-t border-yellow-600">
      <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center">
          <AlertTriangle className="h-5 w-5 text-yellow-400 mr-2" />
          <span className="text-white">
            This product has unpublished draft changes. These changes are not visible to regular users.
          </span>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="border-yellow-400 text-yellow-400 hover:bg-yellow-400/20"
            onClick={viewDraft}
          >
            <Eye className="h-4 w-4 mr-2" />
            View Draft
          </Button>
          <Button
            size="sm"
            className="bg-yellow-400 text-yellow-900 hover:bg-yellow-500"
            onClick={handlePublish}
            disabled={isPublishing}
          >
            {isPublishing ? (
              <>
                <div className="h-3 w-3 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                Publishing...
              </>
            ) : (
              <>
                <Rocket className="h-4 w-4 mr-2" />
                Publish Now
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
