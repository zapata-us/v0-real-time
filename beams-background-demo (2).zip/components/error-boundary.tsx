"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { AlertTriangle, RefreshCw } from "lucide-react"

interface ErrorBoundaryProps {
  children: React.ReactNode
}

export function ErrorBoundary({ children }: ErrorBoundaryProps) {
  const [hasError, setHasError] = useState(false)

  useEffect(() => {
    const handleError = () => {
      setHasError(true)

      // Log error to monitoring service in production
      if (process.env.NODE_ENV === "production") {
        // Example: Send to error monitoring service
        // errorMonitoringService.captureException(error)
        console.error("An error occurred in the application")
      }
    }

    window.addEventListener("error", handleError)

    return () => {
      window.removeEventListener("error", handleError)
    }
  }, [])

  if (hasError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black p-4">
        <div className="max-w-md w-full bg-white/10 backdrop-blur-xl p-8 rounded-xl text-center">
          <AlertTriangle className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Something went wrong</h2>
          <p className="text-white/70 mb-6">We apologize for the inconvenience. Please try refreshing the page.</p>
          <Button
            onClick={() => {
              setHasError(false)
              window.location.reload()
            }}
            className="bg-white/20 hover:bg-white/30 text-white"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Page
          </Button>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
