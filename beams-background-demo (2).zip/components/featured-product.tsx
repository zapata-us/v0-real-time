"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { motion, useInView, useAnimation } from "framer-motion"
import { Button } from "@/components/ui/button"

export function FeaturedProduct() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.3, margin: "0px 0px -100px 0px" })
  const controls = useAnimation()
  const textControls = useAnimation()
  const imageControls = useAnimation()

  useEffect(() => {
    if (isInView) {
      controls.start({ opacity: 1, scale: 1, transition: { duration: 0.5, ease: [0.25, 0.1, 0.25, 1] } })
      textControls.start({ opacity: 1, x: 0, transition: { duration: 0.4, delay: 0.1, ease: [0.25, 0.1, 0.25, 1] } })
      imageControls.start({ opacity: 1, x: 0, transition: { duration: 0.4, delay: 0.2, ease: [0.25, 0.1, 0.25, 1] } })
    }
  }, [isInView, controls, textControls, imageControls])

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.98 }}
      animate={controls}
      className="relative overflow-hidden rounded-lg backdrop-blur-md bg-black/20 border border-white/10 hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all duration-300 h-full"
    >
      <div className="grid grid-cols-1 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={textControls}
          className="p-6 md:p-8 flex flex-col justify-center backdrop-blur-sm bg-black/10"
        >
          <div className="mb-2 text-sm font-medium uppercase tracking-wider text-white/70">Certified Authentic</div>
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">Rolex GMT-Master II</h2>
          <p className="text-white/80 mb-6 text-sm md:text-base">
            Each timepiece undergoes rigorous authentication by our certified experts, ensuring you receive only genuine
            luxury watches with complete documentation.
          </p>
          <div className="text-xl font-bold text-white mb-6">$14,950</div>
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.3 }}
          >
            <Button className="w-fit rounded-full bg-white text-black hover:bg-white/90">
              View Certificate
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </motion.div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={imageControls}
          className="relative aspect-square md:aspect-auto p-4"
        >
          <Image
            src="/images/watches/real-time-gmt-master-II-Batman.png"
            alt="Rolex GMT-Master II"
            fill
            className="object-contain"
            sizes="(max-width: 768px) 100vw, 50vw"
            priority
          />
        </motion.div>
      </div>
    </motion.div>
  )
}
