"use client"

import { useState, useRef, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

// Featured product type
interface FeaturedProduct {
  id: string
  name: string
  brand: string
  price: number
  image: string
  isNew?: boolean
  isLimited?: boolean
  discount?: number
  addedDate?: number // Timestamp for when the product was added
}

// Sample featured products data - sorted by newest first
const featuredProducts: FeaturedProduct[] = [
  {
    id: "rolex-daytona",
    name: "Cosmograph Daytona",
    brand: "Rolex",
    price: 39900,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    isNew: true,
    addedDate: Date.now() - 2 * 24 * 60 * 60 * 1000, // 2 days ago
  },
  {
    id: "patek-nautilus",
    name: "Nautilus 5711",
    brand: "Patek Philippe",
    price: 135000,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    isLimited: true,
    addedDate: Date.now() - 5 * 24 * 60 * 60 * 1000, // 5 days ago
  },
  {
    id: "cartier-santos",
    name: "Santos de Cartier",
    brand: "Cartier",
    price: 7800,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    addedDate: Date.now() - 7 * 24 * 60 * 60 * 1000, // 7 days ago
  },
  {
    id: "ap-royal-oak",
    name: "Royal Oak Offshore",
    brand: "Audemars Piguet",
    price: 45900,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    addedDate: Date.now() - 10 * 24 * 60 * 60 * 1000, // 10 days ago
  },
  {
    id: "hublot-big-bang",
    name: "Big Bang Unico",
    brand: "Hublot",
    price: 22900,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    discount: 15,
    addedDate: Date.now() - 14 * 24 * 60 * 60 * 1000, // 14 days ago
  },
  {
    id: "bvlgari-octo",
    name: "Octo Finissimo",
    brand: "Bvlgari",
    price: 12300,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    addedDate: Date.now() - 20 * 24 * 60 * 60 * 1000, // 20 days ago
  },
]

// Sample reference numbers for each product
const referenceNumbers = {
  "rolex-daytona": "116500LN",
  "patek-nautilus": "5711/1A-010",
  "cartier-santos": "WSSA0018",
  "ap-royal-oak": "26470ST.OO.A027CA.01",
  "hublot-big-bang": "411.NX.1170.RX",
  "bvlgari-octo": "103464",
}

// Sort products by newest first
const sortedProducts = [...featuredProducts].sort((a, b) => {
  const dateA = a.addedDate || 0
  const dateB = b.addedDate || 0
  return dateB - dateA
})

interface FeaturedProductsProps {
  disableAutoScroll?: boolean
  desktopItemCount?: number
}

export function FeaturedProducts({ disableAutoScroll, desktopItemCount = 3 }: FeaturedProductsProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isMobile, setIsMobile] = useState(false)
  const [isIOS, setIsIOS] = useState(false)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  // Check device type on mount
  useEffect(() => {
    const checkDeviceType = () => {
      const mobile = window.innerWidth < 768
      const iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream

      setIsMobile(mobile)
      setIsIOS(iOS)

      // Apply iOS-specific optimizations
      if (iOS) {
        document.documentElement.style.setProperty("--scroll-behavior", "auto")
      }
    }

    checkDeviceType()
    window.addEventListener("resize", checkDeviceType)

    return () => {
      window.removeEventListener("resize", checkDeviceType)
      document.documentElement.style.removeProperty("--scroll-behavior")
    }
  }, [])

  // Simple navigation functions
  const scrollToIndex = (index: number) => {
    if (!scrollContainerRef.current) return

    const container = scrollContainerRef.current
    const itemsPerView = getVisibleItems()
    const itemWidth = container.clientWidth / itemsPerView

    const newPosition = index * itemWidth

    // Use simpler scroll for iOS
    if (isIOS) {
      container.scrollLeft = newPosition
    } else {
      container.scrollTo({
        left: newPosition,
        behavior: "smooth",
      })
    }

    setCurrentIndex(index)
  }

  const handlePrev = () => {
    const newIndex = Math.max(0, currentIndex - 1)
    scrollToIndex(newIndex)
  }

  const handleNext = () => {
    const visibleItems = getVisibleItems()
    const maxIndex = Math.max(0, sortedProducts.length - visibleItems)
    const newIndex = Math.min(maxIndex, currentIndex + 1)
    scrollToIndex(newIndex)
  }

  // Get visible items count based on screen size
  const getVisibleItems = () => {
    if (typeof window === "undefined") return desktopItemCount // SSR fallback
    if (window.innerWidth < 768) return 2 // Mobile view
    if (window.innerWidth < 1024) return 3 // Tablet view
    return desktopItemCount // Desktop view
  }

  return (
    <div className="relative px-2 sm:px-4 pb-2">
      {/* iOS-optimized header with glass morphism effect */}
      <div
        className="mb-5 rounded-xl p-3 flex items-center justify-between"
        style={{
          backdropFilter: "blur(10px)",
          WebkitBackdropFilter: "blur(10px)",
          boxShadow: "0 8px 32px rgba(0,0,0,0.1)",
        }}
      >
        <div className="flex flex-col">
          <h3 className="text-lg font-medium text-white" style={{ fontWeight: 600, letterSpacing: "-0.01em" }}>
            Latest Models
          </h3>
          <p className="text-xs text-white/70 mt-0.5">Discover our newest timepieces</p>
        </div>

        {/* Navigation buttons with iOS-style design */}
        <div className="flex space-x-2">
          {" "}
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrev}
            disabled={currentIndex === 0}
            className="rounded-full h-8 w-8 p-0 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20"
            style={{
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
              transition: "all 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
              border: "none",
            }}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleNext}
            disabled={currentIndex >= sortedProducts.length - getVisibleItems()}
            className="rounded-full h-8 w-8 p-0 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20"
            style={{
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
              transition: "all 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
              border: "none",
            }}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Optimized scroll container */}
      <div
        ref={scrollContainerRef}
        className="flex overflow-x-auto scrollbar-hide snap-x snap-mandatory"
        style={{
          scrollbarWidth: "none",
          msOverflowStyle: "none",
          WebkitOverflowScrolling: "touch",
          transform: "translateZ(0)", // Force GPU acceleration
          willChange: "transform", // Optimize for animations
        }}
      >
        {sortedProducts.map((product, index) => (
          <div
            key={product.id}
            className={`flex-shrink-0 w-1/2 sm:w-1/2 ${
              desktopItemCount === 6 ? "lg:w-1/6" : "lg:w-1/3"
            } px-2 pb-1 snap-start`}
            style={{
              scrollSnapAlign: "start",
              perspective: "1000px", // Add perspective for 3D effect
              transformStyle: "preserve-3d", // Preserve 3D transformations
              transition: "transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94)", // iOS-like transition
            }}
          >
            <div
              className="h-full rounded-2xl overflow-hidden"
              style={{
                background: "rgba(255, 255, 255, 0.05)",
                backdropFilter: "blur(20px)",
                WebkitBackdropFilter: "blur(20px)",
                boxShadow: "0 8px 20px rgba(0, 0, 0, 0.12), 0 3px 6px rgba(0, 0, 0, 0.08)",
                transform: "translateZ(0)", // Force GPU acceleration
                willChange: "transform", // Optimize for animations
              }}
            >
              <div className="p-0">
                {/* Product image - iOS optimized */}
                <Link href={`/product/${product.id}`} prefetch={false}>
                  <div
                    className="relative h-[207px] sm:h-[322px] w-full"
                    style={{
                      background: "linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.1) 100%)",
                    }}
                  >
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      fill
                      className="object-contain p-3"
                      sizes={`(max-width: 640px) 50vw, (max-width: 1024px) 50vw, ${
                        desktopItemCount === 6 ? "16vw" : "33vw"
                      }`}
                      priority={index < 4}
                      loading={index < 4 ? "eager" : "lazy"}
                      style={{
                        transform: "translateZ(0)", // Force GPU acceleration
                        willChange: isIOS ? "transform" : "auto", // Optimize for iOS
                      }}
                    />
                  </div>
                </Link>

                {/* Product info - iOS style */}
                <div
                  className="p-3 sm:p-4"
                  style={{
                    backdropFilter: "blur(10px)",
                    WebkitBackdropFilter: "blur(10px)",
                  }}
                >
                  <Link href={`/product/${product.id}`} prefetch={false}>
                    <h3
                      className="text-sm font-semibold text-white truncate leading-tight"
                      style={{
                        fontWeight: 500,
                        letterSpacing: "-0.02em",
                      }}
                    >
                      {product.name}
                    </h3>
                    <p className="text-xs text-white/70 mb-1" style={{ fontWeight: 400 }}>
                      {referenceNumbers[product.id as keyof typeof referenceNumbers] || product.id}
                    </p>
                  </Link>

                  <div className="flex justify-between items-center mt-1">
                    <div>
                      <span className="text-white font-bold" style={{ fontWeight: 600 }}>
                        ${product.price.toLocaleString()}
                      </span>
                    </div>

                    <Button
                      size="sm"
                      asChild
                      className="rounded-full bg-white/90 text-black hover:bg-white"
                      style={{
                        boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
                        fontSize: "0.8125rem",
                        fontWeight: 500,
                        letterSpacing: "-0.01em",
                        padding: "0.375rem 0.875rem",
                      }}
                    >
                      <Link href={`/product/${product.id}`} prefetch={false}>
                        View
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Mobile swipe indicator - iOS style */}
      {isMobile && (
        <div className="mt-4 flex justify-center">
          <div
            className="flex items-center space-x-1 px-3 py-1.5 rounded-full"
            style={{
              background: "rgba(255,255,255,0.1)",
              backdropFilter: "blur(10px)",
              WebkitBackdropFilter: "blur(10px)",
              boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
            }}
          >
            <div className="w-5 h-1 bg-white/50 rounded-full"></div>
            <span className="text-xs text-white/70">Swipe to see more</span>
          </div>
        </div>
      )}

      {/* View All Products CTA - iOS style */}
      <div className="flex justify-center mt-6">
        <Button
          asChild
          className="rounded-full text-white px-6 py-2"
          style={{
            background: "rgba(255,255,255,0.15)",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
            boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
            fontSize: "0.9375rem",
            fontWeight: 500,
            letterSpacing: "-0.01em",
            transition: "all 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
            border: "none",
          }}
        >
          <Link href="/collection" prefetch={false}>
            View All Timepieces
          </Link>
        </Button>
      </div>
    </div>
  )
}
