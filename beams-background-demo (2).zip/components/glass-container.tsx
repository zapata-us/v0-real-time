"use client"

import type React from "react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

interface GlassContainerProps {
  children: React.ReactNode
  className?: string
  animate?: boolean
}

export function GlassContainer({ children, className, animate = true }: GlassContainerProps) {
  const containerContent = (
    <div
      className={cn(
        "backdrop-blur-md bg-black/20 border border-white/10 rounded-lg p-6 hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all duration-300",
        className,
      )}
    >
      {children}
    </div>
  )

  if (animate) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        {containerContent}
      </motion.div>
    )
  }

  return containerContent
}
