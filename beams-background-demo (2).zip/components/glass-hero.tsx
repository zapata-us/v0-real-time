"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { motion, useInView, useAnimation } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useIOSDetection } from "@/lib/use-ios-detection"
import { useRouter } from "next/navigation"

export function GlassHero() {
  const ref = useRef(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const isInView = useInView(ref, { once: true, amount: 0.2 })
  const controls = useAnimation()
  const isIOS = useIOSDetection()
  const [videoLoaded, setVideoLoaded] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  // Add this at the top of the component
  const isIOSDevice =
    typeof navigator !== "undefined" && /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/collection?search=${encodeURIComponent(searchQuery)}`)
    }
  }

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [isInView, controls])

  // Optimize video playback for iOS Safari
  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    // Function to attempt playing the video
    const attemptPlay = () => {
      video.play().catch((error) => {
        // If autoplay was prevented, we'll try again on user interaction
        console.log("Video autoplay prevented:", error)
      })
    }

    // iOS Safari specific optimizations
    video.playsInline = true
    video.setAttribute("playsinline", "true")
    video.muted = true
    video.setAttribute("muted", "true")

    // For iOS Safari, preload metadata only to save bandwidth
    video.preload = isIOS ? "none" : "metadata"

    // Add loaded event listener
    const handleLoaded = () => {
      setVideoLoaded(true)
      attemptPlay()
    }

    video.addEventListener("loadeddata", handleLoaded)

    // Try to play immediately for non-iOS
    if (!isIOS) {
      attemptPlay()
    }

    // Also try to play on document interaction for iOS
    const playOnInteraction = () => {
      if (isIOS && !videoLoaded) {
        // For iOS, only start loading the video on first interaction
        video.load()
      } else {
        attemptPlay()
      }
      // Remove the event listeners after first interaction
      document.removeEventListener("touchstart", playOnInteraction)
      document.removeEventListener("click", playOnInteraction)
    }

    document.addEventListener("touchstart", playOnInteraction, { passive: true })
    document.addEventListener("click", playOnInteraction)

    // iOS Safari specific: handle page visibility changes
    const handleVisibilityChange = () => {
      if (document.hidden) {
        video.pause()
      } else if (videoLoaded) {
        attemptPlay()
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)

    return () => {
      document.removeEventListener("touchstart", playOnInteraction)
      document.removeEventListener("click", playOnInteraction)
      document.removeEventListener("visibilitychange", handleVisibilityChange)
      video.removeEventListener("loadeddata", handleLoaded)
    }
  }, [isIOS, videoLoaded])

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const titleVariants = {
    hidden: { opacity: 0, y: isIOSDevice ? -10 : -20 }, // Smaller distance for iOS
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: isIOSDevice ? 0.4 : 0.6, // Shorter duration for iOS
        ease: [0.25, 0.1, 0.25, 1],
      },
    },
  }

  const descriptionVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.4,
        ease: [0.25, 0.1, 0.25, 1],
      },
    },
  }

  const searchVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.4,
        ease: [0.25, 0.1, 0.25, 1],
      },
    },
  }

  const buttonVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.4,
        ease: [0.25, 0.1, 0.25, 1],
      },
    },
  }

  return (
    <div className="relative py-32 md:py-48 text-center" ref={ref}>
      {/* Video Background */}
      <div className="absolute inset-0 overflow-hidden -z-10">
        <div className="absolute inset-0 bg-black/50 backdrop-blur-[2px] z-10"></div>
        <video
          ref={videoRef}
          className="absolute w-full h-full object-cover"
          playsInline
          muted
          loop
          autoPlay={!isIOS}
          preload={isIOS ? "none" : "auto"}
          poster="/placeholder.svg?height=1080&width=1920"
          disablePictureInPicture
          disableRemotePlayback
          style={{
            objectFit: "cover",
            WebkitTransform: "translateZ(0)",
            transform: "translateZ(0)",
            willChange: isIOS ? "transform" : "auto", // Add will-change hint for iOS
          }}
        >
          <source
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/relojes%201%20final-u4ybhC0U42E4Ot3J8DLuztbdBsfBnZ.mp4"
            type="video/mp4"
          />
        </video>
      </div>

      <motion.div
        className="container mx-auto px-4 relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate={controls}
      >
        <motion.h1 variants={titleVariants} className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
          Exceptional Timepieces
        </motion.h1>

        <motion.p variants={descriptionVariants} className="text-xl text-white/80 max-w-3xl mx-auto mb-8">
          Discover the world's finest luxury watches in the heart of Miami's jewelry district.
        </motion.p>

        {/* Search Bar */}
        <motion.div variants={searchVariants} className="max-w-md mx-auto mb-8">
          <form onSubmit={handleSearch} className="relative flex items-center">
            <div className="absolute inset-0 bg-white/5 rounded-full blur-md"></div>
            <div className="relative flex items-center bg-black/30 backdrop-blur-md rounded-full overflow-hidden w-full">
              <Input
                type="text"
                placeholder="Search for watches..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent border-0 text-white placeholder:text-white/50 focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:ring-offset-0 focus-visible:outline-none focus:border-0 active:outline-none active:ring-0 active:border-0 h-12 pl-6"
                style={{ touchAction: "manipulation", fontSize: "16px" }} // Prevent zoom on iOS
              />
              <Button
                type="submit"
                variant="ghost"
                size="icon"
                className="text-white h-12 w-12 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
              >
                <Search className="h-5 w-5" />
              </Button>
            </div>
          </form>
        </motion.div>

        <motion.div
          variants={buttonVariants}
          className="flex flex-col sm:flex-row justify-center gap-4 w-full max-w-md mx-auto"
        >
          <Button
            asChild
            className="w-full rounded-lg bg-white/15 text-white hover:bg-white/25 px-6 py-5 shadow-[0_4px_30px_rgba(255,255,255,0.25)] transition-all duration-300 relative overflow-hidden"
            style={{
              backdropFilter: "blur(20px)",
              WebkitBackdropFilter: "blur(20px)",
            }}
          >
            <a
              href="/marketplace"
              className="relative z-10 flex items-center justify-center"
              aria-label="Explore our watch collection"
            >
              <span className="relative">Explore Collection</span>
            </a>
          </Button>

          <Button
            asChild
            className="w-full rounded-lg bg-white/15 text-white hover:bg-white/25 px-6 py-5 shadow-[0_4px_30px_rgba(255,255,255,0.25)] transition-all duration-300 relative overflow-hidden"
            style={{
              backdropFilter: "blur(20px)",
              WebkitBackdropFilter: "blur(20px)",
            }}
          >
            <a
              href="/marketplace#brands"
              className="relative z-10 flex items-center justify-center"
              aria-label="View watch brands in our marketplace"
            >
              <span className="relative">View Brands</span>
            </a>
          </Button>
        </motion.div>
      </motion.div>
    </div>
  )
}
