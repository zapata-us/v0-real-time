"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Search, X, LogIn } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useRouter } from "next/navigation"

interface GlassNavbarProps {
  className?: string
}

export function GlassNavbar({ className }: GlassNavbarProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()
  const [isSearchOpen, setIsSearchOpen] = useState(false)

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/marketplace?search=${encodeURIComponent(searchQuery)}`)
      setIsSearchOpen(false)
      setSearchQuery("")
    }
  }

  return (
    <header className={cn("fixed top-0 left-0 right-0 z-50 w-full", className)}>
      {/* Glass effect container */}
      <div className="relative backdrop-blur-md bg-black/25">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between relative">
            {/* Left Corner - Subscriber Login */}
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
              {/* Subscriber Login Link */}
              <Link
                href="/subscribers"
                className="flex items-center gap-1.5 text-[0.85rem] text-white hover:text-white/90 transition-colors"
                aria-label="Subscriber Area"
              >
                <LogIn className="h-4 w-4" />
                <span className="font-light tracking-wide hidden sm:inline">Subscribers</span>
              </Link>
            </div>

            {/* Center Logo */}
            <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-[22%]">
              <Link
                href="/"
                className="flex items-center"
                onClick={(e) => {
                  // If already on homepage, prevent default navigation and just scroll to top
                  if (window.location.pathname === "/" || window.location.pathname === "") {
                    e.preventDefault()
                    window.scrollTo({ top: 0, behavior: "smooth" })
                  }
                }}
              >
                <div className="relative h-16 w-auto">
                  <Image
                    src="/images/real-time-logo.png"
                    alt="REAL TIME Logo"
                    width={300}
                    height={75}
                    className="object-contain"
                    priority
                  />
                </div>
              </Link>
            </div>

            {/* Mobile Burger Menu */}
            <div className="flex items-center">
              <button
                className="text-white h-11 w-14 p-0 absolute top-[13%] -right-2 bg-transparent border-none focus:outline-none"
                onClick={toggleMenu}
                aria-label="Menu"
              >
                {isMenuOpen ? (
                  <X className="h-8 w-8" />
                ) : (
                  <svg
                    width="32"
                    height="32"
                    viewBox="0 0 80 80"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8"
                  >
                    <line x1="20" y1="30" x2="60" y2="30" stroke="white" strokeWidth="4" strokeLinecap="round" />
                    <line x1="20" y1="50" x2="60" y2="50" stroke="white" strokeWidth="4" strokeLinecap="round" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Menu - Compact Version */}
      {isMenuOpen && (
        <div className="absolute right-4 top-[calc(4rem+3vh)] w-64 z-40 bg-black/20 backdrop-blur-2xl rounded-xl shadow-[0_8px_32px_rgba(255,255,255,0.08)] overflow-hidden">
          <div className="p-5">
            {/* Search Bar */}
            <div className="mb-6">
              <form
                onSubmit={handleSearch}
                className="relative flex items-center bg-black/15 rounded-full overflow-hidden"
              >
                <Input
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1 bg-transparent border-0 text-white placeholder:text-white/50 focus:outline-none focus:ring-0 h-9 pl-4 text-sm"
                />
                <Button
                  type="submit"
                  variant="ghost"
                  size="icon"
                  className="text-white h-9 w-9 rounded-full bg-white/8 hover:bg-white/15"
                >
                  <Search className="h-4 w-4" />
                </Button>
              </form>
            </div>

            {/* Simplified Navigation */}
            <nav className="space-y-1">
              <Link
                href="/"
                className="block text-sm font-medium text-white/90 hover:text-white py-2.5 px-3 rounded-lg hover:bg-white/5"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
              <Link
                href="/marketplace"
                className="block text-sm font-medium text-white/90 hover:text-white py-2.5 px-3 rounded-lg hover:bg-white/5"
                onClick={() => setIsMenuOpen(false)}
              >
                Marketplace
              </Link>
              <Link
                href="/#serial-search"
                className="block text-sm font-medium text-white/90 hover:text-white py-2.5 px-3 rounded-lg hover:bg-white/5"
                onClick={(e) => {
                  setIsMenuOpen(false)
                  // Check if we're already on the homepage
                  if (window.location.pathname === "/" || window.location.pathname === "") {
                    e.preventDefault()
                    // Find the element and scroll to it
                    const element = document.getElementById("serial-search")
                    if (element) {
                      element.scrollIntoView({ behavior: "smooth", block: "start" })
                    }
                  }
                }}
              >
                Search by Serial
              </Link>
              <Link
                href="/about"
                className="block text-sm font-medium text-white/90 hover:text-white py-2.5 px-3 rounded-lg hover:bg-white/5"
                onClick={() => setIsMenuOpen(false)}
              >
                About
              </Link>
              <Link
                href="/support"
                className="block text-sm font-medium text-white/90 hover:text-white py-2.5 px-3 rounded-lg hover:bg-white/5"
                onClick={() => setIsMenuOpen(false)}
              >
                Support
              </Link>
              <Link
                href="/contact"
                className="block text-sm font-medium text-white/90 hover:text-white py-2.5 px-3 rounded-lg hover:bg-white/5"
                onClick={() => setIsMenuOpen(false)}
              >
                Contact
              </Link>
              <Link
                href="/subscribers"
                className="block text-sm font-medium text-white hover:text-white/90 py-2.5 px-3 rounded-lg hover:bg-white/5 flex items-center"
                onClick={() => setIsMenuOpen(false)}
              >
                <LogIn className="h-4 w-4 mr-2" />
                Subscribers
              </Link>
            </nav>
          </div>
        </div>
      )}
    </header>
  )
}
