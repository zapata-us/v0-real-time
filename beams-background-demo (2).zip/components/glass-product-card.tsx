"use client"

import { useRef } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface ProductProps {
  id: string
  name: string
  brand: string
  price: number
  image: string
  className?: string
}

export function GlassProductCard({ id, name, brand, price, image, className }: ProductProps) {
  const titleRef = useRef<HTMLHeadingElement>(null)

  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-xl backdrop-blur-xl bg-gradient-to-b from-white/10 to-black/30 transition-colors duration-500 hover:from-white/15 hover:to-black/40 hover:shadow-[0_8px_32px_rgba(255,255,255,0.15)] flex flex-col max-h-[285px] shadow-lg",
        className,
      )}
      data-product-id={id}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-white/5 opacity-50 pointer-events-none"></div>

      <div className="aspect-square overflow-hidden flex-shrink-0 max-h-[220px]">
        <Image
          src={image || "/placeholder.svg"}
          alt={name}
          width={500}
          height={500}
          className="h-full w-full object-contain transition-transform duration-700 group-hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
      </div>

      <div className="absolute top-3 right-3">
        <div
          className="flex items-center text-[10px] text-emerald-400 bg-black/40 px-2 py-1 rounded-full"
          style={{
            WebkitTransform: "translateZ(0)",
            transform: "translateZ(0)",
            WebkitBackfaceVisibility: "hidden",
            backfaceVisibility: "hidden",
            WebkitPerspective: 1000,
            perspective: 1000,
          }}
        >
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1"></div>
          In Stock
        </div>
      </div>

      <div className="px-3 py-1 flex-grow-0 w-full">
        <div className="flex items-center justify-between mb-0.5">
          <div className="text-sm font-medium text-white/70">{brand}</div>
        </div>

        <div className="text-xs text-white/60 mb-0.5">
          Ref. {id.toUpperCase()}-
          {Math.floor(Math.random() * 1000)
            .toString()
            .padStart(3, "0")}
        </div>

        <h3
          ref={titleRef}
          className="text-xs font-medium text-white mb-2 whitespace-nowrap overflow-hidden text-ellipsis"
          title={name}
        >
          {name}
        </h3>

        <div className="flex items-center justify-between">
          <div className="text-sm font-light text-white border-t border-white/10 pt-2 w-full">
            ${price.toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  )
}
