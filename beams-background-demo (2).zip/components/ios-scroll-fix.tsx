"use client"

import { useEffect } from "react"
import { useIOSDetection } from "@/lib/use-ios-detection"

export function IOSScrollFix() {
  const isIOS = useIOSDetection()

  useEffect(() => {
    if (!isIOS) return

    // Fix for iOS Safari scrolling issues
    const handleTouchMove = (e: TouchEvent) => {
      // Allow default scrolling behavior
      // This prevents the need for position: fixed on body
    }

    // Fix for iOS keyboard appearance
    const handleFocus = () => {
      // Add a small delay to scroll the focused element into view
      setTimeout(() => {
        if (document.activeElement instanceof HTMLElement) {
          document.activeElement.scrollIntoView({
            block: "center",
            behavior: "smooth",
          })
        }
      }, 300)
    }

    document.addEventListener("touchmove", handleTouchMove, { passive: true })
    document.addEventListener("focus", handleFocus, true)

    return () => {
      document.removeEventListener("touchmove", handleTouchMove)
      document.removeEventListener("focus", handleFocus, true)
    }
  }, [isIOS])

  // This component doesn't render anything
  return null
}
