"use client"

import { useEffect } from "react"

export function MobilePerformanceOptimizations() {
  useEffect(() => {
    // Check if running on iOS
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream

    if (!isIOS) return

    // iOS-specific optimizations

    // 1. Set viewport meta tag to prevent scaling issues
    const viewportMeta = document.querySelector('meta[name="viewport"]')
    if (viewportMeta) {
      viewportMeta.setAttribute("content", "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no")
    }

    // 2. Add iOS-specific class to body for CSS optimizations
    document.body.classList.add("ios-device")

    // 3. Optimize scroll performance with passive listeners
    const passiveOption = { passive: true }

    // 4. Prevent unnecessary repaints during scroll
    const handleScroll = () => {
      // Empty handler with passive option improves scroll performance
    }

    // 5. Optimize touch events
    const handleTouchMove = () => {
      // Empty handler with passive option improves touch performance
    }

    // 6. Optimize resize events with throttling
    let resizeTimeout: NodeJS.Timeout
    const handleResize = () => {
      if (resizeTimeout) clearTimeout(resizeTimeout)
      resizeTimeout = setTimeout(() => {
        // Handle resize logic here if needed
      }, 100)
    }

    // 7. Optimize page visibility for battery life
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Pause animations, timers, and non-essential operations
        document.body.classList.add("ios-page-hidden")
      } else {
        // Resume animations and operations
        document.body.classList.remove("ios-page-hidden")
      }
    }

    // 8. Add event listeners with passive option for better performance
    window.addEventListener("scroll", handleScroll, passiveOption)
    document.addEventListener("touchmove", handleTouchMove, passiveOption)
    window.addEventListener("resize", handleResize, passiveOption)
    document.addEventListener("visibilitychange", handleVisibilityChange)

    // 9. Disable hover effects on iOS for better performance
    const style = document.createElement("style")
    style.innerHTML = `
      @media (pointer: coarse) {
        .hover-effect {
          transition: none !important;
          transform: none !important;
        }
      }
      
      /* Optimize animations for iOS */
      @supports (-webkit-touch-callout: none) {
        .animate-marquee {
          animation-duration: 30s; /* Slower on iOS */
          will-change: transform; /* Hardware acceleration hint */
          transform: translateZ(0); /* Force hardware acceleration */
        }
        
        /* Pause animations when page is hidden */
        .ios-page-hidden .animate-marquee,
        .ios-page-hidden [class*="animate-"] {
          animation-play-state: paused !important;
        }
        
        /* Fix for 100vh issue in iOS Safari */
        .min-h-screen {
          min-height: 100vh;
          min-height: -webkit-fill-available;
        }
        
        /* Fix for input zooming */
        input, select, textarea {
          font-size: 16px !important;
        }
        
        /* Improve tap targets for iOS */
        button, a, [role="button"] {
          cursor: pointer;
          touch-action: manipulation;
        }
      }
    `
    document.head.appendChild(style)

    // Clean up
    return () => {
      window.removeEventListener("scroll", handleScroll)
      document.removeEventListener("touchmove", handleTouchMove)
      window.removeEventListener("resize", handleResize)
      document.removeEventListener("visibilitychange", handleVisibilityChange)
      document.body.classList.remove("ios-device")
      document.head.removeChild(style)
    }
  }, [])

  // This component doesn't render anything
  return null
}
