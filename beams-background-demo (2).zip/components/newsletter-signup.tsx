"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle2, CreditCard, ArrowRight } from "lucide-react"
import Link from "next/link"

export function PremiumSubscription() {
  const [animationStep, setAnimationStep] = useState(0)

  // Simple animation cycle for the chart
  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationStep((prev) => (prev + 1) % 4)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="py-16 bg-gradient-to-b from-black/0 to-black/30 ios-safe-area">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          {/* Subscription Badge removed */}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Enhanced Chart Preview */}
            <div className="order-2 md:order-1 bg-black/40 backdrop-blur-md rounded-xl p-4 shadow-xl">
              <div className="text-left mb-3">
                <span className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Premium Access</span>
                <h3 className="text-xl font-bold text-white">Real-Time Market Analytics</h3>
              </div>

              {/* Dynamic Chart Display */}
              <div className="relative rounded-lg overflow-hidden h-[240px] bg-gradient-to-br from-black/80 to-black/40">
                {/* Abstract Graph Background with Perpetual Animation */}
                <div className="absolute inset-0">
                  <svg className="w-full h-full" viewBox="0 0 400 240" preserveAspectRatio="none">
                    {/* Animated grid lines */}
                    <g opacity="0.1">
                      {Array.from({ length: 6 }).map((_, i) => (
                        <line key={`h-${i}`} x1="0" y1={i * 40} x2="400" y2={i * 40} stroke="#A8A29E" strokeWidth="1">
                          <animate
                            attributeName="opacity"
                            values="0.1;0.2;0.1"
                            dur={`${3 + i * 0.5}s`}
                            repeatCount="indefinite"
                          />
                        </line>
                      ))}
                      {Array.from({ length: 8 }).map((_, i) => (
                        <line key={`v-${i}`} x1={i * 50} y1="0" x2={i * 50} y2="240" stroke="#A8A29E" strokeWidth="1">
                          <animate
                            attributeName="opacity"
                            values="0.1;0.2;0.1"
                            dur={`${4 + i * 0.3}s`}
                            repeatCount="indefinite"
                          />
                        </line>
                      ))}
                    </g>

                    {/* Gradient definitions */}
                    <defs>
                      <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#A8A29E" stopOpacity="0.3">
                          <animate attributeName="stopOpacity" values="0.3;0.4;0.3" dur="5s" repeatCount="indefinite" />
                        </stop>
                        <stop offset="100%" stopColor="#A8A29E" stopOpacity="0" />
                      </linearGradient>

                      {/* Animated gradient for flowing effect */}
                      <linearGradient id="flowGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#A8A29E" stopOpacity="0">
                          <animate attributeName="offset" values="0;1;0" dur="10s" repeatCount="indefinite" />
                        </stop>
                        <stop offset="25%" stopColor="#A8A29E" stopOpacity="0.2">
                          <animate attributeName="offset" values="0.25;1.25;0.25" dur="10s" repeatCount="indefinite" />
                        </stop>
                        <stop offset="50%" stopColor="#A8A29E" stopOpacity="0">
                          <animate attributeName="offset" values="0.5;1.5;0.5" dur="10s" repeatCount="indefinite" />
                        </stop>
                      </linearGradient>
                    </defs>

                    {/* Animated background flow */}
                    <rect x="0" y="0" width="400" height="240" fill="url(#flowGradient)" opacity="0.1" />

                    {/* Main wave pattern with animation */}
                    <path
                      d="M0,180 C50,160 80,200 120,150 C160,100 200,120 240,80 C280,40 320,60 400,20"
                      fill="none"
                      stroke="#A8A29E"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity="0.8"
                    >
                      <animate
                        attributeName="d"
                        values="
                          M0,180 C50,160 80,200 120,150 C160,100 200,120 240,80 C280,40 320,60 400,20;
                          M0,170 C50,150 80,190 120,140 C160,90 200,110 240,70 C280,30 320,50 400,10;
                          M0,190 C50,170 80,210 120,160 C160,110 200,130 240,90 C280,50 320,70 400,30;
                          M0,180 C50,160 80,200 120,150 C160,100 200,120 240,80 C280,40 320,60 400,20
                        "
                        dur="15s"
                        repeatCount="indefinite"
                      />
                    </path>

                    {/* Secondary wave pattern with animation */}
                    <path
                      d="M0,220 C70,200 120,230 180,180 C240,130 300,150 400,100"
                      fill="none"
                      stroke="#A8A29E"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeDasharray="1,5"
                      opacity="0.6"
                    >
                      <animate
                        attributeName="d"
                        values="
                          M0,220 C70,200 120,230 180,180 C240,130 300,150 400,100;
                          M0,210 C70,190 120,220 180,170 C240,120 300,140 400,90;
                          M0,230 C70,210 120,240 180,190 C240,140 300,160 400,110;
                          M0,220 C70,200 120,230 180,180 C240,130 300,150 400,100
                        "
                        dur="12s"
                        repeatCount="indefinite"
                      />
                      <animate
                        attributeName="strokeDasharray"
                        values="1,5;1,3;1,7;1,5"
                        dur="20s"
                        repeatCount="indefinite"
                      />
                    </path>

                    {/* Animated area fill */}
                    <path
                      d="M0,180 C50,160 80,200 120,150 C160,100 200,120 240,80 C280,40 320,60 400,20 L400,240 L0,240 Z"
                      fill="url(#areaGradient)"
                    >
                      <animate
                        attributeName="d"
                        values="
                          M0,180 C50,160 80,200 120,150 C160,100 200,120 240,80 C280,40 320,60 400,20 L400,240 L0,240 Z;
                          M0,170 C50,150 80,190 120,140 C160,90 200,110 240,70 C280,30 320,50 400,10 L400,240 L0,240 Z;
                          M0,190 C50,170 80,210 120,160 C160,110 200,130 240,90 C280,50 320,70 400,30 L400,240 L0,240 Z;
                          M0,180 C50,160 80,200 120,150 C160,100 200,120 240,80 C280,40 320,60 400,20 L400,240 L0,240 Z
                        "
                        dur="15s"
                        repeatCount="indefinite"
                      />
                    </path>

                    {/* Animated pulse circles */}
                    <circle cx="120" cy="150" r="4" fill="#A8A29E">
                      <animate attributeName="r" values="4;6;4" dur="3s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="1;0.6;1" dur="3s" repeatCount="indefinite" />
                      <animate attributeName="cy" values="150;140;160;150" dur="15s" repeatCount="indefinite" />
                    </circle>

                    <circle cx="240" cy="80" r="4" fill="#A8A29E">
                      <animate attributeName="r" values="4;6;4" dur="3s" repeatCount="indefinite" begin="1s" />
                      <animate attributeName="opacity" values="1;0.6;1" dur="3s" repeatCount="indefinite" begin="1s" />
                      <animate attributeName="cy" values="80;70;90;80" dur="15s" repeatCount="indefinite" />
                    </circle>

                    <circle cx="320" cy="60" r="4" fill="#A8A29E">
                      <animate attributeName="r" values="4;6;4" dur="3s" repeatCount="indefinite" begin="2s" />
                      <animate attributeName="opacity" values="1;0.6;1" dur="3s" repeatCount="indefinite" begin="2s" />
                      <animate attributeName="cy" values="60;50;70;60" dur="15s" repeatCount="indefinite" />
                    </circle>

                    {/* Moving data points that traverse the chart */}
                    <circle cx="0" cy="180" r="3" fill="#A8A29E" opacity="0.8">
                      <animate attributeName="cx" values="-10;410" dur="20s" repeatCount="indefinite" />
                      <animate
                        attributeName="cy"
                        values="180;160;140;120;100;80;60;40;20"
                        dur="20s"
                        repeatCount="indefinite"
                      />
                    </circle>

                    <circle cx="0" cy="200" r="2" fill="#A8A29E" opacity="0.6">
                      <animate attributeName="cx" values="-20;410" dur="25s" repeatCount="indefinite" begin="5s" />
                      <animate
                        attributeName="cy"
                        values="200;190;170;150;130;110;90;70;50;30"
                        dur="25s"
                        repeatCount="indefinite"
                        begin="5s"
                      />
                    </circle>
                  </svg>
                </div>

                {/* Price Tag Overlay */}
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm">
                  <div className="bg-stone-400 text-black px-6 py-3 rounded-lg font-bold text-xl mb-2 shadow-lg transform rotate-[-2deg]">
                    Subscribe to Unlock
                  </div>
                  <p className="text-white/70 text-sm text-center max-w-[80%]">
                    Subscribe now for exclusive access to premium analytics
                  </p>
                </div>
              </div>

              {/* Feature List */}
              <ul className="mt-4 space-y-2 text-sm">
                <li className="flex items-center text-white/80">
                  <CheckCircle2 className="h-4 w-4 text-stone-400 mr-2 flex-shrink-0" />
                  <span>Real-time price movement tracking</span>
                </li>
                <li className="flex items-center text-white/80">
                  <CheckCircle2 className="h-4 w-4 text-stone-400 mr-2 flex-shrink-0" />
                  <span>Exclusive discounts on watch repairs</span>
                </li>
                <li className="flex items-center text-white/80">
                  <CheckCircle2 className="h-4 w-4 text-stone-400 mr-2 flex-shrink-0" />
                  <span>Market trend predictions and alerts</span>
                </li>
              </ul>
            </div>

            {/* Subscription Form */}
            <div className="order-1 md:order-2 text-center md:text-left">
              <h2 className="text-3xl font-bold text-white mb-2">Premium Market Analytics</h2>
              <div className="mb-4 flex flex-col">
                <div className="flex items-center mb-2">
                  <span className="text-stone-400 font-bold text-2xl">$14.99</span>
                  <span className="text-white/70 ml-1">per month</span>
                  <span className="ml-2 bg-stone-400/20 text-stone-400 text-xs px-2 py-0.5 rounded-full">Monthly</span>
                </div>
                <div className="flex items-center">
                  <span className="text-stone-400 font-bold text-xl">$99.99</span>
                  <span className="text-white/70 ml-1">per year</span>
                  <span className="ml-2 bg-stone-400/20 text-stone-400 text-xs px-2 py-0.5 rounded-full">Save 44%</span>
                </div>
              </div>
              <p className="text-white/70 mb-6">
                Subscribe to our premium digital product for exclusive real-time market analytics, price alerts, and
                special offers on luxury timepieces and repair services.
              </p>

              {/* Enhanced subscription button for better iOS experience */}
              <div className="flex items-center">
                <Link
                  href="/subscribers"
                  className="w-full ios-tap-target"
                  aria-label="Subscribe now to access premium features"
                >
                  <Button className="w-full bg-stone-400 text-black hover:bg-stone-500 py-7 px-6 font-medium rounded-full flex items-center justify-center shadow-lg transform transition-transform active:scale-[0.98] text-lg">
                    <CreditCard className="h-5 w-5 mr-2" />
                    Subscribe Now
                    <ArrowRight className="h-5 w-5 ml-2 animate-pulse-subtle" />
                  </Button>
                </Link>
              </div>

              {/* Additional easy access link */}
              <div className="mt-4 text-center">
                <Link
                  href="/subscribers"
                  className="text-stone-400 hover:text-stone-300 text-sm font-medium inline-flex items-center ios-tap-target py-2"
                  aria-label="Learn more about subscription options"
                >
                  View all subscription options
                  <ArrowRight className="h-3.5 w-3.5 ml-1" />
                </Link>
              </div>

              <p className="text-white/50 text-xs mt-4">
                By subscribing, you agree to our Terms of Service and will be billed either $14.99 monthly or $99.99
                annually depending on your selected plan.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Add iOS-specific styles */}
      <style jsx global>{`
        /* iOS-specific optimizations */
        .ios-safe-area {
          padding-left: env(safe-area-inset-left);
          padding-right: env(safe-area-inset-right);
        }
        
        /* Prevent iOS zoom on input focus */
        @supports (-webkit-touch-callout: none) {
          input, select, textarea {
            font-size: 16px !important;
          }
          
          /* Improve tap targets for iOS */
          .ios-tap-target {
            cursor: pointer;
            touch-action: manipulation;
            -webkit-tap-highlight-color: transparent;
            min-height: 44px; /* Apple HIG recommended minimum */
          }
          
          /* Fix for iOS button active state */
          button:active {
            opacity: 0.8;
          }
        }
        
        /* Subtle pulse animation for the arrow */
        @keyframes pulse-subtle {
          0%, 100% { transform: translateX(0); }
          50% { transform: translateX(3px); }
        }
        
        .animate-pulse-subtle {
          animation: pulse-subtle 2s ease-in-out infinite;
        }
      `}</style>
    </section>
  )
}

// Export the old name for backward compatibility
export const NewsletterSignup = PremiumSubscription
