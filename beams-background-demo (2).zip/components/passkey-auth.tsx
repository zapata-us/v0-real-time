"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Check, Lock, Shield } from "lucide-react"

export function PasskeyAuth() {
  const { verifyPasskey, isAuthenticated } = useAuth()
  const [words, setWords] = useState<string[]>(Array(7).fill(""))
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  // Set up input refs
  useEffect(() => {
    inputRefs.current = inputRefs.current.slice(0, 7)
  }, [])

  const handleWordChange = (index: number, value: string) => {
    const newWords = [...words]
    newWords[index] = value.toLowerCase().trim()
    setWords(newWords)

    // Auto-focus next input if this one has content
    if (value && index < 6) {
      inputRefs.current[index + 1]?.focus()
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsSubmitting(true)

    // Check if all words are filled
    if (words.some((word) => !word)) {
      setError("Please enter all seed words")
      setIsSubmitting(false)
      return
    }

    // Verify the passkey
    const isCorrect = verifyPasskey(words)
    if (isCorrect) {
      setSuccess(true)
    } else {
      setError("Invalid seed phrase. Please check your words and try again.")
    }
    setIsSubmitting(false)
  }

  const resetPasskey = () => {
    setWords(Array(7).fill(""))
    setError("")
    setSuccess(false)
    inputRefs.current[0]?.focus()
  }

  if (isAuthenticated) {
    return (
      <Card className="w-full max-w-md bg-black/20 border-white/10 text-white">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Shield className="h-5 w-5 text-green-500" />
            Authentication Successful
          </CardTitle>
          <CardDescription className="text-white/70">
            Your identity has been verified with the secure seed phrase.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-4">
            <Check className="h-16 w-16 text-green-500" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md bg-black/20 border-white/10 text-white">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-2">
          <Lock className="h-5 w-5 text-white/80" />
          Secure Seed Authentication
        </CardTitle>
        <CardDescription className="text-white/70">
          Enter your 7-word seed phrase in the correct order to authenticate
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive" className="bg-red-900/20 border-red-600">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success ? (
            <div className="flex flex-col items-center justify-center p-4 space-y-4">
              <Check className="h-16 w-16 text-green-500" />
              <p className="text-center text-lg">Authentication successful!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              <div className="p-4 bg-black/30 rounded-lg border border-white/10">
                <div className="grid grid-cols-1 gap-3">
                  {Array.from({ length: 7 }).map((_, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-sm font-mono">
                        {index + 1}
                      </div>
                      <Input
                        ref={(el) => (inputRefs.current[index] = el)}
                        type="text"
                        value={words[index]}
                        onChange={(e) => handleWordChange(index, e.target.value)}
                        className="bg-black/20 border-white/20 text-white placeholder:text-white/50 font-mono"
                        placeholder="Enter word"
                        autoComplete="off"
                        spellCheck="false"
                        autoCapitalize="off"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-xs text-white/60 p-2 bg-white/5 rounded">
                <p className="flex items-center gap-1">
                  <Shield className="h-3 w-3" />
                  Security tip: Never share your seed phrase with anyone
                </p>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex gap-3">
          <Button
            type="button"
            variant="outline"
            className="flex-1 bg-white/5 hover:bg-white/10 border-white/20"
            onClick={resetPasskey}
          >
            Reset
          </Button>
          <Button
            type="submit"
            className="flex-1 bg-white text-black hover:bg-white/90"
            disabled={isSubmitting || success}
          >
            {isSubmitting ? (
              <>
                <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                Verifying...
              </>
            ) : (
              "Authenticate"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
