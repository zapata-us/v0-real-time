"use client"

import { CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

interface PaymentConfirmationProps {
  subscriptionDetails: {
    planName: string
    billingCycle: "monthly" | "annual"
    amount: number
    currency: string
    startDate: Date
    nextBillingDate: Date
  }
  onContinue: () => void
}

export function PaymentConfirmation({ subscriptionDetails, onContinue }: PaymentConfirmationProps) {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date)
  }

  const formatCurrency = (amount: number, currency: string) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency.toUpperCase(),
    }).format(amount / 100)
  }

  return (
    <Card className="bg-gray-800/50 border-gray-700 max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto bg-green-500/20 p-3 rounded-full w-16 h-16 flex items-center justify-center mb-4">
          <CheckCircle className="h-8 w-8 text-green-500" />
        </div>
        <CardTitle className="text-xl text-white">Payment Successful!</CardTitle>
        <CardDescription className="text-gray-400">Your subscription has been activated successfully</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-gray-700/30 p-4 rounded-lg">
          <h3 className="text-white font-medium mb-3">Subscription Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Plan:</span>
              <span className="text-white">{subscriptionDetails.planName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Billing Cycle:</span>
              <span className="text-white">{subscriptionDetails.billingCycle === "annual" ? "Annual" : "Monthly"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Amount:</span>
              <span className="text-white">
                {formatCurrency(subscriptionDetails.amount, subscriptionDetails.currency)}
              </span>
            </div>
            <Separator className="bg-gray-600 my-2" />
            <div className="flex justify-between">
              <span className="text-gray-400">Start Date:</span>
              <span className="text-white">{formatDate(subscriptionDetails.startDate)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Next Billing Date:</span>
              <span className="text-white">{formatDate(subscriptionDetails.nextBillingDate)}</span>
            </div>
          </div>
        </div>

        <div className="bg-stone-400/10 border border-stone-400/20 rounded-lg p-4 text-sm">
          <p className="text-white">
            Thank you for subscribing! You now have full access to all features included in your plan. Your subscription
            will automatically renew on the next billing date.
          </p>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={onContinue} className="w-full bg-stone-400 hover:bg-stone-500 text-black">
          Go to Dashboard
        </Button>
      </CardFooter>
    </Card>
  )
}
