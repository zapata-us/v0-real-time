"use client"

import { AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface PaymentErrorProps {
  error: {
    message: string
    code?: string
  }
  onRetry: () => void
  onSupport: () => void
}

export function PaymentError({ error, onRetry, onSupport }: PaymentErrorProps) {
  return (
    <Card className="bg-gray-800/50 border-gray-700 max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto bg-red-500/20 p-3 rounded-full w-16 h-16 flex items-center justify-center mb-4">
          <AlertTriangle className="h-8 w-8 text-red-500" />
        </div>
        <CardTitle className="text-xl text-white">Payment Failed</CardTitle>
        <CardDescription className="text-gray-400">We encountered an issue processing your payment</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert variant="destructive" className="bg-red-900/20 border-red-600">
          <AlertTitle>Error {error.code && `(${error.code})`}</AlertTitle>
          <AlertDescription>{error.message}</AlertDescription>
        </Alert>

        <div className="bg-gray-700/30 p-4 rounded-lg text-sm">
          <h3 className="text-white font-medium mb-2">Common Solutions:</h3>
          <ul className="list-disc list-inside space-y-1 text-gray-400">
            <li>Check your card details and try again</li>
            <li>Ensure your card has sufficient funds</li>
            <li>Try a different payment method</li>
            <li>Contact your bank to authorize the transaction</li>
          </ul>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col space-y-3">
        <Button onClick={onRetry} className="w-full bg-stone-400 hover:bg-stone-500 text-black">
          Try Again
        </Button>
        <Button onClick={onSupport} variant="outline" className="w-full border-gray-600 text-white hover:bg-gray-700">
          Contact Support
        </Button>
      </CardFooter>
    </Card>
  )
}
