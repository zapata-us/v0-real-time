"use client"

import type React from "react"

import { useState } from "react"
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, CreditCard } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface PaymentFormProps {
  priceId: string
  amount: number
  currency: string
  interval: "month" | "year"
  planName: string
  onSuccess: (data: any) => void
  onError: (error: any) => void
  customerId?: string
  userId: string
  email: string
  name: string
}

export function PaymentForm({
  priceId,
  amount,
  currency,
  interval,
  planName,
  onSuccess,
  onError,
  customerId,
  userId,
  email,
  name,
}: PaymentFormProps) {
  const stripe = useStripe()
  const elements = useElements()
  const { toast } = useToast()
  const [isProcessing, setIsProcessing] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault()

    if (!stripe || !elements) {
      return
    }

    const cardElement = elements.getElement(CardElement)

    if (!cardElement) {
      setErrorMessage("Card element not found")
      return
    }

    setIsProcessing(true)
    setErrorMessage(null)

    try {
      // Create payment method
      const { error: paymentMethodError, paymentMethod } = await stripe.createPaymentMethod({
        type: "card",
        card: cardElement,
        billing_details: {
          name,
          email,
        },
      })

      if (paymentMethodError) {
        throw new Error(paymentMethodError.message)
      }

      // Create subscription
      const response = await fetch("/api/stripe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          priceId,
          customerId,
          paymentMethodId: paymentMethod.id,
          userId,
          email,
          name,
          subscriptionType: planName,
          billingCycle: interval,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error?.message || "Failed to process payment")
      }

      // Confirm payment
      const { error: confirmError } = await stripe.confirmCardPayment(data.clientSecret)

      if (confirmError) {
        throw new Error(confirmError.message)
      }

      // Success
      toast({
        title: "Payment successful!",
        description: `You are now subscribed to the ${planName} plan.`,
      })

      onSuccess({
        subscriptionId: data.subscriptionId,
        customerId: data.customerId,
      })
    } catch (error: any) {
      console.error("Payment error:", error)
      setErrorMessage(error.message || "An error occurred during payment processing")
      onError(error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader>
        <CardTitle className="text-xl text-white">Payment Information</CardTitle>
        <CardDescription className="text-gray-400">
          Enter your card details to complete your subscription
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          {errorMessage && (
            <Alert variant="destructive" className="bg-red-900/20 border-red-600">
              <AlertDescription>{errorMessage}</AlertDescription>
            </Alert>
          )}

          <div className="bg-gray-700/30 p-4 rounded-lg mb-4">
            <h3 className="text-white font-medium mb-2">Subscription Summary</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="text-gray-400">Plan:</div>
              <div className="text-white">{planName}</div>
              <div className="text-gray-400">Billing:</div>
              <div className="text-white">{interval === "year" ? "Annual" : "Monthly"}</div>
              <div className="text-gray-400">Price:</div>
              <div className="text-white">
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: currency.toUpperCase(),
                }).format(amount / 100)}{" "}
                per {interval}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="card-element" className="block text-sm font-medium text-white">
                Card Details
              </label>
              <div className="bg-gray-700/50 border border-gray-600 rounded-md p-3">
                <CardElement
                  id="card-element"
                  options={{
                    style: {
                      base: {
                        fontSize: "16px",
                        color: "#ffffff",
                        "::placeholder": {
                          color: "#9ca3af",
                        },
                      },
                      invalid: {
                        color: "#ef4444",
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center p-4 bg-gray-700/20 rounded-lg text-sm">
            <Shield className="h-5 w-5 text-stone-400 mr-3 shrink-0" />
            <p className="text-gray-400">
              Your payment is secure. We use industry-standard encryption to protect your information.
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <Button
            type="submit"
            className="w-full bg-stone-400 hover:bg-stone-500 text-black"
            disabled={isProcessing || !stripe}
          >
            {isProcessing ? (
              <>
                <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                Processing...
              </>
            ) : (
              <>
                <CreditCard className="h-4 w-4 mr-2" />
                Pay{" "}
                {new Intl.NumberFormat("en-US", {
                  style: "currency",
                  currency: currency.toUpperCase(),
                }).format(amount / 100)}
              </>
            )}
          </Button>
          <p className="text-xs text-gray-500 text-center">
            By subscribing, you agree to our{" "}
            <a href="/terms" className="text-stone-400 hover:underline">
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="/privacy" className="text-stone-400 hover:underline">
              Privacy Policy
            </a>
            .
          </p>
        </CardFooter>
      </form>
    </Card>
  )
}
