"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useStripe } from "@stripe/react-stripe-js"
import { CardElement, useElements } from "@stripe/react-stripe-js"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { CreditCard, PlusCircle, Trash2, CheckCircle2, Shield } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface PaymentMethod {
  id: string
  card: {
    brand: string
    last4: string
    exp_month: number
    exp_year: number
  }
  billing_details: {
    name: string
  }
}

interface PaymentMethodsManagerProps {
  customerId: string
  defaultPaymentMethodId?: string
}

export function PaymentMethodsManager({ customerId, defaultPaymentMethodId }: PaymentMethodsManagerProps) {
  const stripe = useStripe()
  const elements = useElements()
  const { toast } = useToast()
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddingCard, setIsAddingCard] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [defaultPaymentMethod, setDefaultPaymentMethod] = useState<string | undefined>(defaultPaymentMethodId)

  useEffect(() => {
    if (customerId) {
      fetchPaymentMethods()
    }
  }, [customerId])

  const fetchPaymentMethods = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/stripe?customerId=${customerId}`)
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error?.message || "Failed to fetch payment methods")
      }

      setPaymentMethods(data.paymentMethods)

      // Find default payment method from subscriptions
      if (data.subscriptions && data.subscriptions.length > 0) {
        const subscription = data.subscriptions[0]
        if (subscription.default_payment_method) {
          setDefaultPaymentMethod(subscription.default_payment_method)
        }
      }
    } catch (error) {
      console.error("Error fetching payment methods:", error)
      toast({
        title: "Error",
        description: "Failed to load payment methods",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddCard = async (event: React.FormEvent) => {
    event.preventDefault()

    if (!stripe || !elements) {
      return
    }

    const cardElement = elements.getElement(CardElement)

    if (!cardElement) {
      setErrorMessage("Card element not found")
      return
    }

    setIsProcessing(true)
    setErrorMessage(null)

    try {
      // Create payment method
      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: "card",
        card: cardElement,
      })

      if (error) {
        throw new Error(error.message)
      }

      // Attach payment method to customer
      const response = await fetch("/api/stripe/payment-methods", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          customerId,
          paymentMethodId: paymentMethod.id,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error?.message || "Failed to add payment method")
      }

      toast({
        title: "Success",
        description: "Payment method added successfully",
      })

      setIsAddingCard(false)
      fetchPaymentMethods()
    } catch (error: any) {
      console.error("Error adding payment method:", error)
      setErrorMessage(error.message || "An error occurred while adding your card")
    } finally {
      setIsProcessing(false)
    }
  }

  const handleRemoveCard = async (paymentMethodId: string) => {
    try {
      const response = await fetch(`/api/stripe/payment-methods?paymentMethodId=${paymentMethodId}`, {
        method: "DELETE",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error?.message || "Failed to remove payment method")
      }

      toast({
        title: "Success",
        description: "Payment method removed successfully",
      })

      fetchPaymentMethods()
    } catch (error: any) {
      console.error("Error removing payment method:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to remove payment method",
        variant: "destructive",
      })
    }
  }

  const handleSetDefaultCard = async (paymentMethodId: string) => {
    try {
      const response = await fetch("/api/stripe/payment-methods", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          customerId,
          paymentMethodId,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error?.message || "Failed to set default payment method")
      }

      setDefaultPaymentMethod(paymentMethodId)
      toast({
        title: "Success",
        description: "Default payment method updated",
      })
    } catch (error: any) {
      console.error("Error setting default payment method:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to update default payment method",
        variant: "destructive",
      })
    }
  }

  const formatCardBrand = (brand: string) => {
    return brand.charAt(0).toUpperCase() + brand.slice(1)
  }

  return (
    <Card className="bg-gray-800/50 border-gray-700">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="space-y-1">
          <CardTitle className="text-white">Payment Methods</CardTitle>
          <CardDescription className="text-gray-400">
            Manage your payment methods and billing information
          </CardDescription>
        </div>
        <Button onClick={() => setIsAddingCard(true)} className="bg-stone-400 hover:bg-stone-500 text-black">
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Payment Method
        </Button>
      </CardHeader>
      <CardContent className="pt-6">
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="h-20 bg-gray-700/30 animate-pulse rounded-lg"></div>
            ))}
          </div>
        ) : paymentMethods.length === 0 ? (
          <div className="text-center py-8">
            <CreditCard className="h-12 w-12 mx-auto text-gray-500 mb-3" />
            <h3 className="text-white font-medium mb-1">No payment methods</h3>
            <p className="text-gray-400 text-sm">Add a payment method to manage your subscriptions</p>
          </div>
        ) : (
          <div className="space-y-4">
            {paymentMethods.map((method) => (
              <div
                key={method.id}
                className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-gray-700/30 rounded-lg p-4 border border-gray-700"
              >
                <div className="flex items-center gap-3">
                  <div className="h-10 w-16 rounded bg-gray-600 flex items-center justify-center text-white text-xs">
                    {method.card.brand.toUpperCase()}
                  </div>
                  <div>
                    <div className="font-medium text-white flex items-center">
                      {formatCardBrand(method.card.brand)} •••• {method.card.last4}
                      {method.id === defaultPaymentMethod && (
                        <Badge className="ml-2 bg-stone-400 text-black">Default</Badge>
                      )}
                    </div>
                    <div className="text-sm text-gray-400">
                      Expires {method.card.exp_month}/{method.card.exp_year}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {method.id !== defaultPaymentMethod && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSetDefaultCard(method.id)}
                      className="text-white border-gray-600 hover:bg-gray-700 hover:text-white sm:w-auto w-full"
                    >
                      <CheckCircle2 className="mr-2 h-4 w-4" />
                      Set as Default
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleRemoveCard(method.id)}
                    className="text-rose-400 border-gray-600 hover:bg-rose-500/10 hover:text-rose-400 sm:w-auto w-full"
                    disabled={method.id === defaultPaymentMethod}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      <Dialog open={isAddingCard} onOpenChange={setIsAddingCard}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Add Payment Method</DialogTitle>
            <DialogDescription className="text-gray-400">
              Enter your card details to add a new payment method
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAddCard}>
            {errorMessage && (
              <Alert variant="destructive" className="bg-red-900/20 border-red-600">
                <AlertDescription>{errorMessage}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label htmlFor="card-element" className="block text-sm font-medium text-white">
                  Card Details
                </label>
                <div className="bg-gray-700/50 border border-gray-600 rounded-md p-3">
                  <CardElement
                    id="card-element"
                    options={{
                      style: {
                        base: {
                          fontSize: "16px",
                          color: "#ffffff",
                          "::placeholder": {
                            color: "#9ca3af",
                          },
                        },
                        invalid: {
                          color: "#ef4444",
                        },
                      },
                    }}
                  />
                </div>
              </div>

              <div className="flex items-center p-4 bg-gray-700/20 rounded-lg text-sm">
                <Shield className="h-5 w-5 text-stone-400 mr-3 shrink-0" />
                <p className="text-gray-400">
                  Your payment information is encrypted and secure. We use industry-standard security measures to
                  protect your data.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsAddingCard(false)}
                className="border-gray-600 text-white hover:bg-gray-700"
                disabled={isProcessing}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-stone-400 hover:bg-stone-500 text-black"
                disabled={isProcessing || !stripe}
              >
                {isProcessing ? (
                  <>
                    <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                    Processing...
                  </>
                ) : (
                  "Add Card"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
