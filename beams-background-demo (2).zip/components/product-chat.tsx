"use client"

import { useState, useRef, useEffect } from "react"
import type React from "react"
import { X, Send, Phone } from "lucide-react"

interface ProductChatProps {
  productId: string
  productName?: string
  action?: "buy" | "sell"
  onClose: () => void
}

export default function ProductChat({
  productId,
  productName = "Luxury Watch",
  action = "buy",
  onClose,
}: ProductChatProps) {
  const [messages, setMessages] = useState<
    { text: string; isUser: boolean; timestamp?: Date; sender?: string; status?: string }[]
  >([])
  const [inputMessage, setInputMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const [emailAddress, setEmailAddress] = useState("")
  const [chatAction, setChatAction] = useState<"buy" | "sell">("buy")
  const [showCallPrompt, setShowCallPrompt] = useState(false)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping, showCallPrompt])

  // Auto-resize textarea to fit content
  useEffect(() => {
    const textarea = inputRef.current
    if (textarea) {
      // Reset height to auto to get the correct scrollHeight
      textarea.style.height = "auto"
      // Set the height to match the content
      textarea.style.height = `${textarea.scrollHeight}px`

      // iOS Safari specific fix: prevent zoom on focus
      textarea.style.fontSize = "16px"
    }
  }, [inputMessage])

  // Initialize with welcome message
  useEffect(() => {
    setMessages([]) // Initialize with empty messages array

    // Pre-populate the message field
    setInputMessage(
      `I'm ready to sell my ${productName}. Can you help with that?

(https://realtimejewelry.com/product/${productId})`,
    )

    // Focus input when chat opens
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus()
      }
    }, 100)

    // Show call prompt after 2 seconds
    setTimeout(() => {
      setShowCallPrompt(true)
    }, 2000)
  }, [productId, productName])

  // Bot responses
  const botResponses = [
    "Thank you for your message! How can I assist you further?",
    "I understand. Is there anything specific you'd like to know about this watch?",
    "That's interesting. Would you like to schedule a viewing of this timepiece?",
    "I'm here to help! Let me know if you have any questions about the specifications.",
    "Thanks for reaching out. This model is currently in stock and available for purchase.",
    "I appreciate your question. This watch comes with a full set including box and papers.",
    "Great! Would you like information about our financing options?",
    "I see. Would you prefer to visit our showroom or proceed with an online purchase?",
    "This particular model has been serviced recently and is in excellent condition.",
  ]

  const sendMessage = () => {
    if (inputMessage.trim()) {
      // Add user message
      setMessages([
        ...messages,
        { text: inputMessage, isUser: true, timestamp: new Date(), sender: "user", status: "sent" },
      ])
      setInputMessage("")

      // Show typing indicator
      setIsTyping(true)

      // Simulate bot response after a delay
      setTimeout(
        () => {
          setIsTyping(false)
          setMessages((prev) => [
            ...prev,
            {
              text: botResponses[Math.floor(Math.random() * botResponses.length)],
              isUser: false,
              timestamp: new Date(),
              sender: "bot",
              status: "received",
            },
          ])
        },
        1000 + Math.random() * 1000,
      ) // Random delay between 1-2 seconds
    }
  }

  // Add iOS Safari specific handling for the chat input
  const handleFocus = () => {
    // iOS Safari: scroll the page after a short delay to ensure the input is visible
    setTimeout(() => {
      if (inputRef.current) {
        // Scroll the element into view with a small offset to account for the keyboard
        window.scrollTo(0, window.scrollY + 100)
      }
    }, 300)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const formatTime = (date: Date) => {
    const hours = date.getHours().toString().padStart(2, "0")
    const minutes = date.getMinutes().toString().padStart(2, "0")
    return `${hours}:${minutes}`
  }

  const getStatusIcon = (status: string) => {
    if (status === "sent") {
      return <span className="text-green-500">✓</span>
    } else if (status === "received") {
      return <span className="text-blue-500">✓</span>
    }
    return null
  }

  // Function to determine message container width based on content length
  const getMessageWidth = (text: string) => {
    const length = text.length
    if (length > 100) return "max-w-[95%]"
    if (length > 50) return "max-w-[85%]"
    return "max-w-[75%]"
  }

  return (
    <div
      className="fixed bottom-4 left-4 right-4 bg-black/15 backdrop-blur-md rounded-lg shadow-[0_8px_32px_rgba(255,255,255,0.05)] z-50 overflow-hidden ios-safe-bottom"
      style={{
        WebkitTransform: "translateZ(0)",
        transform: "translateZ(0)",
        WebkitBackfaceVisibility: "hidden",
        backfaceVisibility: "hidden",
        WebkitPerspective: 1000,
        perspective: 1000,
        maxHeight: "calc(100vh - 2rem)",
        borderWidth: "0.5px",
        borderColor: "rgba(255, 255, 255, 0.03)",
        boxShadow: "0 10px 30px rgba(0, 0, 0, 0.15), inset 0 1px 0 0 rgba(255, 255, 255, 0.03)",
      }}
    >
      <div className="flex items-center justify-between p-3 border-b border-white/10 bg-black/30 backdrop-blur-md relative">
        <h3 className="font-medium text-white">Real Time</h3>
        <button onClick={onClose} className="text-white/70 hover:text-white">
          <X className="h-5 w-5" />
        </button>
      </div>

      <div
        className="h-80 overflow-y-auto bg-black/80 p-4"
        style={{
          boxShadow: "inset 0 1px 3px rgba(0, 0, 0, 0.1)",
        }}
      >
        {messages.map((msg, index) => (
          <div key={index} className={`${msg.isUser ? "flex justify-end" : "flex justify-start"} mb-3 max-w-full`}>
            <div
              className={`${
                msg.isUser ? "bg-green-500/30" : "bg-gray-300/50"
              } rounded-lg p-3 ${getMessageWidth(msg.text)} shadow-sm`}
            >
              <p
                className={`whitespace-pre-wrap text-xs w-full overflow-visible break-words ${msg.isUser ? "text-white" : "text-gray-800"}`}
              >
                {msg.text}
              </p>
              <div
                className={`flex items-center ${msg.isUser ? "justify-end" : "justify-start"} text-xs mt-1 space-x-1 ${msg.isUser ? "text-green-100" : "text-gray-600"}`}
              >
                <span>{msg.timestamp ? formatTime(msg.timestamp) : ""}</span>
                {msg.sender === "user" && getStatusIcon(msg.status || "")}
              </div>
            </div>
          </div>
        ))}

        {showCallPrompt && (
          <div className="flex justify-center my-4" style={{ marginTop: "-5%" }}>
            <div
              className="backdrop-blur-md bg-white/10 rounded-full p-2 max-w-[80%] text-center border border-white/20"
              style={{
                boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1), inset 0 1px 1px rgba(255, 255, 255, 0.1)",
              }}
            >
              <div className="flex items-center justify-center gap-2 mb-1">
                <Phone className="h-4 w-4 text-white/90" />
                <p className="text-white/90 font-medium text-xs tracking-wide uppercase">For faster reply</p>
              </div>
              <a
                href="tel:3057663058"
                className="text-white font-bold text-base hover:text-white hover:underline transition-colors"
              >
                Call (305) 766-3058
              </a>
            </div>
          </div>
        )}

        {isTyping && (
          <div className="flex justify-start mb-3">
            <div className="bg-gray-300/50 rounded-lg p-3 max-w-[75%] shadow-sm">
              <div className="flex space-x-2">
                <div
                  className="w-2 h-2 rounded-full bg-gray-600 animate-bounce"
                  style={{ animationDelay: "0ms" }}
                ></div>
                <div
                  className="w-2 h-2 rounded-full bg-gray-600 animate-bounce"
                  style={{ animationDelay: "200ms" }}
                ></div>
                <div
                  className="w-2 h-2 rounded-full bg-gray-600 animate-bounce"
                  style={{ animationDelay: "400ms" }}
                ></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="border-t border-white/10 p-3 bg-black/70 backdrop-blur-md">
        <input
          type="email"
          placeholder="email@example.com"
          value={emailAddress}
          onChange={(e) => setEmailAddress(e.target.value)}
          className="w-full mb-2 p-2 bg-black/40 text-white text-sm focus:outline-none focus:ring-0 placeholder:text-white/50"
        />

        <div className="relative">
          <textarea
            ref={inputRef}
            value={inputMessage}
            onChange={(e) => {
              setInputMessage(e.target.value)
              // Immediately adjust height when text changes
              const textarea = e.target as HTMLTextAreaElement
              textarea.style.height = "auto"
              textarea.style.height = `${textarea.scrollHeight}px`
            }}
            onFocus={handleFocus}
            onKeyDown={handleKeyPress}
            placeholder="Type your message..."
            className="w-full resize-none bg-black/40 py-2 px-4 pr-10 text-white text-sm focus:outline-none focus:ring-0 placeholder:text-white/50 overflow-hidden transition-all duration-200"
            style={{
              minHeight: "40px",
              maxHeight: "120px",
              height: "auto",
              fontSize: "16px", // Prevent iOS zoom on focus
              WebkitAppearance: "none", // Remove iOS default styling
              WebkitOverflowScrolling: "touch", // Improve iOS scrolling
              borderRadius: "4px",
              border: "1px solid rgba(255, 255, 255, 0.1)",
            }}
          />

          <button
            className="absolute right-2 bottom-2 text-white p-1.5 bg-black/30 rounded-full hover:bg-black/40 transition-colors"
            onClick={sendMessage}
            style={{
              minWidth: "32px",
              minHeight: "32px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
