"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"

interface Comment {
  id: string
  productId: string
  author: string
  authorInitials: string
  authorAvatar?: string
  content: string
  createdAt: string
  likes: number
}

export function ProductComments({ productId }: { productId: string }) {
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadComments = async () => {
      try {
        setIsLoading(true)
        setError(null)
        //Simulate API call delay
        await new Promise((resolve) => setTimeout(resolve, 1200))

        //Mock data for comments
        const mockComments: Record<string, Comment[]> = {
          "1": [
            {
              id: "c1",
              productId: "1",
              author: "James Wilson",
              authorInitials: "JW",
              content:
                "The GMT-Master II is truly a masterpiece. I've owned mine for 3 years and it still looks brand new. The blue and black bezel is stunning in person.",
              createdAt: "2023-09-15T14:23:00Z",
              likes: 12,
            },
            {
              id: "c2",
              productId: "1",
              author: "Sarah Chen",
              authorInitials: "SC",
              authorAvatar: "/mystical-forest-spirit.png",
              content:
                "I've been saving up for this watch for years. Finally pulled the trigger last month. Worth every penny! The craftsmanship is unmatched.",
              createdAt: "2023-10-02T09:45:00Z",
              likes: 8,
            },
            {
              id: "c3",
              productId: "1",
              author: "Michael Rodriguez",
              authorInitials: "MR",
              content:
                "Does anyone know if this comes with the original box and papers? Looking to add this to my collection.",
              createdAt: "2023-10-10T16:30:00Z",
              likes: 3,
            },
          ],
          "2": [
            {
              id: "c4",
              productId: "2",
              author: "Emma Thompson",
              authorInitials: "ET",
              content: "The Royal Oak Offshore is a statement piece. I get compliments every time I wear it.",
              createdAt: "2023-09-20T11:15:00Z",
              likes: 7,
            },
            {
              id: "c5",
              productId: "2",
              author: "David Park",
              authorInitials: "DP",
              authorAvatar: "/confident-coder.png",
              content: "I'm torn between this and the Patek Philippe Nautilus. Any thoughts from owners?",
              createdAt: "2023-10-05T13:20:00Z",
              likes: 5,
            },
          ],
        }

        setComments(mockComments[productId] || [])
      } catch (err) {
        console.error("Failed to load comments:", err)
        setError("Failed to load comments. Please try again later.")
      } finally {
        setIsLoading(false)
      }
    }

    loadComments()
  }, [productId])

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim()) return

    try {
      setIsSubmitting(true)
      setError(null)

      //Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 800))

      const newCommentObj = {
        id: `c${Date.now()}`,
        productId,
        author: "You",
        authorInitials: "YO",
        content: newComment,
        createdAt: new Date().toISOString(),
        likes: 0,
      }

      setComments((prev) => [newCommentObj, ...prev])
      setNewComment("")
    } catch (err) {
      console.error("Failed to post comment:", err)
      setError("Failed to post your comment. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(date)
  }

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-white">Comments</h2>

      <form onSubmit={handleSubmitComment} className="space-y-4">
        <Textarea
          placeholder="Share your thoughts about this watch..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          className="min-h-[100px] bg-black/30 border-white/10 text-white placeholder:text-white/50"
        />
        <div className="flex justify-end">
          <Button
            type="submit"
            disabled={isSubmitting || !newComment.trim()}
            className="rounded-full bg-white text-black hover:bg-white/90"
          >
            {isSubmitting ? "Posting..." : "Post Comment"}
          </Button>
        </div>
      </form>

      {error && <div className="p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-white">{error}</div>}

      <div className="space-y-6">
        {isLoading ? (
          // Skeleton loading state
          Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="flex gap-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-4 w-[200px]" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-[70%]" />
              </div>
            </div>
          ))
        ) : comments.length === 0 ? (
          <div className="text-center py-8 text-white/60">Be the first to comment on this product.</div>
        ) : (
          comments.map((comment) => (
            <div key={comment.id} className="flex gap-4">
              <Avatar>
                {comment.authorAvatar ? (
                  <AvatarImage src={comment.authorAvatar || "/placeholder.svg"} alt={comment.author} />
                ) : null}
                <AvatarFallback className="bg-white/10 text-white">{comment.authorInitials}</AvatarFallback>
              </Avatar>
              <div className="space-y-1 flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-white">{comment.author}</h3>
                  <span className="text-xs text-white/60">{formatDate(comment.createdAt)}</span>
                </div>
                <p className="text-white/80 text-sm whitespace-pre-wrap">{comment.content}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
