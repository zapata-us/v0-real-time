"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Save, X, Upload, Trash2, Eye, AlertCircle, Info, ImageIcon, Rocket, FileCheck2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/hooks/use-toast"
import type { ProductType } from "@/types/product"
import { saveProduct, fetchProductById, fetchDraftProductById, publishDraft } from "@/lib/product-service"
import { ProductPreview } from "@/components/product-preview"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface ProductFormProps {
  productId?: string
  isEditMode?: boolean
}

export function ProductForm({ productId, isEditMode = false }: ProductFormProps) {
  const router = useRouter()
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("details")
  const [isLoading, setIsLoading] = useState(isEditMode)
  const [isSaving, setIsSaving] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [isTestMode, setIsTestMode] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [hasDraft, setHasDraft] = useState(false)

  const [product, setProduct] = useState<ProductType>({
    id: "",
    name: "",
    brand: "",
    price: 0,
    description: "",
    features: [],
    image: "",
    reference: "",
    caseSize: "",
    caseMaterial: "",
    dialColor: "",
    bracelet: "",
  })

  useEffect(() => {
    if (isEditMode && productId) {
      loadProduct(productId)
      // Also check if there's a draft version
      checkForDraft(productId)
    }
  }, [isEditMode, productId])

  const checkForDraft = async (id: string) => {
    try {
      const draft = await fetchDraftProductById(id)
      setHasDraft(!!draft)
    } catch (error) {
      console.error("Error checking for draft:", error)
    }
  }

  const loadProduct = async (id: string) => {
    setIsLoading(true)
    try {
      const data = await fetchProductById(id)
      // Ensure all fields have defined values to prevent uncontrolled to controlled input errors
      const normalizedData = {
        ...data,
        reference: data.reference || "",
        caseSize: data.caseSize || "",
        caseMaterial: data.caseMaterial || "",
        dialColor: data.dialColor || "",
        bracelet: data.bracelet || "",
      }

      setProduct(normalizedData)
      if (data.image) {
        setImagePreview(data.image)
      }
    } catch (error) {
      toast({
        title: "Error loading product",
        description: "There was a problem loading the product details. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProduct((prev) => ({ ...prev, [name]: value }))

    // Clear error when field is edited
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }
  }

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Allow digits, commas, periods, and backspace
    const value = e.target.value.replace(/[^\d.,]/g, "")

    // Convert to number for storage, handling commas properly
    const numericValue = Number.parseFloat(value.replace(/,/g, "")) || 0

    setProduct((prev) => ({ ...prev, price: numericValue }))

    if (errors.price) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors.price
        return newErrors
      })
    }
  }

  const handleSelectChange = (name: string, value: string) => {
    setProduct((prev) => ({ ...prev, [name]: value }))

    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[name]
        return newErrors
      })
    }
  }

  const handleFeaturesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const featuresText = e.target.value
    const featuresArray = featuresText
      .split("\n")
      .map((feature) => feature.trim())
      .filter((feature) => feature.length > 0)

    setProduct((prev) => ({ ...prev, features: featuresArray }))
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check file type
    if (!file.type.startsWith("image/")) {
      setErrors((prev) => ({ ...prev, image: "Please upload an image file" }))
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setErrors((prev) => ({ ...prev, image: "Image size should be less than 5MB" }))
      return
    }

    // Create a preview
    const reader = new FileReader()
    reader.onload = (event) => {
      setImagePreview(event.target?.result as string)
    }
    reader.readAsDataURL(file)

    // In a real app, you would upload the file to a storage service
    // and set the returned URL to the product.image field
    // For this example, we'll just use the preview as the image URL
    setProduct((prev) => ({ ...prev, image: URL.createObjectURL(file) }))

    if (errors.image) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors.image
        return newErrors
      })
    }
  }

  const removeImage = () => {
    setImagePreview(null)
    setProduct((prev) => ({ ...prev, image: "" }))
  }

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!product.name.trim()) {
      newErrors.name = "Product name is required"
    }

    if (!product.brand.trim()) {
      newErrors.brand = "Brand is required"
    }

    if (product.price <= 0) {
      newErrors.price = "Price must be greater than 0"
    }

    if (!product.reference.trim()) {
      newErrors.reference = "Reference is required"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const saveAsDraft = async () => {
    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors in the form before saving as draft.",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)
    try {
      await saveProduct(product, true)

      toast({
        title: "Draft Saved",
        description: "Your changes have been saved as a draft. They won't be visible to users until published.",
      })

      setHasDraft(true)
    } catch (error) {
      toast({
        title: "Error Saving Draft",
        description: "There was a problem saving the draft. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handlePublishDraft = async () => {
    if (!product.id) return

    setIsSaving(true)
    try {
      const publishedProduct = await publishDraft(product.id)

      toast({
        title: "Changes Published",
        description: "Your changes have been published and are now visible to all users.",
      })

      setHasDraft(false)
      router.push(`/product/${publishedProduct.id}`)
    } catch (error) {
      toast({
        title: "Error Publishing Changes",
        description: "There was a problem publishing your changes. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors in the form before submitting.",
        variant: "destructive",
      })
      return
    }

    // Set the source field to indicate this is a manually entered product
    const productToSave = {
      ...product,
      source: "manual" as const,
    }

    setIsSaving(true)
    try {
      // If in test mode, save as draft
      if (isTestMode) {
        await saveProduct(productToSave, true)
        toast({
          title: "Test Version Saved",
          description: "Your changes have been saved for testing. They won't be visible to users until published.",
        })
        setHasDraft(true)
      } else {
        // Otherwise save as published
        const savedProduct = await saveProduct(productToSave, false)
        toast({
          title: isEditMode ? "Product Updated" : "Product Created",
          description: isEditMode
            ? "The product has been successfully updated and is now visible to all users."
            : "The product has been successfully created and is now visible to all users.",
        })
        router.push(`/product/${savedProduct.id}`)
      }
    } catch (error) {
      toast({
        title: "Error Saving Product",
        description: "There was a problem saving the product. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const previewProduct = () => {
    setShowPreview(true)
  }

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-white border-r-transparent"></div>
        <p className="mt-4 text-white/70">Loading product details...</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex flex-col items-end gap-2">
        <h1 className="text-2xl font-bold text-white self-start mb-4">
          {isEditMode ? "Edit Product" : "Add New Product"}
        </h1>
        <div className="flex items-center mb-4">
          <Switch id="test-mode" checked={isTestMode} onCheckedChange={setIsTestMode} className="mr-2" />
          <Label htmlFor="test-mode" className="text-white cursor-pointer">
            Test Mode{" "}
            {isTestMode && <span className="text-xs text-blue-400 ml-2">(Changes won't go live until published)</span>}
          </Label>
        </div>
        <div className="flex gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => router.push("/admin/products")}
            className="border-white/20 text-white hover:bg-white/10"
          >
            <X className="mr-2 h-4 w-4" />
            Cancel
          </Button>

          <Button
            type="button"
            variant="outline"
            onClick={previewProduct}
            className="border-white/20 text-white hover:bg-white/10"
          >
            <Eye className="mr-2 h-4 w-4" />
            Preview
          </Button>

          {isTestMode && (
            <Button
              type="button"
              onClick={saveAsDraft}
              disabled={isSaving}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <FileCheck2 className="mr-2 h-4 w-4" />
              Save Draft
            </Button>
          )}

          {hasDraft && (
            <Button
              type="button"
              onClick={handlePublishDraft}
              disabled={isSaving}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Rocket className="mr-2 h-4 w-4" />
              Publish Changes
            </Button>
          )}

          <Button
            type="submit"
            disabled={isSaving}
            className={
              isTestMode ? "bg-blue-600 hover:bg-blue-700 text-white" : "bg-white text-black hover:bg-white/90"
            }
          >
            {isSaving ? (
              <>
                <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-solid border-current border-r-transparent"></div>
                {isTestMode ? "Saving..." : "Publishing..."}
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                {isTestMode ? "Save for Testing" : "Save & Publish"}
              </>
            )}
          </Button>
        </div>
      </div>

      {Object.keys(errors).length > 0 && (
        <Alert variant="destructive" className="bg-red-900/20 border-red-600 text-white">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Validation Errors</AlertTitle>
          <AlertDescription>Please fix the following errors before submitting the form.</AlertDescription>
        </Alert>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-black/20 border border-white/10">
          <TabsTrigger
            value="details"
            className="data-[state=active]:bg-white data-[state=active]:text-black text-white"
          >
            Basic Details
          </TabsTrigger>
          <TabsTrigger
            value="description"
            className="data-[state=active]:bg-white data-[state=active]:text-black text-white"
          >
            Features
          </TabsTrigger>
          <TabsTrigger
            value="images"
            className="data-[state=active]:bg-white data-[state=active]:text-black text-white"
          >
            Images
          </TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="mt-6">
          <Card className="bg-black/20 border-white/10 text-white">
            <CardHeader>
              <CardTitle>Basic Details</CardTitle>
              <CardDescription className="text-white/70">
                Enter the basic information about the product.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className={errors.name ? "text-red-400" : ""}>
                  Product Name *
                </Label>
                <Input
                  id="name"
                  name="name"
                  value={product.name}
                  onChange={handleInputChange}
                  placeholder="Enter product name"
                  className={`bg-black/20 border-${errors.name ? "red-400" : "white/20"} text-white placeholder:text-white/50`}
                />
                {errors.name && <p className="text-sm text-red-400">{errors.name}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="brand" className={errors.brand ? "text-red-400" : ""}>
                  Brand *
                </Label>
                <Select
                  name="brand"
                  value={product.brand}
                  onValueChange={(value) => handleSelectChange("brand", value)}
                >
                  <SelectTrigger
                    id="brand"
                    className={`bg-black/20 border-${errors.brand ? "red-400" : "white/20"} text-white placeholder:text-white/50`}
                  >
                    <SelectValue placeholder="Select a brand" />
                  </SelectTrigger>
                  <SelectContent className="bg-black/90 border-white/20 text-white">
                    <SelectItem value="Rolex">Rolex</SelectItem>
                    <SelectItem value="Cartier">Cartier</SelectItem>
                    <SelectItem value="Audemars Piguet">Audemars Piguet</SelectItem>
                    <SelectItem value="Hublot">Hublot</SelectItem>
                    <SelectItem value="Omega">Omega</SelectItem>
                    <SelectItem value="Patek Philippe">Patek Philippe</SelectItem>
                    <SelectItem value="Vacheron Constantin">Vacheron Constantin</SelectItem>
                    <SelectItem value="Jaeger-LeCoultre">Jaeger-LeCoultre</SelectItem>
                    <SelectItem value="Breguet">Breguet</SelectItem>
                    <SelectItem value="Blancpain">Blancpain</SelectItem>
                    <SelectItem value="IWC">IWC</SelectItem>
                    <SelectItem value="Richard Mille">Richard Mille</SelectItem>
                    <SelectItem value="A. Lange & Söhne">A. Lange & Söhne</SelectItem>
                    <SelectItem value="Piaget">Piaget</SelectItem>
                    <SelectItem value="Franck Muller">Franck Muller</SelectItem>
                  </SelectContent>
                </Select>
                {errors.brand && <p className="text-sm text-red-400">{errors.brand}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="reference" className={errors.reference ? "text-red-400" : ""}>
                  Reference *
                </Label>
                <Input
                  id="reference"
                  name="reference"
                  value={product.reference}
                  onChange={handleInputChange}
                  placeholder="Enter reference number"
                  className={`bg-black/20 border-${errors.reference ? "red-400" : "white/20"} text-white placeholder:text-white/50`}
                />
                {errors.reference && <p className="text-sm text-red-400">{errors.reference}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="caseSize">Case Size</Label>
                  <Select
                    name="caseSize"
                    value={product.caseSize}
                    onValueChange={(value) => handleSelectChange("caseSize", value)}
                  >
                    <SelectTrigger
                      id="caseSize"
                      className="bg-black/20 border-white/20 text-white placeholder:text-white/50"
                    >
                      <SelectValue placeholder="Select case size" />
                    </SelectTrigger>
                    <SelectContent className="bg-black/90 border-white/20 text-white">
                      {/* Men's Watch Sizes */}
                      <SelectItem value="men-header" disabled className="font-bold text-white/70">
                        Men's Watch Sizes
                      </SelectItem>
                      <SelectItem value="34mm">Small - 34mm</SelectItem>
                      <SelectItem value="35mm">Small - 35mm</SelectItem>
                      <SelectItem value="36mm">Small - 36mm</SelectItem>
                      <SelectItem value="37mm">Small - 37mm</SelectItem>
                      <SelectItem value="38mm">Small - 38mm</SelectItem>
                      <SelectItem value="39mm">Medium - 39mm</SelectItem>
                      <SelectItem value="40mm">Medium - 40mm</SelectItem>
                      <SelectItem value="41mm">Medium - 41mm</SelectItem>
                      <SelectItem value="42mm">Medium - 42mm</SelectItem>
                      <SelectItem value="43mm">Large - 43mm</SelectItem>
                      <SelectItem value="44mm">Large - 44mm</SelectItem>
                      <SelectItem value="45mm">Large - 45mm</SelectItem>
                      <SelectItem value="46mm">Large - 46mm</SelectItem>
                      <SelectItem value="47mm">Extra Large - 47mm</SelectItem>
                      <SelectItem value="48mm">Extra Large - 48mm</SelectItem>
                      <SelectItem value="49mm">Extra Large - 49mm</SelectItem>
                      <SelectItem value="50mm+">Extra Large - 50mm+</SelectItem>

                      {/* Women's Watch Sizes */}
                      <SelectItem value="women-header" disabled className="font-bold text-white/70 mt-2">
                        Women's Watch Sizes
                      </SelectItem>
                      <SelectItem value="26mm">Petite - 26mm</SelectItem>
                      <SelectItem value="27mm">Petite - 27mm</SelectItem>
                      <SelectItem value="28mm">Petite - 28mm</SelectItem>
                      <SelectItem value="29mm">Petite - 29mm</SelectItem>
                      <SelectItem value="30mm">Petite - 30mm</SelectItem>
                      <SelectItem value="31mm">Standard - 31mm</SelectItem>
                      <SelectItem value="32mm">Standard - 32mm</SelectItem>
                      <SelectItem value="33mm">Standard - 33mm</SelectItem>
                      <SelectItem value="34mm-women">Standard - 34mm</SelectItem>
                      <SelectItem value="35mm-women">Standard - 35mm</SelectItem>
                      <SelectItem value="36mm-women">Standard - 36mm</SelectItem>
                      <SelectItem value="37mm-women">Oversized - 37mm</SelectItem>
                      <SelectItem value="38mm-women">Oversized - 38mm</SelectItem>
                      <SelectItem value="39mm-women">Oversized - 39mm</SelectItem>
                      <SelectItem value="40mm-women">Oversized - 40mm</SelectItem>
                      <SelectItem value="41mm-women">Oversized - 41mm</SelectItem>
                      <SelectItem value="42mm-women">Oversized - 42mm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="caseMaterial">Case Material</Label>
                  <Select
                    name="caseMaterial"
                    value={product.caseMaterial}
                    onValueChange={(value) => handleSelectChange("caseMaterial", value)}
                  >
                    <SelectTrigger
                      id="caseMaterial"
                      className="bg-black/20 border-white/20 text-white placeholder:text-white/50"
                    >
                      <SelectValue placeholder="Select case material" />
                    </SelectTrigger>
                    <SelectContent className="bg-black/90 border-white/20 text-white">
                      <SelectItem value="Stainless Steel">Stainless Steel</SelectItem>
                      <SelectItem value="Yellow Gold">Yellow Gold</SelectItem>
                      <SelectItem value="White Gold">White Gold</SelectItem>
                      <SelectItem value="Rose Gold">Rose Gold</SelectItem>
                      <SelectItem value="Platinum">Platinum</SelectItem>
                      <SelectItem value="Titanium">Titanium</SelectItem>
                      <SelectItem value="Ceramic">Ceramic</SelectItem>
                      <SelectItem value="Carbon Fiber">Carbon Fiber</SelectItem>
                      <SelectItem value="Bronze">Bronze</SelectItem>
                      <SelectItem value="PVD Coated Steel">PVD Coated Steel</SelectItem>
                      <SelectItem value="Resin">Resin</SelectItem>
                      <SelectItem value="Plastic">Plastic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dialColor">Dial Color</Label>
                  <Input
                    id="dialColor"
                    name="dialColor"
                    value={product.dialColor}
                    onChange={handleInputChange}
                    placeholder="e.g., Black"
                    className="bg-black/20 border-white/20 text-white placeholder:text-white/50"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bracelet">Bracelet / Strap</Label>
                  <Select
                    name="bracelet"
                    value={product.bracelet}
                    onValueChange={(value) => handleSelectChange("bracelet", value)}
                  >
                    <SelectTrigger
                      id="bracelet"
                      className="bg-black/20 border-white/20 text-white placeholder:text-white/50"
                    >
                      <SelectValue placeholder="Select bracelet/strap" />
                    </SelectTrigger>
                    <SelectContent className="bg-black/90 border-white/20 text-white">
                      <SelectItem value="Stainless Steel">Stainless Steel</SelectItem>
                      <SelectItem value="Oystersteel">Oystersteel</SelectItem>
                      <SelectItem value="Oysterflex">Oysterflex</SelectItem>
                      <SelectItem value="Jubilee">Jubilee</SelectItem>
                      <SelectItem value="President">President</SelectItem>
                      <SelectItem value="Leather Strap">Leather Strap</SelectItem>
                      <SelectItem value="Rubber Strap">Rubber Strap</SelectItem>
                      <SelectItem value="Yellow Gold">Yellow Gold</SelectItem>
                      <SelectItem value="White Gold">White Gold</SelectItem>
                      <SelectItem value="Rose Gold">Rose Gold</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="price" className={errors.price ? "text-red-400" : ""}>
                  Estimated Market Value ($) *
                </Label>
                <Input
                  id="price"
                  name="price"
                  type="text"
                  value={product.price === 0 ? "" : product.price.toLocaleString()}
                  onChange={handlePriceChange}
                  placeholder="0.00"
                  className={`bg-black/20 border-${errors.price ? "red-400" : "white/20"} text-white placeholder:text-white/50`}
                />
                {errors.price && <p className="text-sm text-red-400">{errors.price}</p>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="description" className="mt-6">
          <Card className="bg-black/20 border-white/10 text-white">
            <CardHeader>
              <CardTitle>Features</CardTitle>
              <CardDescription className="text-white/70">List the key features of the product.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="features">Features (one per line)</Label>
                <Textarea
                  id="features"
                  name="features"
                  value={product.features.join("\n")}
                  onChange={handleFeaturesChange}
                  placeholder="Enter product features (one per line)"
                  className="min-h-32 bg-black/20 border-white/20 text-white placeholder:text-white/50"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="images" className="mt-6">
          <Card className="bg-black/20 border-white/10 text-white">
            <CardHeader>
              <CardTitle>Product Images</CardTitle>
              <CardDescription className="text-white/70">
                Upload images for the product. The first image will be used as the main product image.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <Label htmlFor="image" className={errors.image ? "text-red-400" : ""}>
                  Main Product Image
                </Label>

                {imagePreview ? (
                  <div className="relative border border-white/20 rounded-lg overflow-hidden">
                    <img
                      src={imagePreview || "/placeholder.svg"}
                      alt="Product preview"
                      className="max-h-64 w-full object-contain"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={removeImage}
                      className="absolute top-2 right-2"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="border border-dashed border-white/20 rounded-lg p-12 text-center">
                    <ImageIcon className="mx-auto h-12 w-12 text-white/50" />
                    <h3 className="mt-4 text-sm font-medium text-white">No image uploaded</h3>
                    <p className="mt-2 text-xs text-white/70">
                      Upload a product image in JPG, PNG or WebP format (max 5MB)
                    </p>
                    <label htmlFor="image" className="mt-4 inline-block">
                      <div className="inline-flex items-center justify-center rounded-md bg-white px-4 py-2 text-sm font-medium text-black hover:bg-white/90 cursor-pointer">
                        <Upload className="mr-2 h-4 w-4" />
                        Upload Image
                      </div>
                      <input id="image" type="file" accept="image/*" onChange={handleImageUpload} className="sr-only" />
                    </label>
                  </div>
                )}

                {errors.image && <p className="text-sm text-red-400">{errors.image}</p>}
              </div>

              <Alert className="bg-blue-900/20 border-blue-600">
                <Info className="h-4 w-4" />
                <AlertTitle>Additional Images</AlertTitle>
                <AlertDescription>
                  In a production environment, you would be able to upload multiple images for the product. For this
                  demo, we're focusing on the main product image only.
                </AlertDescription>
              </Alert>
            </CardContent>
            <CardFooter>
              <div className="text-sm text-white/70 flex items-center">
                <Info className="h-4 w-4 mr-2" />
                Images will be optimized automatically after upload.
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      {showPreview && <ProductPreview product={product} onClose={() => setShowPreview(false)} />}
    </form>
  )
}
