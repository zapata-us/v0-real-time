"use client"

import { useEffect, useRef } from "react"
import { motion, useInView, useAnimation } from "framer-motion"
import { GlassProductCard } from "@/components/glass-product-card"

// Update the watches array to use the new image
const watches = [
  {
    id: "1",
    name: "GMT-Master II 'Batman'",
    brand: "Rolex",
    price: 14950,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
  {
    id: "2",
    name: "Royal Oak Offshore",
    brand: "Audemars Piguet",
    price: 45900,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
  {
    id: "3",
    name: "Submariner Date",
    brand: "Rolex",
    price: 14500,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
  {
    id: "4",
    name: "Speedmaster Moonwatch",
    brand: "Omega",
    price: 7250,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
  {
    id: "5",
    name: "Big Bang Unico",
    brand: "Hublot",
    price: 22900,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
  {
    id: "6",
    name: "Luminor Marina",
    brand: "Panerai",
    price: 8900,
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
  },
]

const ProductItem = ({
  watch,
  index,
  fixedHeight = false,
  noHoverAnimation = false,
}: {
  watch: any
  index: number
  fixedHeight?: boolean
  noHoverAnimation?: boolean
}) => {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, amount: 0.1, margin: "0px 0px -100px 0px" })
  const controls = useAnimation()

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [isInView, controls])

  return (
    <motion.div
      ref={ref}
      variants={{
        hidden: { opacity: 0 },
        visible: { opacity: 1 },
      }}
      initial="hidden"
      animate={controls}
      transition={{
        duration: 0.5,
        delay: index * 0.06,
        ease: [0.25, 0.1, 0.25, 1],
      }}
      whileHover={
        noHoverAnimation
          ? {}
          : {
              y: -10,
              transition: { duration: 0.2, ease: "easeOut" },
            }
      }
      className={`${fixedHeight ? "h-full" : ""} p-2 mb-4 flex flex-col w-full overflow-visible`}
    >
      <GlassProductCard
        id={watch.id}
        name={watch.name}
        brand={watch.brand}
        price={watch.price}
        image={watch.image}
        className={`${fixedHeight ? "h-full" : ""} w-full h-full`}
      />
    </motion.div>
  )
}

interface ProductGridProps {
  twoColumnLayout?: boolean
  fourColumnLayout?: boolean
  fixedHeight?: boolean
  startIndex?: number
  noHoverAnimation?: boolean
  latestOnly?: boolean
  limit?: number
}

// Update the ProductGrid component to handle products passed from the collection page:
export function ProductGrid({
  products,
  twoColumnLayout = false,
  fourColumnLayout = false,
  fixedHeight = false,
  startIndex = 0,
  noHoverAnimation = false,
  latestOnly = false,
  limit,
}: {
  products?: any[]
  twoColumnLayout?: boolean
  fourColumnLayout?: boolean
  fixedHeight?: boolean
  startIndex?: number
  noHoverAnimation?: boolean
  latestOnly?: boolean
  limit?: number
}) {
  // Use provided products or fall back to watches array
  const sourceProducts = products || watches

  // Filter out auto-generated products if no products were provided
  const filteredWatches = products
    ? sourceProducts
    : sourceProducts.filter((watch) => {
        // If we had access to the full product data with source field, we would use that
        // For now, let's assume watches with ID "2" are auto-generated (based on our mock data)
        return watch.id !== "2" // This is a simplified example - in a real app, you'd check the source field
      })

  // Sort watches by newest first if latestOnly is true
  const sortedWatches = latestOnly
    ? [...filteredWatches].sort((a, b) => (b.addedDate || 0) - (a.addedDate || 0))
    : filteredWatches

  // Apply limit if provided
  const limitedWatches = limit ? sortedWatches.slice(0, limit) : sortedWatches

  let displayWatches

  if (fourColumnLayout) {
    displayWatches = limitedWatches.slice(0, 4)
  } else if (twoColumnLayout) {
    displayWatches = limitedWatches.slice(startIndex, startIndex + 2)
  } else {
    displayWatches = limitedWatches
  }

  return (
    <>
      {displayWatches.map((watch, index) => (
        <ProductItem
          key={watch.id}
          watch={watch}
          index={index}
          fixedHeight={fixedHeight}
          noHoverAnimation={noHoverAnimation}
        />
      ))}
    </>
  )
}
