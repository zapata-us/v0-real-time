"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { X, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { ProductType } from "@/types/product"

interface ProductPreviewProps {
  product: ProductType
  onClose: () => void
}

export function ProductPreview({ product, onClose }: ProductPreviewProps) {
  const [isMobile, setIsMobile] = useState(false)

  // Check if we're on mobile for responsive preview
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 overflow-y-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <Button variant="ghost" size="sm" className="text-white mr-2" onClick={onClose}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Editor
            </Button>
            <div className="text-white/50 text-sm">Preview Mode</div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center bg-black/40 rounded-full px-3 py-1">
              <span className={`h-2 w-2 rounded-full ${isMobile ? "bg-blue-500" : "bg-white/30"} mr-2`}></span>
              <button
                className={`text-xs ${isMobile ? "text-blue-500" : "text-white/50"}`}
                onClick={() => setIsMobile(true)}
              >
                Mobile
              </button>
              <span className="mx-2 text-white/30">|</span>
              <span className={`h-2 w-2 rounded-full ${!isMobile ? "bg-blue-500" : "bg-white/30"} mr-2`}></span>
              <button
                className={`text-xs ${!isMobile ? "text-blue-500" : "text-white/50"}`}
                onClick={() => setIsMobile(false)}
              >
                Desktop
              </button>
            </div>

            <Button variant="ghost" size="icon" className="text-white" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div className={`mx-auto ${isMobile ? "max-w-sm" : "max-w-6xl"} bg-black rounded-lg overflow-hidden`}>
          <div className="h-10 bg-black/50 flex items-center px-4 border-b border-white/10">
            <div className="flex space-x-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
            <div className="mx-auto text-white/50 text-xs">{isMobile ? "Mobile Preview" : "Desktop Preview"}</div>
          </div>

          <div className="h-[calc(100vh-10rem)] overflow-y-auto bg-black">
            <div className="backdrop-blur-md bg-black/20 border border-white/10 rounded-lg overflow-hidden hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all duration-300 m-4">
              <div className={`grid ${isMobile ? "grid-cols-1" : "grid-cols-3 md:grid-cols-5"} gap-2 md:gap-8`}>
                {/* Image section */}
                <div
                  className={`${isMobile ? "col-span-1" : "col-span-1 md:col-span-1"} p-3 md:p-4 flex items-center justify-center`}
                >
                  <div className="aspect-square relative rounded-lg w-full overflow-visible">
                    <div
                      className="absolute inset-0 flex items-center justify-center"
                      style={{ transform: "scale(2.75) translateX(3%)" }}
                    >
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-contain"
                        sizes="(max-width: 768px) 33vw, 20vw"
                        priority
                      />
                    </div>
                  </div>
                </div>

                {/* Product info section */}
                <div className={`${isMobile ? "col-span-1" : "col-span-2 md:col-span-4"} p-3 md:p-8 flex flex-col`}>
                  <div className="mb-1 md:mb-2 text-[10px] md:text-xs font-medium text-white/70">{product.brand}</div>
                  <h1 className="text-base md:text-xl font-bold text-white mb-2 md:mb-4">{product.name}</h1>
                  <div className="text-sm md:text-lg font-bold text-white mb-3 md:mb-6">
                    ${product.price.toLocaleString()}
                  </div>

                  <div className="mb-3 md:mb-6 p-2 md:p-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h3 className="text-[10px] text-white/60 mb-1">Case Size</h3>
                        <p className="text-xs font-medium text-white">{product.caseSize || "N/A"}</p>
                      </div>
                      <div>
                        <h3 className="text-[10px] text-white/60 mb-1">Case Material</h3>
                        <p className="text-xs font-medium text-white">{product.caseMaterial || "N/A"}</p>
                      </div>
                      <div>
                        <h3 className="text-[10px] text-white/60 mb-1">Dial Color</h3>
                        <p className="text-xs font-medium text-white">{product.dialColor || "N/A"}</p>
                      </div>
                      <div>
                        <h3 className="text-[10px] text-white/60 mb-1">Bracelet / Strap</h3>
                        <p className="text-xs font-medium text-white">{product.bracelet || "N/A"}</p>
                      </div>
                      <div className="col-span-2">
                        <h3 className="text-[10px] text-white/60 mb-1">Est. Market Value</h3>
                        <p className="text-xs font-medium text-white">
                          ${product.price.toLocaleString()} - $${(product.price * 1.1).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 md:gap-4 mt-auto">
                    <Button className="flex-1 text-xs md:text-sm rounded-full bg-white text-black hover:bg-white/90 h-8 md:h-10">
                      Inquire
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1 text-xs md:text-sm rounded-full text-white bg-white/5 backdrop-blur-sm hover:bg-white/10 h-8 md:h-10 transition-all duration-300 border-0"
                    >
                      Sell Mine
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Features section */}
            <div className="m-4 p-4 backdrop-blur-md bg-black/20 border border-white/10 rounded-lg">
              <h2 className="text-lg font-bold text-white mb-4">Features</h2>
              <ul className="list-disc pl-5 text-white/80 space-y-2">
                {product.features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
