"use client"

import { useEffect, useState } from "react"
import { X } from "lucide-react"

export function ProductionBanner() {
  const [isVisible, setIsVisible] = useState(false)
  const isProduction = process.env.NODE_ENV === "production"
  const isStagingEnv = process.env.NEXT_PUBLIC_ENVIRONMENT === "staging"

  useEffect(() => {
    // Only show banner in non-production environments or staging
    setIsVisible(!isProduction || isStagingEnv)
  }, [isProduction, isStagingEnv])

  if (!isVisible) {
    return null
  }

  const environment = isStagingEnv ? "STAGING" : "DEVELOPMENT"

  return (
    <div className="bg-yellow-500 text-black px-4 py-2 text-center relative">
      <p className="text-sm font-medium">{environment} ENVIRONMENT - This site is not in production mode</p>
      <button
        onClick={() => setIsVisible(false)}
        className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1"
        aria-label="Close banner"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  )
}
