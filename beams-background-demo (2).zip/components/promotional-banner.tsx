"use client"

import { useState, useEffect, useRef, useMemo } from "react"
import { motion } from "framer-motion"
import { Star, Quote } from "lucide-react"
import Image from "next/image"

// Simplified testimonial interface
interface Testimonial {
  id: string
  name: string
  position: string
  quote: string
  rating: number
}

// Optimized testimonials data - removed unnecessary fields
const testimonials: Testimonial[] = [
  {
    id: "john-smith",
    name: "John Smith",
    position: "Watch Collector",
    quote:
      "The attention to detail and craftsmanship of the watches I purchased exceeded my expectations. The customer service was exceptional throughout the entire process.",
    rating: 5,
  },
  {
    id: "sarah-johnson",
    name: "Sarah Johnson",
    position: "CEO",
    quote:
      "As someone who reviews luxury products for a living, I can confidently say that the quality and value of these timepieces are unmatched in the industry.",
    rating: 5,
  },
  {
    id: "michael-chen",
    name: "Michael Chen",
    position: "Watch Enthusiast",
    quote:
      "I've been collecting watches for over 20 years, and the pieces from this collection stand among the finest in my collection. Truly remarkable craftsmanship.",
    rating: 4,
  },
  {
    id: "emma-wilson",
    name: "Emma Wilson",
    position: "Fashion Editor",
    quote:
      "These timepieces are not just accessories, they're statements. The design is timeless and the quality is impeccable. I receive compliments every time I wear mine.",
    rating: 5,
  },
  {
    id: "david-miller",
    name: "David Miller",
    position: "Collector",
    quote:
      "The authentication process gave me complete confidence in my purchase. The watch arrived in perfect condition and has been keeping perfect time.",
    rating: 5,
  },
  {
    id: "olivia-brown",
    name: "Olivia Brown",
    position: "Jewelry Designer",
    quote:
      "As someone who works with luxury items daily, I can spot quality immediately. These watches showcase exceptional craftsmanship that stands out even to a trained eye.",
    rating: 4,
  },
]

export function PromotionalBanner() {
  const [currentPage, setCurrentPage] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const [isHovering, setIsHovering] = useState(false)
  const [isIOS, setIsIOS] = useState(false)

  // Detect iOS on mount
  useEffect(() => {
    const checkIsIOS = () => {
      const userAgent = window.navigator.userAgent.toLowerCase()
      return /iphone|ipad|ipod/.test(userAgent)
    }
    setIsIOS(checkIsIOS())
  }, [])

  // Calculate items per page based on screen size - memoized for performance
  const getItemsPerPage = () => {
    if (typeof window !== "undefined") {
      return window.innerWidth < 768 ? 1 : window.innerWidth < 1024 ? 2 : 3
    }
    return 3 // Default for SSR
  }

  const [itemsPerPage, setItemsPerPage] = useState(3)

  // Update items per page on resize - with debounce for performance
  useEffect(() => {
    const handleResize = () => {
      // Debounce resize handler
      if (resizeTimeout) clearTimeout(resizeTimeout)
      resizeTimeout = setTimeout(() => {
        setItemsPerPage(getItemsPerPage())
      }, 200)
    }

    let resizeTimeout: NodeJS.Timeout

    // Set initial value
    handleResize()

    window.addEventListener("resize", handleResize, { passive: true })
    return () => {
      window.removeEventListener("resize", handleResize)
      if (resizeTimeout) clearTimeout(resizeTimeout)
    }
  }, [])

  // Calculate total pages - memoized to prevent unnecessary recalculations
  const totalPages = useMemo(() => Math.ceil(testimonials.length / itemsPerPage), [itemsPerPage])

  // Auto-rotate testimonials - pause on hover
  useEffect(() => {
    // Skip auto-rotation if user is hovering
    if (isHovering) return

    const interval = setInterval(() => {
      setCurrentPage((prev) => (prev + 1) % totalPages)
    }, 8000)

    return () => clearInterval(interval)
  }, [totalPages, isHovering])

  const goToPage = (index: number) => {
    setCurrentPage(index)
  }

  // Get current testimonials to display - memoized to prevent recalculation on every render
  const currentTestimonials = useMemo(() => {
    const startIndex = currentPage * itemsPerPage
    return testimonials.slice(startIndex, startIndex + itemsPerPage)
  }, [currentPage, itemsPerPage])

  // Render stars based on rating - memoized by rating
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`h-3 w-3 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
          aria-hidden="true"
        />
      ))
  }

  // Optimized motion variants for iOS
  const motionVariants = {
    initial: { opacity: 0, y: isIOS ? 10 : 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: isIOS ? -10 : -20 },
    transition: { duration: isIOS ? 0.3 : 0.5 },
  }

  return (
    <div
      className="relative overflow-hidden rounded-2xl py-8"
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
      onTouchStart={() => setIsHovering(true)}
      onTouchEnd={() => setIsHovering(false)}
    >
      <div className="container mx-auto px-4">
        {/* Section Title */}
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold text-white">What Our Customers Say</h2>
          <div className="w-20 h-1 bg-white/30 mx-auto mt-3"></div>
        </div>

        {/* Testimonials Container */}
        <div className="relative">
          {/* Testimonials Grid */}
          <div
            ref={containerRef}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6"
            style={{
              // Force hardware acceleration for smoother animations
              transform: "translateZ(0)",
              WebkitTransform: "translateZ(0)",
              // Optimize for iOS
              WebkitOverflowScrolling: "touch",
            }}
          >
            {currentTestimonials.map((testimonial) => (
              <motion.div
                key={testimonial.id}
                initial={motionVariants.initial}
                animate={motionVariants.animate}
                exit={motionVariants.exit}
                transition={motionVariants.transition}
                className="bg-white/10 backdrop-blur-md rounded-lg p-4 shadow-lg flex flex-col h-full"
                style={{
                  // iOS optimizations
                  WebkitBackfaceVisibility: "hidden",
                  WebkitPerspective: 1000,
                  WebkitTransform: "translate3d(0,0,0)",
                  WebkitTransformStyle: "preserve-3d",
                  willChange: isIOS ? "transform, opacity" : "auto",
                }}
              >
                {/* Quote Icon */}
                <div className="mb-2">
                  <Quote className="h-5 w-5 text-white/40 rotate-180" />
                </div>

                {/* Testimonial Quote */}
                <p className="text-sm text-white/90 mb-4 flex-grow">"{testimonial.quote}"</p>

                {/* Author Info and Rating */}
                <div className="flex items-center mt-auto pt-3">
                  <div className="relative h-10 w-10 rounded-full overflow-hidden mr-3 bg-white/10">
                    {/* Optimized image loading with blur placeholder */}
                    <Image
                      src={`/smiling-woman-curly-brown-hair-headshot.png?height=40&width=40&query=professional headshot of ${testimonial.name}`}
                      alt={testimonial.name}
                      fill
                      className="object-cover"
                      sizes="40px"
                      loading="lazy"
                      style={{
                        objectFit: "cover",
                        // Prevent image flickering on iOS
                        WebkitTransform: "translateZ(0)",
                      }}
                    />
                  </div>
                  <div className="flex-grow">
                    <h3 className="text-xs font-bold text-white">{testimonial.name}</h3>
                    <p className="text-xs text-white/70">{testimonial.position}</p>
                  </div>
                  <div className="flex space-x-0.5">{renderStars(testimonial.rating)}</div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Page Indicators - Optimized for touch */}
          {totalPages > 1 && (
            <div className="flex justify-center space-x-3 mt-6">
              {Array(totalPages)
                .fill(0)
                .map((_, index) => (
                  <button
                    key={index}
                    className={`h-2.5 rounded-full transition-all ${
                      index === currentPage ? "w-8 bg-white" : "w-2.5 bg-white/30"
                    }`}
                    onClick={() => goToPage(index)}
                    aria-label={`Go to testimonial page ${index + 1}`}
                    style={{
                      touchAction: "manipulation",
                      WebkitTapHighlightColor: "transparent",
                    }}
                  />
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
