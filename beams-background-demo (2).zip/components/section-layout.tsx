import type React from "react"

interface SectionLayoutProps {
  title?: string
  description?: string
  children: React.ReactNode
  className?: string
}

export function SectionLayout({ children, className = "" }: SectionLayoutProps) {
  return <>{children}</>
}
