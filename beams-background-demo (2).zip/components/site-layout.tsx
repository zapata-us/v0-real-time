"use client"

import type React from "react"
import BeamsBackground from "@/components/beams-background"
import { GlassNavbar } from "@/components/glass-navbar"
import { DraftBanner } from "@/components/draft-banner"
import Image from "next/image"
import Link from "next/link"
import { useState, useEffect } from "react"

// Add this after the imports at the top of the file
const fadeInKeyframes = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
`

interface SiteLayoutProps {
  children: React.ReactNode
  intensity?: "subtle" | "medium" | "strong"
  isAdmin?: boolean
}

export function SiteLayout({ children, intensity = "medium", isAdmin = false }: SiteLayoutProps) {
  const [currentPath, setCurrentPath] = useState("")

  useEffect(() => {
    setCurrentPath(window.location.pathname)
  }, [])

  return (
    <BeamsBackground intensity={isAdmin ? "subtle" : intensity}>
      <div
        className="min-h-screen flex flex-col"
        style={{
          // Use proper iOS-safe classes instead of inline styles
          WebkitOverflowScrolling: "touch",
        }}
      >
        <GlassNavbar />

        <main className={`flex-1 ${isAdmin ? "pt-12" : ""} ios-safe-bottom backdrop-blur-md bg-black/10`}>
          {isAdmin ? (
            <div className="flex h-full">
              {/* Admin Sidebar - Simplified for Products and Subscribers only */}
              <div className="w-64 h-full bg-black/40 border-r border-white/10 overflow-y-auto">
                <div className="p-4">
                  <div className="flex items-center space-x-2 mb-8">
                    <div className="h-8 w-8 rounded-md bg-amber-400 flex items-center justify-center">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-5 w-5 text-black"
                      >
                        <path d="M12 4.5a2.5 2.5 0 0 0-4.96-.46 2.5 2.5 0 0 0-1.98 3 2.5 2.5 0 0 0 1.32 4.24 2.5 2.5 0 0 0 1.98 3A2.5 2.5 0 1 0 12 19.5a2.5 2.5 0 0 0 3.96.44 2.5 2.5 0 0 0 2.08-2.93 2.5 2.5 0 0 0 1.38-4.24 2.5 2.5 0 0 0-1.38-4.24 2.5 2.5 0 0 0-2.08-2.93A2.5 2.5 0 0 0 12 4.5z" />
                        <circle cx="12" cy="12" r="2" />
                      </svg>
                    </div>
                    <h2 className="text-xl font-bold text-white">Admin Panel</h2>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-xs uppercase tracking-wider text-white/50 font-semibold mb-3 px-3">
                      Management
                    </h3>
                    <nav className="space-y-1">
                      <Link
                        href="/admin/products"
                        className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-white hover:bg-white/10 group"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5 mr-3 text-white/70 group-hover:text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                          />
                        </svg>
                        Products
                      </Link>
                      <Link
                        href="/admin/subscribers"
                        className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-white hover:bg-white/10 group"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5 mr-3 text-white/70 group-hover:text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                          />
                        </svg>
                        Subscribers
                      </Link>
                    </nav>
                  </div>

                  <div>
                    <h3 className="text-xs uppercase tracking-wider text-white/50 font-semibold mb-3 px-3">Account</h3>
                    <nav className="space-y-1">
                      <Link
                        href="/"
                        className="flex items-center px-3 py-2 text-sm font-medium rounded-md text-white hover:bg-white/10 group"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5 mr-3 text-white/70 group-hover:text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
                          />
                        </svg>
                        Back to Site
                      </Link>
                      <button className="w-full flex items-center px-3 py-2 text-sm font-medium rounded-md text-white hover:bg-white/10 group">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5 mr-3 text-white/70 group-hover:text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                          />
                        </svg>
                        Sign Out
                      </button>
                    </nav>
                  </div>
                </div>
              </div>

              {/* Admin Content Area */}
              <div className="flex-1 overflow-y-auto p-4">
                <div className="max-w-7xl mx-auto">{children}</div>
              </div>
            </div>
          ) : (
            children
          )}
        </main>

        {!isAdmin && !currentPath.includes("/subscription") && (
          <footer className="backdrop-blur-md bg-black/30 border-t border-white/10 py-6 ios-safe-bottom">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
                {/* Logo section - optimized with width/height */}
                <div className="flex justify-center md:justify-start">
                  <div className="mb-2">
                    <Image
                      src="/images/real-time-logo.png"
                      alt="REAL TIME Logo"
                      width={160}
                      height={40}
                      className="object-contain"
                      priority={false}
                      loading="lazy"
                    />
                  </div>
                </div>

                {/* Support links - optimized with better touch targets */}
                <div>
                  <ul className="space-y-1">
                    <li>
                      <h4 className="text-sm font-medium text-white mb-2">SUPPORT CENTER</h4>
                    </li>
                    {["Repair Your Watch", "Trade Your Watch", "Sell Your Watch", "Contact Us"].map((item) => (
                      <li key={item}>
                        <Link
                          href={
                            item === "Contact Us" ? "/contact" : `/support#${item.toLowerCase().replace(/\s+/g, "-")}`
                          }
                          className="text-sm text-white/70 hover:text-white block py-1.5"
                        >
                          {item}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Newsletter - optimized form handling */}
                <div className="mx-auto w-full max-w-[280px] md:max-w-none">
                  <h3 className="text-sm font-semibold text-white mb-2">NEWSLETTER</h3>
                  <p className="text-sm text-white/70 mb-3">
                    Subscribe to receive updates, access to exclusive deals, and more.
                  </p>

                  <form
                    className="flex flex-col space-y-2"
                    onSubmit={(e) => {
                      e.preventDefault()
                      const emailInput = e.currentTarget.querySelector('input[type="email"]') as HTMLInputElement
                      const email = emailInput.value.trim()

                      // Simple email validation
                      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
                      if (!email || !emailRegex.test(email)) {
                        alert("Please enter a valid email address")
                        return
                      }

                      // Instead of using mailto: which can be blocked, just show success message
                      // We would normally send this to an API endpoint
                      console.log("Email subscription for:", email)

                      // Clear the input after submission
                      emailInput.value = ""
                      alert(`Thank you for subscribing with ${email}!`)
                    }}
                  >
                    <div className="flex relative">
                      <input
                        type="email"
                        placeholder="Enter your email"
                        aria-label="Email address"
                        className="flex-1 bg-black/20 border border-white/20 rounded-l-md px-2 py-2 text-white placeholder:text-white/50 focus:outline-none text-sm"
                      />
                      <button
                        type="submit"
                        className="bg-white text-black px-3 py-2 rounded-r-md hover:bg-white/90 transition-colors text-sm whitespace-nowrap"
                        aria-label="Subscribe to newsletter"
                      >
                        Subscribe
                      </button>
                    </div>
                  </form>
                </div>
              </div>

              {/* Copyright section - simplified */}
              <div className="border-t border-white/10 mt-6 pt-4 flex justify-between items-center">
                <div className="text-sm text-white/50">© 2025 REAL TIME. All rights reserved.</div>
              </div>
            </div>
          </footer>
        )}

        {/* Show draft banner for admin users */}
        <DraftBanner />
      </div>
    </BeamsBackground>
  )
}
