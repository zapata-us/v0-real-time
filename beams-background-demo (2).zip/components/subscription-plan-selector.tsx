"use client"

import { useState } from "react"
import { Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

interface Plan {
  id: string
  name: string
  description: string
  priceId: {
    monthly: string
    annual: string
  }
  price: {
    monthly: number
    annual: number
  }
  features: {
    name: string
    included: boolean
  }[]
  popular?: boolean
}

interface SubscriptionPlanSelectorProps {
  plans: Plan[]
  onSelectPlan: (plan: Plan, billingCycle: "monthly" | "annual") => void
  defaultSelected?: string
  defaultBillingCycle?: "monthly" | "annual"
}

export function SubscriptionPlanSelector({
  plans,
  onSelectPlan,
  defaultSelected = "premium",
  defaultBillingCycle = "annual",
}: SubscriptionPlanSelectorProps) {
  const [selectedPlan, setSelectedPlan] = useState<string>(defaultSelected)
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">(defaultBillingCycle)

  // Calculate savings percentage for annual billing
  const calculateSavings = (monthly: number, annual: number) => {
    const monthlyCost = monthly * 12
    const savings = ((monthlyCost - annual) / monthlyCost) * 100
    return Math.round(savings)
  }

  const handlePlanChange = (planId: string) => {
    setSelectedPlan(planId)
  }

  const handleBillingCycleChange = (isAnnual: boolean) => {
    setBillingCycle(isAnnual ? "annual" : "monthly")
  }

  const handleContinue = () => {
    const plan = plans.find((p) => p.id === selectedPlan)
    if (plan) {
      onSelectPlan(plan, billingCycle)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-center space-x-2 mb-8">
        <Label htmlFor="billing-toggle" className="text-gray-400">
          Monthly Billing
        </Label>
        <Switch
          id="billing-toggle"
          checked={billingCycle === "annual"}
          onCheckedChange={handleBillingCycleChange}
          className="data-[state=checked]:bg-stone-400"
        />
        <Label htmlFor="billing-toggle" className="flex items-center">
          <span className="text-gray-400">Annual Billing</span>
          <Badge className="ml-2 bg-stone-400 text-black border-none">Save 16-20%</Badge>
        </Label>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`relative overflow-hidden border-2 transition-all duration-200 ${
              selectedPlan === plan.id
                ? "border-stone-400 bg-gray-800/50"
                : "border-transparent bg-gray-800/30 hover:bg-gray-800/40"
            }`}
          >
            {plan.popular && (
              <div className="absolute top-0 right-0">
                <Badge className="rounded-none rounded-bl-lg bg-stone-400 text-black">Most Popular</Badge>
              </div>
            )}
            <CardHeader>
              <CardTitle className="text-white">{plan.name}</CardTitle>
              <CardDescription className="text-gray-400">{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-white">
                  ${billingCycle === "annual" ? plan.price.annual : plan.price.monthly}
                </div>
                <div className="text-gray-400 text-sm">{billingCycle === "annual" ? "per year" : "per month"}</div>
                {billingCycle === "annual" && (
                  <div className="text-stone-400 text-xs mt-1">
                    Save {calculateSavings(plan.price.monthly, plan.price.annual)}%
                  </div>
                )}
              </div>

              <div className="space-y-2">
                {plan.features.map((feature) => (
                  <div key={feature.name} className="flex items-start">
                    {feature.included ? (
                      <Check className="h-5 w-5 text-stone-400 mr-2 shrink-0" />
                    ) : (
                      <X className="h-5 w-5 text-gray-500 mr-2 shrink-0" />
                    )}
                    <div className={`text-sm ${feature.included ? "text-white" : "text-gray-500"}`}>{feature.name}</div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button
                onClick={() => handlePlanChange(plan.id)}
                className={
                  selectedPlan === plan.id
                    ? "w-full bg-stone-400 hover:bg-stone-500 text-black"
                    : "w-full bg-gray-700 hover:bg-gray-600 text-white"
                }
              >
                {selectedPlan === plan.id ? "Selected" : "Select Plan"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="flex justify-center">
        <Button onClick={handleContinue} className="bg-stone-400 hover:bg-stone-500 text-black px-8" size="lg">
          Continue with {plans.find((p) => p.id === selectedPlan)?.name} Plan
        </Button>
      </div>
    </div>
  )
}
