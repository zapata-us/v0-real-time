"use client"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState, useEffect, useRef } from "react"

type TermsModalProps = {
  isOpen: boolean
  onClose: () => void
  title?: string
  content?: string
  onAccept?: () => void
}

export function TermsModal({
  isOpen,
  onClose,
  title = "Subscription Terms & Conditions",
  content,
  onAccept,
}: TermsModalProps) {
  const [hasReachedBottom, setHasReachedBottom] = useState(false)
  const contentRef = useRef<HTMLDivElement>(null)

  // Reset scroll state when modal opens
  useEffect(() => {
    if (isOpen) {
      setHasReachedBottom(false)
    }
  }, [isOpen])

  // Check if user has scrolled to the bottom
  const handleScroll = () => {
    if (!contentRef.current) return

    const { scrollTop, scrollHeight, clientHeight } = contentRef.current
    // Consider "bottom" when user is within 20px of the actual bottom
    const isBottom = scrollTop + clientHeight >= scrollHeight - 20

    if (isBottom && !hasReachedBottom) {
      setHasReachedBottom(true)
    }
  }

  const handleAccept = () => {
    onClose()
    if (onAccept) {
      onAccept()
    }
  }

  if (!isOpen) return null

  const defaultContent = `
    1. Subscription Terms
    By subscribing to Real Time, you agree to the following terms and conditions. Please read these carefully before proceeding with your subscription.

    2. Subscription Period and Renewal
    Your subscription will begin on the date of purchase and continue for the period specified in your selected plan (monthly or annual). Subscriptions automatically renew at the end of each billing period unless cancelled.

    3. Pricing and Payment
    3.1 The subscription fee will be charged to your designated payment method at the beginning of each billing period.
    3.2 We reserve the right to change subscription prices upon notice. Any price changes will take effect at the next billing cycle.
    3.3 All payments are non-refundable except as expressly stated in these terms or as required by applicable law.

    4. Cancellation Policy
    4.1 You may cancel your subscription at any time through your account settings or by contacting customer support.
    4.2 Cancellation will take effect at the end of your current billing period. You will not receive a refund for the current billing period.
    4.3 Upon cancellation, you will lose access to premium content and features at the end of your billing period.

    5. Access to Content
    5.1 Your subscription grants you a non-exclusive, non-transferable right to access and use the content and features available through Real Time.
    5.2 You may not share your account credentials or subscription benefits with others.
    5.3 We reserve the right to modify, update, or remove content at any time without notice.

    6. Intellectual Property
    6.1 All content provided through Real Time is protected by copyright, trademark, and other intellectual property laws.
    6.2 You may not reproduce, distribute, modify, create derivative works of, publicly display, or exploit any content from Real Time without explicit permission.

    7. Account Security
    7.1 You are responsible for maintaining the confidentiality of your account credentials.
    7.2 You must notify us immediately of any unauthorized use of your account or any other breach of security.

    8. Limitation of Liability
    8.1 To the maximum extent permitted by law, we shall not be liable for any indirect, incidental, special, consequential, or punitive damages.
    8.2 Our total liability for any claims arising from or related to your subscription shall not exceed the amount paid by you for the subscription during the twelve (12) months preceding the claim.

    9. Changes to Terms
    We may modify these terms at any time by posting the revised terms on our website. Your continued use of the subscription after such changes constitutes your acceptance of the new terms.

    10. Governing Law
    These terms shall be governed by and construed in accordance with the laws of Florida, without regard to its conflict of law principles.

    11. Contact Information
    If you have any questions about these terms, please contact us at support@realtime.com.
  `

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 bg-black/60 backdrop-blur-md">
      <div className="relative flex flex-col w-full h-full sm:h-auto sm:max-h-[85vh] sm:max-w-3xl sm:rounded-2xl overflow-hidden bg-white/10 backdrop-blur-xl shadow-lg border border-white/20 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="sticky top-0 flex justify-between items-center p-4 sm:p-6 border-b border-white/15 bg-white/10 backdrop-blur-xl z-20">
          <h2 className="text-xl font-semibold text-white">{title}</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-8 w-8 rounded-full text-white/70 hover:text-white hover:bg-white/10 sm:h-10 sm:w-10"
          >
            <X className="h-4 w-4 sm:h-5 sm:w-5" />
            <span className="sr-only">Close</span>
          </Button>
        </div>

        {/* Content - with padding to ensure content doesn't go under the footer */}
        <div ref={contentRef} onScroll={handleScroll} className="flex-1 overflow-auto p-4 sm:p-6 pb-24">
          <div className="whitespace-pre-line text-sm text-white/90 leading-relaxed">{content || defaultContent}</div>
        </div>

        {/* Footer - fixed at the bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 border-t border-white/15 bg-black/50 backdrop-blur-xl z-20 flex justify-center w-full">
          {hasReachedBottom ? (
            <Button
              onClick={handleAccept}
              className="bg-[#d4af37] hover:bg-[#b8860b] text-black font-medium px-8 w-full sm:w-auto animate-in fade-in duration-300"
            >
              I Agree
            </Button>
          ) : (
            <div className="text-white/70 text-sm animate-pulse">Please scroll to the bottom to continue</div>
          )}
        </div>
      </div>
    </div>
  )
}
