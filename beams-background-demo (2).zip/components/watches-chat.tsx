"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { X, Maximize2, Send, Smile, Phone, Video, ImageIcon, Paperclip, MoreVertical } from "lucide-react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  content: string
  sender: "user" | "system" | "agent"
  timestamp: Date
  status?: "sent" | "delivered" | "read"
  isTyping?: boolean
}

interface QuickReply {
  id: string
  text: string
}

export default function WatchesChat() {
  const [isOpen, setIsOpen] = useState(true)
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState(
    "I'm ready to buy a 5168G-001. Can you help with that?\n\n(https://watches.io/marketplace/patek-philippe/aquanaut/aquanaut-date-sweep-seconds-jumbo-5168g-001-42mm-blue)",
  )
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content: "Welcome to the Real Time Concierge. Leave a message and we'll get back to you shortly.",
      sender: "system",
      timestamp: new Date(),
    },
  ])
  const [isTyping, setIsTyping] = useState(false)
  const [agentOnline, setAgentOnline] = useState(true)
  const [quickReplies, setQuickReplies] = useState<QuickReply[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [lastSeen, setLastSeen] = useState<Date | null>(new Date())
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [showAttachMenu, setShowAttachMenu] = useState(false)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Simulate agent coming online/offline
  useEffect(() => {
    const toggleAgentStatus = () => {
      // 90% chance agent stays online
      if (Math.random() > 0.9) {
        setAgentOnline((prev) => !prev)

        // If coming back online, update last seen
        if (!agentOnline) {
          setLastSeen(new Date())
        }
      }
    }

    const interval = setInterval(toggleAgentStatus, 30000)
    return () => clearInterval(interval)
  }, [agentOnline])

  // Simulate typing with realistic pauses
  const simulateTyping = (text: string, onComplete: (text: string) => void) => {
    setIsTyping(true)

    // Calculate a realistic typing time based on message length
    // Average typing speed is about 40 WPM, or ~200 characters per minute
    const typingSpeed = 200 / 60 // characters per second
    const typingTime = Math.max(1500, Math.min((text.length / typingSpeed) * 1000, 8000))

    // Add some randomness to make it feel more human
    const actualTypingTime = typingTime * (0.8 + Math.random() * 0.4)

    setTimeout(() => {
      setIsTyping(false)
      onComplete(text)
    }, actualTypingTime)
  }

  const generateResponse = (userMessage: string) => {
    // Extract watch model if mentioned
    const watchModelMatch = userMessage.match(/5168G-001|Aquanaut/i)
    const watchModel = watchModelMatch ? "Patek Philippe Aquanaut 5168G-001" : "luxury timepiece"

    // Check message intent
    if (userMessage.toLowerCase().includes("buy") || userMessage.toLowerCase().includes("purchase")) {
      const response = `Thank you for your interest in the ${watchModel}. This is a beautiful piece currently priced at $85,500 with limited availability. I'd be happy to help you with the purchase process. Could you please confirm your preferred shipping address and payment method? We can typically arrange delivery within 2-3 business days after confirmation.`

      setQuickReplies([
        { id: "payment", text: "What payment methods do you accept?" },
        { id: "shipping", text: "Tell me about shipping options" },
        { id: "authenticity", text: "How do you verify authenticity?" },
      ])

      return response
    } else if (userMessage.toLowerCase().includes("price") || userMessage.toLowerCase().includes("cost")) {
      return `The ${watchModel} is currently priced at $85,500. This price includes our authenticity guarantee, premium packaging, and insured shipping. Would you like to proceed with the purchase?`
    } else if (userMessage.toLowerCase().includes("shipping") || userMessage.toLowerCase().includes("delivery")) {
      return `We offer complimentary expedited shipping on all purchases, fully insured against loss or damage. For the ${watchModel}, we can arrange delivery within 2-3 business days to most locations. International shipping is also available but may take longer depending on customs clearance. Would you like to proceed with your purchase?`
    } else if (userMessage.toLowerCase().includes("payment")) {
      return `We accept all major credit cards, wire transfers, and cryptocurrency (Bitcoin, Ethereum). For purchases over $50,000 like the ${watchModel}, we recommend wire transfer for the most secure transaction. We can also discuss financing options if you're interested. How would you prefer to proceed with payment?`
    } else if (userMessage.toLowerCase().includes("authentic") || userMessage.toLowerCase().includes("genuine")) {
      return `Every timepiece we sell, including the ${watchModel}, undergoes a rigorous authentication process by our certified watchmakers. We provide a certificate of authenticity and a 2-year warranty with your purchase. We also offer a lifetime guarantee of authenticity. Would you like more details about our authentication process?`
    } else {
      return `Thank you for your message regarding the ${watchModel}. I'm here to assist with any questions you might have about specifications, availability, or the purchase process. Is there anything specific you'd like to know about this exceptional timepiece?`
    }
  }

  const handleSendMessage = () => {
    if (!message.trim()) return

    // Add user message
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      content: message,
      sender: "user",
      timestamp: new Date(),
      status: "sent",
    }

    setMessages((prev) => [...prev, userMessage])
    setMessage("")
    setQuickReplies([])

    // Update message status to delivered after a short delay
    setTimeout(() => {
      setMessages((prev) => prev.map((msg) => (msg.id === userMessage.id ? { ...msg, status: "delivered" } : msg)))
    }, 1000)

    // Simulate agent typing and response if online
    if (agentOnline) {
      // First, show typing indicator
      setIsTyping(true)

      // Generate response based on user message
      const responseText = generateResponse(userMessage.content)

      // Simulate typing with a realistic delay
      simulateTyping(responseText, (text) => {
        const agentMessage: Message = {
          id: `agent-${Date.now()}`,
          content: text,
          sender: "agent",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, agentMessage])
        setUnreadCount((prev) => prev + 1)

        // Update user message status to read
        setMessages((prev) => prev.map((msg) => (msg.id === userMessage.id ? { ...msg, status: "read" } : msg)))
      })
    } else {
      // If agent is offline, send an automated response after a longer delay
      setTimeout(() => {
        const offlineMessage: Message = {
          id: `system-${Date.now()}`,
          content:
            "Our concierge is currently unavailable but will respond to your inquiry as soon as possible. Thank you for your patience.",
          sender: "system",
          timestamp: new Date(),
        }

        setMessages((prev) => [...prev, offlineMessage])
      }, 10000)
    }
  }

  const handleQuickReply = (reply: QuickReply) => {
    setMessage(reply.text)
    // Focus on input after selecting quick reply
    setTimeout(() => {
      const textarea = document.getElementById("message-input")
      if (textarea) {
        textarea.focus()
      }
    }, 0)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const closeChat = () => {
    setIsOpen(false)
  }

  // Format time for display
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  // Format date for display
  const formatDate = (date: Date) => {
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (date.toDateString() === today.toDateString()) {
      return "Today"
    } else if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday"
    } else {
      return date.toLocaleDateString(undefined, { month: "short", day: "numeric" })
    }
  }

  // Get message status icon
  const getStatusIcon = (status?: string) => {
    switch (status) {
      case "sent":
        return <div className="w-3 h-3 rounded-full border border-blue-500"></div>
      case "delivered":
        return <div className="w-3 h-3 rounded-full bg-blue-500"></div>
      case "read":
        return (
          <div className="flex -space-x-1">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
          </div>
        )
      default:
        return null
    }
  }

  if (!isOpen) return null

  return (
    <div
      className={cn(
        "fixed z-50 flex flex-col overflow-hidden transition-all duration-300 bg-white rounded-lg shadow-xl",
        isFullscreen ? "inset-0 m-0" : "bottom-4 right-4 w-[380px] h-[520px]",
      )}
    >
      {/* Chat Header */}
      <div className="flex items-center p-3 bg-[#1a1a1a] text-white">
        <button className="p-1 rounded-full hover:bg-white/10 transition-colors" aria-label="Back">
          <span className="text-lg">←</span>
        </button>

        <div className="flex -space-x-2 mx-2">
          <div className="relative w-8 h-8 rounded-full bg-gray-300 border-2 border-[#1a1a1a] overflow-hidden">
            <Image
              src="/placeholder.svg?height=32&width=32"
              alt="Agent"
              width={32}
              height={32}
              className="object-cover"
            />
            {agentOnline && (
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#1a1a1a]"></div>
            )}
          </div>
          <div className="w-8 h-8 rounded-full bg-gray-300 border-2 border-[#1a1a1a] overflow-hidden">
            <Image
              src="/placeholder.svg?height=32&width=32"
              alt="User"
              width={32}
              height={32}
              className="object-cover"
            />
          </div>
        </div>

        <div className="flex-1">
          <span className="font-medium">Watches.io</span>
          <div className="text-xs text-gray-300">
            {agentOnline ? (
              <span className="flex items-center">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>
                Online
              </span>
            ) : lastSeen ? (
              <span>Last seen {formatTime(lastSeen)}</span>
            ) : (
              <span>Offline</span>
            )}
          </div>
        </div>

        <div className="flex">
          <button className="p-1.5 rounded-full hover:bg-white/10 transition-colors" aria-label="Voice call">
            <Phone size={16} />
          </button>

          <button className="p-1.5 rounded-full hover:bg-white/10 transition-colors" aria-label="Video call">
            <Video size={16} />
          </button>

          <button
            className="p-1.5 rounded-full hover:bg-white/10 transition-colors mr-1"
            onClick={toggleFullscreen}
            aria-label="Toggle fullscreen"
          >
            <Maximize2 size={16} />
          </button>

          <button
            className="p-1.5 rounded-full hover:bg-white/10 transition-colors"
            onClick={closeChat}
            aria-label="Close chat"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Chat Content */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        {messages.map((msg, index) => {
          // Check if we need to show date separator
          const showDateSeparator =
            index === 0 || formatDate(msg.timestamp) !== formatDate(messages[index - 1].timestamp)

          return (
            <div key={msg.id}>
              {showDateSeparator && (
                <div className="flex justify-center my-4">
                  <div className="px-3 py-1 bg-gray-200 rounded-full text-xs text-gray-600">
                    {formatDate(msg.timestamp)}
                  </div>
                </div>
              )}

              <div
                className={cn(
                  "mb-4 max-w-[85%] rounded-lg p-3 relative group",
                  msg.sender === "user"
                    ? "bg-blue-500 text-white ml-auto"
                    : msg.sender === "system"
                      ? "bg-gray-200 text-gray-800"
                      : "bg-white border border-gray-200 shadow-sm",
                )}
              >
                <p className="whitespace-pre-wrap text-sm">{msg.content}</p>
                <div
                  className={cn(
                    "flex items-center justify-end text-xs mt-1 space-x-1",
                    msg.sender === "user" ? "text-blue-100" : "text-gray-500",
                  )}
                >
                  <span>{formatTime(msg.timestamp)}</span>
                  {msg.sender === "user" && getStatusIcon(msg.status)}
                </div>

                {/* Message actions on hover */}
                {msg.sender === "user" && (
                  <div className="absolute right-0 top-0 transform translate-x-full -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-1 bg-white rounded-full shadow-md text-gray-500 hover:text-gray-700">
                      <MoreVertical size={14} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )
        })}

        {isTyping && (
          <div className="bg-white border border-gray-200 rounded-lg p-3 max-w-[85%] shadow-sm mb-4">
            <div className="flex space-x-2">
              <div className="w-2 h-2 rounded-full bg-gray-400 animate-bounce" style={{ animationDelay: "0ms" }}></div>
              <div
                className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                style={{ animationDelay: "150ms" }}
              ></div>
              <div
                className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"
                style={{ animationDelay: "300ms" }}
              ></div>
            </div>
          </div>
        )}

        {/* Quick replies */}
        {quickReplies.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {quickReplies.map((reply) => (
              <button
                key={reply.id}
                onClick={() => handleQuickReply(reply)}
                className="px-3 py-1.5 bg-white border border-gray-300 rounded-full text-sm text-gray-700 hover:bg-gray-100 transition-colors shadow-sm"
              >
                {reply.text}
              </button>
            ))}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-gray-200 bg-white p-3">
        <input
          type="email"
          placeholder="email@example.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full mb-2 p-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        <div className="flex">
          <div className="flex-1 border border-gray-300 rounded-l-md p-2 bg-white">
            <textarea
              id="message-input"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder="Type your message..."
              className="w-full resize-none focus:outline-none text-sm h-[60px]"
            />
          </div>

          <div className="flex flex-col border-t border-r border-b border-gray-300 rounded-r-md overflow-hidden">
            <div className="relative">
              <button
                className="p-2 hover:bg-gray-100 transition-colors flex-1 border-b border-gray-300"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                aria-label="Add emoji"
              >
                <Smile size={20} className="text-gray-500" />
              </button>

              {showEmojiPicker && (
                <div className="absolute bottom-full right-0 mb-2 p-2 bg-white rounded-lg shadow-lg border border-gray-200">
                  <div className="grid grid-cols-6 gap-2">
                    {["😊", "👍", "🙏", "💯", "⌚", "💎", "🔥", "👌", "🤔", "😍", "💰", "🎉"].map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => {
                          setMessage((prev) => prev + emoji)
                          setShowEmojiPicker(false)
                        }}
                        className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="relative">
              <button
                className="p-2 hover:bg-gray-100 transition-colors flex-1 border-b border-gray-300"
                onClick={() => setShowAttachMenu(!showAttachMenu)}
                aria-label="Attach file"
              >
                <Paperclip size={20} className="text-gray-500" />
              </button>

              {showAttachMenu && (
                <div className="absolute bottom-full right-0 mb-2 p-2 bg-white rounded-lg shadow-lg border border-gray-200">
                  <div className="flex flex-col space-y-1">
                    <button className="flex items-center px-3 py-2 hover:bg-gray-100 rounded text-sm">
                      <ImageIcon size={16} className="mr-2 text-blue-500" />
                      <span>Photo</span>
                    </button>
                    <button className="flex items-center px-3 py-2 hover:bg-gray-100 rounded text-sm">
                      <Paperclip size={16} className="mr-2 text-green-500" />
                      <span>Document</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              className="p-2 hover:bg-blue-50 transition-colors flex-1 text-blue-500"
              onClick={handleSendMessage}
              aria-label="Send message"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
