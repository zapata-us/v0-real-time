"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { useRouter } from "next/navigation"

export type SubscriptionTier = "standard" | null
export type SubscriptionStatus = "active" | "inactive" | "past_due" | "canceled" | "trialing"

export type User = {
  id: string
  email: string
  name: string
  subscriptionStatus: SubscriptionStatus
  subscriptionTier: SubscriptionTier
  subscriptionRenewalDate: string | null
  billingCycle: "monthly" | "annual"
  createdAt: string
}

type AuthContextType = {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  signup: (email: string, password: string, name: string, subscriptionData?: any) => Promise<void>
  logout: () => void
  resetPassword: (email: string) => Promise<void>
  updateSubscription: (billingCycle: "monthly" | "annual") => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Check if user is logged in on mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem("auth_token")

        if (!token) {
          setIsLoading(false)
          return
        }

        // Simulate fetching user data
        // In a real app, you would validate the token with your backend
        setTimeout(() => {
          setUser({
            id: "1",
            email: "user@example.com",
            name: "John Doe",
            subscriptionStatus: "active",
            subscriptionTier: "standard",
            subscriptionRenewalDate: "2025-06-15",
            billingCycle: "annual",
            createdAt: "2023-01-15",
          })
          setIsLoading(false)
        }, 500)
      } catch (error) {
        console.error("Authentication error:", error)
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [])

  const login = async (email: string, password: string) => {
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock successful login
      if (email && password) {
        const mockUser = {
          id: "1",
          email,
          name: email.split("@")[0],
          subscriptionStatus: "active",
          subscriptionTier: "standard",
          subscriptionRenewalDate: "2025-06-15",
          billingCycle: "annual",
          createdAt: "2023-01-15",
        }

        localStorage.setItem("auth_token", "mock_token_12345")
        setUser(mockUser)
        router.push("/dashboard")
      } else {
        throw new Error("Invalid credentials")
      }
    } catch (error) {
      console.error("Login error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const signup = async (email: string, password: string, name: string, subscriptionData?: any) => {
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // In a real implementation, you would:
      // 1. Process the payment with Stripe - charging exactly $10 monthly or $100 yearly
      // 2. Create the user account only after successful payment
      // 3. Associate the subscription with the user account

      // Mock successful signup with subscription
      if (email && password && name) {
        const billingCycle = subscriptionData?.billingCycle || "annual"

        const mockUser = {
          id: "1",
          email,
          name,
          subscriptionStatus: "active", // Active because payment is required
          subscriptionTier: "standard",
          subscriptionRenewalDate: new Date(
            new Date().setMonth(new Date().getMonth() + (billingCycle === "annual" ? 12 : 1)),
          ).toISOString(),
          billingCycle,
          createdAt: new Date().toISOString(),
        }

        localStorage.setItem("auth_token", "mock_token_12345")
        setUser(mockUser)
        router.push("/dashboard")
      } else {
        throw new Error("Invalid signup data")
      }
    } catch (error) {
      console.error("Signup error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const logout = () => {
    localStorage.removeItem("auth_token")
    setUser(null)
    router.push("/login")
  }

  const resetPassword = async (email: string) => {
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      // In a real app, this would send a password reset email
    } catch (error) {
      console.error("Password reset error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const updateSubscription = async (billingCycle: "monthly" | "annual") => {
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      if (user) {
        const updatedUser = {
          ...user,
          billingCycle,
          subscriptionRenewalDate: new Date(
            new Date().setMonth(new Date().getMonth() + (billingCycle === "annual" ? 12 : 1)),
          ).toISOString(),
        }
        setUser(updatedUser)
      }
    } catch (error) {
      console.error("Subscription update error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        signup,
        logout,
        resetPassword,
        updateSubscription,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
