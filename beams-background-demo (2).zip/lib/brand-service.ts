// Brand interface
export interface Brand {
  id: string
  name: string
  imagePath: string
  description: string
  color: string
  founded: string
  headquarters: string
  signatureModels: string[]
}

// Watch interface
export interface Watch {
  id: string
  name: string
  price: number
  image: string
  description: string
  features: string[]
  movement: string
  caseMaterial: string
  diameter: string
  waterResistance: string
}

// Detailed brand data
const brands: Brand[] = [
  {
    id: "rolex",
    name: "Rolex",
    imagePath: "/images/real-time-rolex.png",
    description: "The epitome of luxury and precision since 1905.",
    color: "from-emerald-500/20 to-emerald-500/5",
    founded: "1905",
    headquarters: "Geneva, Switzerland",
    signatureModels: ["Submariner", "Datejust", "Day-Date", "Sky-Dweller"],
  },
  {
    id: "audemars-piguet",
    name: "Audemars Piguet",
    imagePath: "/images/real-time-audemars-piguet.png",
    description: "Masters of complicated watchmaking since 1875.",
    color: "from-blue-500/20 to-blue-500/5",
    founded: "1875",
    headquarters: "Le Brassus, Switzerland",
    signatureModels: ["Royal Oak", "Royal Oak Offshore", "Millenary", "Code 11.59"],
  },
  {
    id: "cartier",
    name: "Cartier",
    imagePath: "/real-time-cartier.png",
    description: "The jeweler of kings and the king of jewelers.",
    color: "from-red-500/20 to-red-500/5",
    founded: "1847",
    headquarters: "Paris, France",
    signatureModels: ["Tank", "Santos", "Ballon Bleu", "Panthère"],
  },
  {
    id: "omega",
    name: "Omega",
    imagePath: "/images/real-time-omega.png",
    description: "Pioneering spirit and innovation in watchmaking.",
    color: "from-amber-500/20 to-amber-500/5",
    founded: "1848",
    headquarters: "Biel/Bienne, Switzerland",
    signatureModels: ["Speedmaster", "Seamaster", "Constellation", "De Ville"],
  },
  {
    id: "hublot",
    name: "Hublot",
    imagePath: "/images/real-time-hublot.png",
    description: "The art of fusion in watchmaking.",
    color: "from-purple-500/20 to-purple-500/5",
    founded: "1980",
    headquarters: "Nyon, Switzerland",
    signatureModels: ["Big Bang", "Classic Fusion", "Spirit of Big Bang", "MP Collection"],
  },
  {
    id: "patek-philippe",
    name: "Patek Philippe",
    imagePath: "/images/real-time-patek.png",
    description: "Tradition and innovation in fine watchmaking since 1839.",
    color: "from-indigo-500/20 to-indigo-500/5",
    founded: "1839",
    headquarters: "Geneva, Switzerland",
    signatureModels: ["Nautilus", "Calatrava", "Aquanaut", "Complications"],
  },
]

// Sample watch data for each brand
const brandWatches: Record<string, Watch[]> = {
  rolex: [
    {
      id: "sky-dweller",
      name: "Sky-Dweller",
      price: 14950,
      image: "/images/real-time-rolex.png",
      description:
        "The Rolex Sky-Dweller is designed for global travelers, featuring an innovative annual calendar and dual time zone display.",
      features: ["Annual calendar", "Dual time zone", "Fluted bezel", "Oyster bracelet"],
      movement: "Automatic",
      caseMaterial: "Oystersteel",
      diameter: "42mm",
      waterResistance: "100m",
    },
    {
      id: "submariner",
      name: "Submariner",
      price: 8950,
      image: "/images/real-time-rolex.png",
      description: "The Rolex Submariner is a classic diving watch, recognized for its durability and timeless design.",
      features: ["Rotatable bezel", "Luminescent display", "Date function"],
      movement: "Automatic",
      caseMaterial: "Oystersteel",
      diameter: "41mm",
      waterResistance: "300m",
    },
  ],
  "audemars-piguet": [
    {
      id: "royal-oak",
      name: "Royal Oak",
      price: 25500,
      image: "/images/real-time-audemars-piguet.png",
      description:
        "The Audemars Piguet Royal Oak, designed by Gerald Genta, revolutionized luxury sports watches with its octagonal bezel and integrated bracelet.",
      features: ["Octagonal bezel", "Tapisserie dial", "Integrated bracelet"],
      movement: "Automatic",
      caseMaterial: "Stainless Steel and 18K Rose Gold",
      diameter: "41mm",
      waterResistance: "50m",
    },
    {
      id: "royal-oak-offshore",
      name: "Royal Oak Offshore",
      price: 32000,
      image: "/images/audemars-piguet-royal-oak.png",
      description: "The Royal Oak Offshore is a bold, sporty evolution of the classic Royal Oak design.",
      features: ["Chronograph", "Screw-locked crown", "Rubber strap"],
      movement: "Automatic",
      caseMaterial: "Stainless Steel",
      diameter: "44mm",
      waterResistance: "100m",
    },
  ],
  // Other brands' watches data...
  cartier: [
    {
      id: "santos",
      name: "Santos",
      price: 7050,
      image: "/real-time-cartier.png",
      description:
        "The Cartier Santos was created in 1904 for Brazilian aviator Alberto Santos-Dumont, making it one of the first wristwatches designed for men.",
      features: ["Square case", "Exposed screws", "Roman numerals"],
      movement: "Automatic",
      caseMaterial: "Stainless Steel",
      diameter: "39.8mm",
      waterResistance: "100m",
    },
    {
      id: "tank",
      name: "Tank",
      price: 5500,
      image: "/real-time-cartier.png",
      description:
        "The Cartier Tank, introduced in 1917, is an icon of elegance with its rectangular case inspired by military tanks of WWI.",
      features: ["Rectangular case", "Roman numerals", "Blue sapphire crown"],
      movement: "Quartz",
      caseMaterial: "18K Gold",
      diameter: "25.5mm x 33.7mm",
      waterResistance: "30m",
    },
  ],
  omega: [
    {
      id: "speedmaster",
      name: "Speedmaster Professional",
      price: 6350,
      image: "/images/real-time-omega.png",
      description:
        "The Omega Speedmaster Professional, known as the 'Moonwatch', was the first watch worn on the moon during the Apollo 11 mission.",
      features: ["Chronograph", "Tachymeter scale", "Manual winding", "Silver Snoopy Award special edition"],
      movement: "Manual",
      caseMaterial: "Stainless Steel",
      diameter: "42mm",
      waterResistance: "50m",
    },
    {
      id: "seamaster",
      name: "Seamaster Diver 300M",
      price: 5200,
      image: "/images/real-time-omega.png",
      description:
        "The Omega Seamaster is a professional diving watch that combines elegant design with exceptional functionality.",
      features: ["Ceramic bezel", "Helium escape valve", "Co-Axial escapement"],
      movement: "Automatic",
      caseMaterial: "Stainless Steel",
      diameter: "42mm",
      waterResistance: "300m",
    },
  ],
  hublot: [
    {
      id: "big-bang",
      name: "Big Bang",
      price: 19900,
      image: "/images/real-time-hublot.png",
      description:
        "The Hublot Big Bang represents the art of fusion in watchmaking, combining different materials for a bold, contemporary look.",
      features: ["Chronograph", "Sapphire crystal", "Skeletonized dial"],
      movement: "Automatic",
      caseMaterial: "Ceramic",
      diameter: "44mm",
      waterResistance: "100m",
    },
    {
      id: "classic-fusion",
      name: "Classic Fusion",
      price: 11500,
      image: "/images/real-time-hublot.png",
      description:
        "The Hublot Classic Fusion offers a more refined take on the brand's signature design, with a thinner case and cleaner aesthetics.",
      features: ["Date display", "Polished & satin finishes", "Alligator strap"],
      movement: "Automatic",
      caseMaterial: "Titanium",
      diameter: "42mm",
      waterResistance: "50m",
    },
  ],
  "patek-philippe": [
    {
      id: "nautilus",
      name: "Nautilus",
      price: 35000,
      image: "/images/real-time-patek.png",
      description:
        "The Patek Philippe Nautilus, designed by Gerald Genta in 1976, is one of the most coveted luxury sports watches in the world.",
      features: ["Porthole-inspired case", "Horizontal embossed dial", "Integrated bracelet"],
      movement: "Automatic",
      caseMaterial: "Stainless Steel",
      diameter: "40mm",
      waterResistance: "120m",
    },
    {
      id: "calatrava",
      name: "Calatrava",
      price: 23000,
      image: "/images/real-time-patek.png",
      description:
        "The Patek Philippe Calatrava, introduced in 1932, is the quintessential dress watch, embodying the brand's philosophy of elegant simplicity.",
      features: ["Hobnail bezel", "Dauphine hands", "Small seconds subdial"],
      movement: "Manual",
      caseMaterial: "18K White Gold",
      diameter: "39mm",
      waterResistance: "30m",
    },
  ],
}

// Get all brands
export function getAllBrands(): Brand[] {
  return brands
}

// Get a brand by ID
export function getBrandById(id: string): Brand | undefined {
  return brands.find((brand) => brand.id === id)
}

// Get watches for a brand
export function getWatchesForBrand(brandId: string): Watch[] {
  return brandWatches[brandId] || []
}
