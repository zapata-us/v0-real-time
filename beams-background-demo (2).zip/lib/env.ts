// Environment variable validation and access
// This ensures we have proper typing and validation for our environment variables

// Define the shape of our environment variables
interface EnvVariables {
  NEXT_PUBLIC_API_URL: string
  AUTH_SECRET: string
  NEXT_PUBLIC_GA_TRACKING_ID?: string
  NEXT_PUBLIC_IMAGE_STORAGE_URL: string
  NEXT_PUBLIC_ENABLE_CHAT_FEATURE: string
  NEXT_PUBLIC_ENABLE_ANALYTICS: string
  SOME_CRITICAL_VAR: string
}

// Get environment variables with validation
export function getEnv(): EnvVariables {
  // Required variables
  if (!process.env.NEXT_PUBLIC_API_URL) {
    throw new Error("NEXT_PUBLIC_API_URL is not defined")
  }

  if (!process.env.AUTH_SECRET) {
    throw new Error("AUTH_SECRET is not defined")
  }

  if (!process.env.NEXT_PUBLIC_IMAGE_STORAGE_URL) {
    throw new Error("NEXT_PUBLIC_IMAGE_STORAGE_URL is not defined")
  }

  if (!process.env.SOME_CRITICAL_VAR) {
    throw new Error("SOME_CRITICAL_VAR is not defined")
  }

  // Return typed environment variables
  return {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL,
    AUTH_SECRET: process.env.AUTH_SECRET,
    NEXT_PUBLIC_GA_TRACKING_ID: process.env.NEXT_PUBLIC_GA_TRACKING_ID || "",
    NEXT_PUBLIC_IMAGE_STORAGE_URL: process.env.NEXT_PUBLIC_IMAGE_STORAGE_URL,
    NEXT_PUBLIC_ENABLE_CHAT_FEATURE: process.env.NEXT_PUBLIC_ENABLE_CHAT_FEATURE || "false",
    NEXT_PUBLIC_ENABLE_ANALYTICS: process.env.NEXT_PUBLIC_ENABLE_ANALYTICS || "false",
    SOME_CRITICAL_VAR: process.env.SOME_CRITICAL_VAR,
  }
}

// Helper to check if a feature is enabled
export function isFeatureEnabled(featureName: "chat" | "analytics"): boolean {
  if (featureName === "chat") {
    return process.env.NEXT_PUBLIC_ENABLE_CHAT_FEATURE === "true"
  }

  if (featureName === "analytics") {
    return process.env.NEXT_PUBLIC_ENABLE_ANALYTICS === "true"
  }

  return false
}
