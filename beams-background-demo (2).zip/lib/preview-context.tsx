"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { ProductType } from "@/types/product"

interface PreviewContextType {
  isPreviewMode: boolean
  previewProduct: ProductType | null
  setPreviewMode: (isPreview: boolean) => void
  setPreviewProduct: (product: ProductType | null) => void
  clearPreview: () => void
}

const PreviewContext = createContext<PreviewContextType | undefined>(undefined)

export function PreviewProvider({ children }: { children: ReactNode }) {
  const [isPreviewMode, setIsPreviewMode] = useState(false)
  const [previewProduct, setPreviewProduct] = useState<ProductType | null>(null)

  // Clear preview data when navigating away (optional)
  useEffect(() => {
    return () => {
      if (typeof window !== "undefined") {
        // Only clear if navigating away from admin pages
        if (!window.location.pathname.includes("/admin")) {
          setIsPreviewMode(false)
          setPreviewProduct(null)
        }
      }
    }
  }, [])

  const clearPreview = () => {
    setIsPreviewMode(false)
    setPreviewProduct(null)
  }

  return (
    <PreviewContext.Provider
      value={{
        isPreviewMode,
        previewProduct,
        setPreviewMode: setIsPreviewMode,
        setPreviewProduct,
        clearPreview,
      }}
    >
      {children}
    </PreviewContext.Provider>
  )
}

export function usePreview() {
  const context = useContext(PreviewContext)
  if (context === undefined) {
    throw new Error("usePreview must be used within a PreviewProvider")
  }
  return context
}
