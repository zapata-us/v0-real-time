import type { ProductType } from "@/types/product"

// Cache for product data
const productCache = new Map<string, { data: ProductType; timestamp: number }>()
const CACHE_DURATION = 5 * 60 * 1000 // 5 minutes in milliseconds

// Mock data for demonstration
const mockProducts: ProductType[] = [
  {
    id: "1",
    name: "GMT-Master II 'Batman'",
    brand: "Rolex",
    price: 14950,
    description:
      "The GMT-Master II, introduced in 1982, was designed to show the time in two different time zones simultaneously. With its distinctive blue and black Cerachrom bezel, this model is affectionately nicknamed 'Batman' by watch enthusiasts.",
    features: [
      "Oyster, 40 mm, Oystersteel",
      "Bidirectional rotatable bezel with 24-hour graduated Cerachrom insert",
      "Black dial with luminescent hour markers",
      "GMT function for dual time zone display",
      "Water-resistant to 100 metres / 330 feet",
    ],
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    reference: "126710BLNR",
    caseSize: "40mm",
    caseMaterial: "Oystersteel",
    dialColor: "Black",
    bracelet: "Oyster, flat three-piece links",
    status: "published",
    source: "manual", // This product was manually entered
  },
  {
    id: "2",
    name: "Royal Oak Offshore",
    brand: "Audemars Piguet",
    price: 45900,
    description:
      "The Royal Oak Offshore collection was launched in 1993 as a more robust and sportier evolution of the iconic Royal Oak. It features a larger case size and more pronounced design elements.",
    features: [
      "42mm stainless steel case",
      "Blue 'Méga Tapisserie' dial",
      "Chronograph function",
      "Date display at 3 o'clock",
      "Water-resistant to 100 metres",
    ],
    image: "/images/watches/real-time-gmt-master-II-Batman.png",
    reference: "26238OR.OO.2000OR.01",
    caseSize: "42mm",
    caseMaterial: "Stainless Steel",
    dialColor: "Blue",
    bracelet: "Stainless Steel Bracelet",
    status: "published",
    source: "auto", // This product was automatically generated
  },
]

// Draft products storage (in a real app, this would be in a database)
const draftProducts: ProductType[] = []

// In a real application, these functions would interact with an API
export async function fetchProducts(options?: {
  limit?: number
  offset?: number
  filters?: {
    brands?: string[]
    materials?: string[]
    colors?: string[]
    sizes?: string[]
    categories?: string[]
    minPrice?: number
    maxPrice?: number
  }
}): Promise<ProductType[]> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  let result = [...mockProducts]
    .filter((p) => p.status === "published")
    .filter((p) => p.source === "manual" || p.source === undefined)

  // Apply filters if provided
  if (options?.filters) {
    const { brands, materials, colors, sizes, categories, minPrice, maxPrice } = options.filters

    if (brands && brands.length > 0) {
      result = result.filter((p) => brands.includes(p.brand))
    }

    if (materials && materials.length > 0) {
      result = result.filter((p) => p.caseMaterial && materials.includes(p.caseMaterial))
    }

    if (colors && colors.length > 0) {
      result = result.filter((p) => p.dialColor && colors.includes(p.dialColor))
    }

    if (sizes && sizes.length > 0) {
      result = result.filter((p) => {
        if (!p.caseSize) return false
        const size = Number.parseInt(p.caseSize)

        return sizes.some((range) => {
          if (range === "20-30 mm" && size >= 20 && size <= 30) return true
          if (range === "31-38 mm" && size >= 31 && size <= 38) return true
          if (range === "39-42 mm" && size >= 39 && size <= 42) return true
          if (range === "43+ mm" && size >= 43) return true
          return false
        })
      })
    }

    if (categories && categories.length > 0) {
      result = result.filter((p) => {
        if (!p.features) return false
        return categories.some((category) =>
          p.features.some((feature) => feature.toLowerCase().includes(category.toLowerCase())),
        )
      })
    }

    if (minPrice !== undefined) {
      result = result.filter((p) => p.price >= minPrice)
    }

    if (maxPrice !== undefined) {
      result = result.filter((p) => p.price <= maxPrice)
    }
  }

  // Apply pagination if provided
  if (options?.offset !== undefined && options?.limit !== undefined) {
    result = result.slice(options.offset, options.offset + options.limit)
  } else if (options?.limit !== undefined) {
    result = result.slice(0, options.limit)
  }

  return result
}

export async function fetchProductById(id: string): Promise<ProductType> {
  // Check cache first
  const cachedProduct = productCache.get(id)
  if (cachedProduct && Date.now() - cachedProduct.timestamp < CACHE_DURATION) {
    console.log("Using cached product data")
    return cachedProduct.data
  }

  // Simulate network conditions for development
  const networkDelay = process.env.NODE_ENV === "development" ? 800 : 200

  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, networkDelay))

  const product = mockProducts.find((p) => p.id === id)
  if (!product) {
    throw new Error(`Product with ID ${id} not found`)
  }

  // Cache the result
  productCache.set(id, { data: { ...product }, timestamp: Date.now() })

  return { ...product }
}

// Add a prefetch function for future use with Next.js
export async function prefetchProduct(id: string): Promise<void> {
  try {
    const product = await fetchProductById(id)
    productCache.set(id, { data: product, timestamp: Date.now() })
  } catch (error) {
    console.error(`Failed to prefetch product ${id}:`, error)
  }
}

// Add a function to clear the cache if needed
export function clearProductCache(): void {
  productCache.clear()
}

// Add a function to clear a specific product from cache
export function clearProductFromCache(id: string): void {
  productCache.delete(id)
}

// Add a function to fetch the latest products
export async function fetchLatestProducts(limit = 6): Promise<ProductType[]> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Sort products by date added (newest first) and filter out auto-generated products
  // In a real app, this would be a database query with ORDER BY
  return [...mockProducts]
    .filter((p) => p.status === "published")
    .filter((p) => p.source === "manual" || p.source === undefined) // Only return manually entered products
    .sort((a, b) => {
      // Use addedDate if available, otherwise use a random date
      const dateA = a.addedDate || Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000
      const dateB = b.addedDate || Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000
      return dateB - dateA
    })
    .slice(0, limit)
}

export async function saveProduct(product: ProductType, isDraft = false): Promise<ProductType> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1200))

  // For new products, generate an ID
  if (!product.id) {
    product.id = Math.random().toString(36).substring(2, 9)
  }

  // Set the status based on whether it's a draft
  product.status = isDraft ? "draft" : "published"

  // Add timestamp for when the product was published
  if (!isDraft && !product.addedDate) {
    product.addedDate = Date.now()
  }

  // In a real app, this would update the database
  // For this demo, we'll store drafts separately
  if (isDraft) {
    const existingIndex = draftProducts.findIndex((p) => p.id === product.id)
    if (existingIndex >= 0) {
      draftProducts[existingIndex] = { ...product }
    } else {
      draftProducts.push({ ...product })
    }
  } else {
    // For published products, update the main list
    const existingIndex = mockProducts.findIndex((p) => p.id === product.id)
    if (existingIndex >= 0) {
      mockProducts[existingIndex] = { ...product }
    } else {
      mockProducts.push({ ...product })
    }

    // Also remove from drafts if it exists there
    const draftIndex = draftProducts.findIndex((p) => p.id === product.id)
    if (draftIndex >= 0) {
      draftProducts.splice(draftIndex, 1)
    }
  }

  return { ...product }
}

export async function fetchDraftProducts(): Promise<ProductType[]> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))
  return [...draftProducts]
}

export async function fetchDraftProductById(id: string): Promise<ProductType | null> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const product = draftProducts.find((p) => p.id === id)
  return product ? { ...product } : null
}

export async function deleteProduct(id: string): Promise<void> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  // In a real app, this would delete from the database
  // For this demo, we'll just simulate success
  return
}

export async function publishDraft(id: string): Promise<ProductType> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Find the draft
  const draftIndex = draftProducts.findIndex((p) => p.id === id)
  if (draftIndex < 0) {
    throw new Error(`Draft product with ID ${id} not found`)
  }

  // Get the draft and mark as published
  const draft = { ...draftProducts[draftIndex], status: "published" }

  // Update or add to published products
  const existingIndex = mockProducts.findIndex((p) => p.id === id)
  if (existingIndex >= 0) {
    mockProducts[existingIndex] = draft
  } else {
    mockProducts.push(draft)
  }

  // Remove from drafts
  draftProducts.splice(draftIndex, 1)

  return draft
}

export async function searchProducts(query: string): Promise<ProductType[]> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  if (!query.trim()) {
    return fetchProducts()
  }

  const lowercaseQuery = query.toLowerCase()

  return mockProducts
    .filter((p) => p.status === "published")
    .filter((p) => p.source === "manual" || p.source === undefined)
    .filter(
      (p) =>
        p.name.toLowerCase().includes(lowercaseQuery) ||
        p.brand.toLowerCase().includes(lowercaseQuery) ||
        (p.reference && p.reference.toLowerCase().includes(lowercaseQuery)),
    )
}
