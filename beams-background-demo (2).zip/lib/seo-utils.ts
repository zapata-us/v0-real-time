import type { Metadata } from "next"
import type { ProductType } from "@/types/product"

// Generate SEO metadata for product pages
export function generateProductMetadata(product: ProductType): Metadata {
  return {
    title: `${product.name} | ${product.brand}`,
    description:
      product.description?.substring(0, 160) ||
      `Discover the ${product.brand} ${product.name} luxury timepiece at REAL TIME.`,
    openGraph: {
      title: `${product.name} | ${product.brand}`,
      description:
        product.description?.substring(0, 160) ||
        `Discover the ${product.brand} ${product.name} luxury timepiece at REAL TIME.`,
      images: [
        {
          url: product.image || "/images/og-default.jpg",
          width: 1200,
          height: 630,
          alt: `${product.brand} ${product.name}`,
        },
      ],
      type: "product",
      product: {
        price: {
          amount: product.price.toString(),
          currency: "USD",
        },
      },
    },
    twitter: {
      card: "summary_large_image",
      title: `${product.name} | ${product.brand}`,
      description:
        product.description?.substring(0, 160) ||
        `Discover the ${product.brand} ${product.name} luxury timepiece at REAL TIME.`,
      images: [product.image || "/images/twitter-default.jpg"],
    },
  }
}

// Generate SEO metadata for category pages
export function generateCategoryMetadata(category: string): Metadata {
  const formattedCategory = category.charAt(0).toUpperCase() + category.slice(1)

  return {
    title: `${formattedCategory} Watches Collection`,
    description: `Explore our collection of ${formattedCategory.toLowerCase()} luxury watches. Find the perfect timepiece for your style and preferences.`,
    openGraph: {
      title: `${formattedCategory} Watches Collection | REAL TIME`,
      description: `Explore our collection of ${formattedCategory.toLowerCase()} luxury watches. Find the perfect timepiece for your style and preferences.`,
      images: [
        {
          url: `/images/categories/${category.toLowerCase()}.jpg`,
          width: 1200,
          height: 630,
          alt: `${formattedCategory} Watches Collection`,
        },
      ],
    },
  }
}
