"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { loadStripe, type Stripe } from "@stripe/stripe-js"
import { Elements } from "@stripe/react-stripe-js"

// Replace with your publishable key
const STRIPE_PUBLISHABLE_KEY = process.env.NEXT_PUBLIC_API_URL + "/stripe-key"

interface StripeContextType {
  stripe: Stripe | null
  isLoading: boolean
}

const StripeContext = createContext<StripeContextType | undefined>(undefined)

export function StripeProvider({ children }: { children: ReactNode }) {
  const [stripePromise, setStripePromise] = useState(() => loadStripe(STRIPE_PUBLISHABLE_KEY))
  const [stripe, setStripe] = useState<Stripe | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const initializeStripe = async () => {
      try {
        const stripeInstance = await stripePromise
        setStripe(stripeInstance)
      } catch (error) {
        console.error("Failed to initialize Stripe:", error)
      } finally {
        setIsLoading(false)
      }
    }

    initializeStripe()
  }, [stripePromise])

  return (
    <StripeContext.Provider value={{ stripe, isLoading }}>
      <Elements stripe={stripePromise}>{children}</Elements>
    </StripeContext.Provider>
  )
}

export function useStripe() {
  const context = useContext(StripeContext)
  if (context === undefined) {
    throw new Error("useStripe must be used within a StripeProvider")
  }
  return context
}
