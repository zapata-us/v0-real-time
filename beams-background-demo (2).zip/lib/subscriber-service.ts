import type { SubscriberType } from "@/types/subscriber"

// Mock data for demonstration
const mockSubscribers: SubscriberType[] = [
  {
    id: "sub_1",
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    companyName: "Luxury Watches Inc.",
    phone: "555-123-4567",
    address: {
      street: "123 Main St",
      city: "New York",
      state: "NY",
      zip: "10001",
      country: "USA",
    },
    username: "johndoe",
    subscriptionType: "annual",
    subscriptionStatus: "active",
    startDate: Date.now() - 90 * 24 * 60 * 60 * 1000, // 90 days ago
    nextBillingDate: Date.now() + 275 * 24 * 60 * 60 * 1000, // 275 days in future
    createdAt: Date.now() - 90 * 24 * 60 * 60 * 1000,
    lastLoginAt: Date.now() - 2 * 24 * 60 * 60 * 1000,
  },
  {
    id: "sub_2",
    firstName: "Jane",
    lastName: "Smith",
    email: "jane.smith@example.com",
    companyName: "Smith's Jewelry",
    phone: "555-987-6543",
    address: {
      street: "456 Oak Ave",
      street2: "Suite 201",
      city: "Los Angeles",
      state: "CA",
      zip: "90001",
      country: "USA",
    },
    username: "janesmith",
    subscriptionType: "monthly",
    subscriptionStatus: "active",
    startDate: Date.now() - 45 * 24 * 60 * 60 * 1000, // 45 days ago
    nextBillingDate: Date.now() + 15 * 24 * 60 * 60 * 1000, // 15 days in future
    createdAt: Date.now() - 45 * 24 * 60 * 60 * 1000,
    lastLoginAt: Date.now() - 1 * 24 * 60 * 60 * 1000,
  },
  {
    id: "sub_3",
    firstName: "Robert",
    lastName: "Johnson",
    email: "robert.johnson@example.com",
    companyName: "Johnson's Pawn",
    phone: "555-456-7890",
    address: {
      street: "789 Pine Blvd",
      city: "Chicago",
      state: "IL",
      zip: "60007",
      country: "USA",
    },
    username: "robertj",
    subscriptionType: "annual",
    subscriptionStatus: "expired",
    startDate: Date.now() - 380 * 24 * 60 * 60 * 1000, // 380 days ago
    nextBillingDate: Date.now() - 15 * 24 * 60 * 60 * 1000, // 15 days ago
    createdAt: Date.now() - 380 * 24 * 60 * 60 * 1000,
    lastLoginAt: Date.now() - 20 * 24 * 60 * 60 * 1000,
  },
  {
    id: "sub_4",
    firstName: "Maria",
    lastName: "Garcia",
    email: "maria.garcia@example.com",
    companyName: "Elite Watch Collectors",
    phone: "555-789-0123",
    address: {
      street: "321 Elm St",
      city: "Miami",
      state: "FL",
      zip: "33101",
      country: "USA",
    },
    username: "mariag",
    subscriptionType: "monthly",
    subscriptionStatus: "cancelled",
    startDate: Date.now() - 70 * 24 * 60 * 60 * 1000, // 70 days ago
    nextBillingDate: Date.now() - 10 * 24 * 60 * 60 * 1000, // 10 days ago
    createdAt: Date.now() - 70 * 24 * 60 * 60 * 1000,
    lastLoginAt: Date.now() - 25 * 24 * 60 * 60 * 1000,
  },
  {
    id: "sub_5",
    firstName: "Michael",
    lastName: "Brown",
    email: "michael.brown@example.com",
    companyName: "Antique Timepieces",
    phone: "555-321-6547",
    address: {
      street: "654 Maple Dr",
      city: "Dallas",
      state: "TX",
      zip: "75001",
      country: "USA",
    },
    username: "michaelb",
    subscriptionType: "annual",
    subscriptionStatus: "active",
    startDate: Date.now() - 30 * 24 * 60 * 60 * 1000, // 30 days ago
    nextBillingDate: Date.now() + 335 * 24 * 60 * 60 * 1000, // 335 days in future
    createdAt: Date.now() - 30 * 24 * 60 * 60 * 1000,
    lastLoginAt: Date.now() - 3 * 24 * 60 * 60 * 1000,
  },
]

// In a real application, these functions would interact with an API
export async function fetchSubscribers(options?: {
  limit?: number
  offset?: number
  filters?: {
    status?: string[]
    type?: string[]
    search?: string
  }
}): Promise<SubscriberType[]> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  let result = [...mockSubscribers]

  // Apply filters if provided
  if (options?.filters) {
    const { status, type, search } = options.filters

    if (status && status.length > 0) {
      result = result.filter((s) => status.includes(s.subscriptionStatus))
    }

    if (type && type.length > 0) {
      result = result.filter((s) => type.includes(s.subscriptionType))
    }

    if (search) {
      const lowerSearch = search.toLowerCase()
      result = result.filter(
        (s) =>
          s.firstName.toLowerCase().includes(lowerSearch) ||
          s.lastName.toLowerCase().includes(lowerSearch) ||
          s.email.toLowerCase().includes(lowerSearch) ||
          s.companyName.toLowerCase().includes(lowerSearch) ||
          s.username.toLowerCase().includes(lowerSearch),
      )
    }
  }

  // Apply pagination if provided
  if (options?.offset !== undefined && options?.limit !== undefined) {
    result = result.slice(options.offset, options.offset + options.limit)
  } else if (options?.limit !== undefined) {
    result = result.slice(0, options.limit)
  }

  return result
}

export async function fetchSubscriberById(id: string): Promise<SubscriberType> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const subscriber = mockSubscribers.find((s) => s.id === id)
  if (!subscriber) {
    throw new Error(`Subscriber with ID ${id} not found`)
  }

  return { ...subscriber }
}

export async function updateSubscriptionStatus(
  id: string,
  status: "active" | "cancelled" | "expired" | "pending",
): Promise<SubscriberType> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const subscriberIndex = mockSubscribers.findIndex((s) => s.id === id)
  if (subscriberIndex < 0) {
    throw new Error(`Subscriber with ID ${id} not found`)
  }

  mockSubscribers[subscriberIndex] = {
    ...mockSubscribers[subscriberIndex],
    subscriptionStatus: status,
    // Update next billing date if reactivating
    nextBillingDate:
      status === "active"
        ? mockSubscribers[subscriberIndex].subscriptionType === "monthly"
          ? Date.now() + 30 * 24 * 60 * 60 * 1000
          : Date.now() + 365 * 24 * 60 * 60 * 1000
        : mockSubscribers[subscriberIndex].nextBillingDate,
  }

  return { ...mockSubscribers[subscriberIndex] }
}

export async function deleteSubscriber(id: string): Promise<void> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  // In a real app, this would delete from the database
  // For this demo, we'll just simulate success
  return
}

export async function searchSubscribers(query: string): Promise<SubscriberType[]> {
  return fetchSubscribers({
    filters: {
      search: query,
    },
  })
}
