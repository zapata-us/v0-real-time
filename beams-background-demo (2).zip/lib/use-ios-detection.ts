"use client"

import { useState, useEffect } from "react"

export function useIOSDetection() {
  const [isIOS, setIsIOS] = useState(false)

  useEffect(() => {
    // Check if the device is running iOS
    const checkIsIOS = () => {
      if (typeof window === "undefined") return false

      const userAgent = window.navigator.userAgent.toLowerCase()
      return /iphone|ipad|ipod/.test(userAgent) || (userAgent.includes("mac") && "ontouchend" in document)
    }

    setIsIOS(checkIsIOS())
  }, [])

  return isIOS
}
