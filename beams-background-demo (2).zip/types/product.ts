export interface ProductType {
  id: string
  name: string
  brand: string
  price: number
  description: string
  features: string[]
  image: string
  reference?: string
  caseSize?: string
  caseMaterial?: string
  dialColor?: string
  bracelet?: string
  status?: "draft" | "published"
  addedDate?: number // Timestamp when the product was added/published
  source?: "manual" | "auto" // Indicates if the product was manually entered or automatically generated
}
