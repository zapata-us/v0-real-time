export interface SubscriberType {
  id: string
  firstName: string
  lastName: string
  email: string
  companyName: string
  phone: string
  address: {
    street: string
    street2?: string
    city: string
    state: string
    zip: string
    country: string
  }
  username: string
  subscriptionType: "monthly" | "annual"
  subscriptionStatus: "active" | "cancelled" | "expired" | "pending"
  startDate: number // timestamp
  nextBillingDate: number // timestamp
  createdAt: number
  lastLoginAt?: number
}
